import React, { useState } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, MessageSquare, DollarSign, Calendar as CalendarIcon, CheckCircle2, FileText, Eye, Clock } from "lucide-react";
import { toast } from "react-hot-toast";
import { format, addDays, parseISO } from "date-fns";

export default function RentalDetailsDialog({ rental, isOpen, onClose }) {
  const [noteText, setNoteText] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("מזומן");
  const [extendDays, setExtendDays] = useState("30");
  const [extendType, setExtendType] = useState("ימים");
  const [delayHours, setDelayHours] = useState("");
  const [activeTab, setActiveTab] = useState("notes");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showEndDialog, setShowEndDialog] = useState(false);
  const [endKm, setEndKm] = useState("");
  const [additionalCharges, setAdditionalCharges] = useState("");
  const [extensionDate, setExtensionDate] = useState("");
  const [extensionTime, setExtensionTime] = useState("");
  const queryClient = useQueryClient();

  // Fetch booking to get signed documents
  const { data: booking } = useQuery({
    queryKey: ["booking", rental?.booking_id],
    queryFn: async () => {
      if (!rental?.booking_id) return null;
      const bookings = await base44.entities.Booking.list();
      return bookings.find(b => b.id === rental.booking_id);
    },
    enabled: !!rental?.booking_id
  });

  // Fetch customer details
  const { data: customer } = useQuery({
    queryKey: ["customer", rental?.customer_id],
    queryFn: async () => {
      if (!rental?.customer_id) return null;
      const customers = await base44.entities.Customer.list();
      return customers.find(c => c.id === rental.customer_id);
    },
    enabled: !!rental?.customer_id
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Rental.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["rentals"] });
      queryClient.invalidateQueries({ queryKey: ["rental", rental?.id] });
    }
  });

  const createIncomeMutation = useMutation({
    mutationFn: (data) => base44.entities.Income.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["incomes"]);
    }
  });

  const handleAddNote = async () => {
    if (!noteText.trim()) return;

    setIsProcessing(true);
    try {
      const currentNotes = rental.notes || "";
      const timestamp = format(new Date(), "dd/MM/yyyy HH:mm");
      const newNote = `[${timestamp}] ${noteText}`;
      const updatedNotes = currentNotes ? `${currentNotes}\n\n${newNote}` : newNote;

      await updateMutation.mutateAsync({
        id: rental.id,
        data: { notes: updatedNotes }
      });

      setNoteText("");
      toast.success("ההערה נוספה בהצלחה");
    } catch (error) {
      toast.error("שגיאה בהוספת הערה");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAddPayment = async () => {
    const amount = parseFloat(paymentAmount);
    if (!amount || amount <= 0) {
      toast.error("נא להזין סכום תקין");
      return;
    }

    setIsProcessing(true);
    try {
      const newPaidAmount = (rental.paid_amount || 0) + amount;
      const newRemaining = (rental.total_cost || rental.base_cost || 0) - newPaidAmount;

      // Update rental with new payment
      await updateMutation.mutateAsync({
        id: rental.id,
        data: {
          paid_amount: newPaidAmount,
          remaining_payment: newRemaining
        }
      });

      // Create income record
      await createIncomeMutation.mutateAsync({
        customer_id: rental.customer_id,
        customer_name: rental.customer_name,
        rental_id: rental.id,
        vehicle_id: rental.vehicle_id,
        amount: amount,
        date: format(new Date(), "yyyy-MM-dd"),
        type: "השכרה",
        payment_method: paymentMethod,
        notes: "תשלום באמצע השכרה"
      });

      setPaymentAmount("");
      toast.success("התשלום נרשם בהצלחה");
    } catch (error) {
      toast.error("שגיאה ברישום תשלום");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExtendRental = async () => {
    let newEndDateStr;
    let newEndTime = extensionTime || rental.planned_end_time;

    // Check if using specific date
    if (extensionDate) {
      newEndDateStr = extensionDate;
    } else {
      // Use days calculation
      let daysToAdd = 0;
      
      if (extendType === "ימים") {
        daysToAdd = parseInt(extendDays);
        if (!daysToAdd || daysToAdd <= 0) {
          toast.error("נא להזין מספר ימים תקין");
          return;
        }
      } else if (extendType === "חצי יום") {
        daysToAdd = 0.5;
      } else if (extendType === "24 שעות") {
        daysToAdd = 1;
      } else if (extendType === "שבוע") {
        daysToAdd = 7;
      } else if (extendType === "חודש") {
        daysToAdd = 30;
      }

      const currentEndDate = new Date(rental.planned_end_date);
      const newEndDate = addDays(currentEndDate, daysToAdd);
      newEndDateStr = format(newEndDate, "yyyy-MM-dd");
    }

    setIsProcessing(true);
    try {
      const newEndDate = new Date(newEndDateStr);

      // Check if vehicle is available for extension
      const bookings = await base44.entities.Booking.list();
      const conflict = bookings.find(b => 
        b.vehicle_id === rental.vehicle_id &&
        b.id !== rental.booking_id &&
        b.status !== "בוטל" &&
        parseISO(b.start_date) <= newEndDate &&
        parseISO(b.end_date) >= currentEndDate
      );

      if (conflict) {
        toast.error(`הרכב תפוס ע"י ${conflict.customer_name} בתאריכים ${conflict.start_date} - ${conflict.end_date}`);
        setIsProcessing(false);
        return;
      }

      // Update rental
      await updateMutation.mutateAsync({
        id: rental.id,
        data: {
          planned_end_date: newEndDateStr,
          planned_end_time: newEndTime
        }
      });

      // Update the related booking if exists
      if (rental.booking_id) {
        await base44.entities.Booking.update(rental.booking_id, {
          end_date: newEndDateStr,
          end_time: newEndTime
        });
        queryClient.invalidateQueries(["bookings"]);
      }

      setExtensionDate("");
      setExtensionTime("");
      toast.success("ההשכרה הוארכה בהצלחה");
    } catch (error) {
      toast.error("שגיאה בהארכת השכרה");
    } finally {
      setIsProcessing(false);
    }
  };

  if (!rental) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>פרטי השכרה - {rental.customer_name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Info */}
          <Card className="p-4 bg-gray-50">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span className="text-gray-500">רכב:</span>
                <p className="font-medium">{rental.vehicle_details}</p>
              </div>
              <div>
                <span className="text-gray-500">תאריכים:</span>
                <p className="font-medium">
                  {rental.start_date} {rental.start_time && `(${rental.start_time})`} - {rental.planned_end_date} {rental.planned_end_time && `(${rental.planned_end_time})`}
                </p>
                {rental.status === "הושלם" && rental.actual_end_date && (
                  <p className="text-xs text-green-600 mt-1">
                    סיום בפועל: {rental.actual_end_date} {rental.actual_end_time && `(${rental.actual_end_time})`}
                  </p>
                )}
              </div>
              <div>
                <span className="text-gray-500">ק"מ התחלה:</span>
                <p className="font-medium">{rental.start_km?.toLocaleString()}</p>
              </div>
              <div>
                <span className="text-gray-500">עלות כוללת:</span>
                <p className="font-medium text-lg">
                  ₪{(rental.total_cost || rental.base_cost)?.toLocaleString()}
                </p>
              </div>
            </div>
          </Card>

          {/* Payment Summary */}
          <Card className="p-4 border-cyan-200 bg-cyan-50">
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              סטטוס תשלום
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>עלות כוללת:</span>
                <span className="font-medium">
                  ₪{(rental.total_cost || rental.base_cost)?.toLocaleString() || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span>שולם עד כה:</span>
                <span className="font-medium text-green-600">
                  ₪{rental.paid_amount?.toLocaleString() || 0}
                </span>
              </div>
              <div className="flex justify-between border-t pt-2">
                <span className="font-semibold">נותר לתשלום:</span>
                <span className="font-bold text-red-600">
                  ₪{rental.remaining_payment?.toLocaleString() || 0}
                </span>
              </div>
            </div>
          </Card>

          {/* Customer Details */}
          {customer && (
            <Card className="p-4 border-blue-200 bg-blue-50">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                פרטי לקוח
              </h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-600">טלפון:</span>
                  <p className="font-medium">{customer.phone}</p>
                </div>
                {customer.phone_secondary && (
                  <div>
                    <span className="text-gray-600">טלפון נוסף:</span>
                    <p className="font-medium">{customer.phone_secondary}</p>
                  </div>
                )}
                {customer.email && (
                  <div>
                    <span className="text-gray-600">מייל:</span>
                    <p className="font-medium">{customer.email}</p>
                  </div>
                )}
                <div>
                  <span className="text-gray-600">תעודת זהות:</span>
                  <p className="font-medium">{customer.id_number}</p>
                </div>
                {customer.address && (
                  <div className="col-span-2">
                    <span className="text-gray-600">כתובת:</span>
                    <p className="font-medium">{customer.address}</p>
                  </div>
                )}
                {(customer.license_front_image || customer.license_back_image) && (
                  <div className="col-span-2">
                    <span className="text-gray-600 block mb-2">רישיון נהיגה:</span>
                    <div className="flex gap-2">
                      {customer.license_front_image && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(customer.license_front_image, '_blank')}
                        >
                          <Eye className="w-3 h-3 ml-1" />
                          צד קדמי
                        </Button>
                      )}
                      {customer.license_back_image && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(customer.license_back_image, '_blank')}
                        >
                          <Eye className="w-3 h-3 ml-1" />
                          צד אחורי
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </Card>
          )}

          {/* Signed Documents */}
          {booking && (
            <Card className="p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <FileText className="w-5 h-5" />
                מסמכים חתומים
              </h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm">חוזה השכרה</span>
                  <div className="flex items-center gap-2">
                    {booking.contract_signed ? (
                      <>
                        <span className="text-xs text-green-600">✓ נחתם</span>
                        {booking.contract_url && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (booking.contract_url.startsWith('data:')) {
                                const win = window.open();
                                win.document.write(`<img src="${booking.contract_url}" style="max-width:100%"/>`);
                              } else {
                                window.open(booking.contract_url, '_blank');
                              }
                            }}
                          >
                            <Eye className="w-3 h-3" />
                          </Button>
                        )}
                      </>
                    ) : (
                      <span className="text-xs text-gray-400">לא נחתם</span>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm">תצהיר קבלת רכב</span>
                  <div className="flex items-center gap-2">
                    {booking.declaration_signed ? (
                      <>
                        <span className="text-xs text-green-600">✓ נחתם</span>
                        {booking.declaration_url && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (booking.declaration_url.startsWith('data:')) {
                                const win = window.open();
                                win.document.write(`<img src="${booking.declaration_url}" style="max-width:100%"/>`);
                              } else {
                                window.open(booking.declaration_url, '_blank');
                              }
                            }}
                          >
                            <Eye className="w-3 h-3" />
                          </Button>
                        )}
                      </>
                    ) : (
                      <span className="text-xs text-gray-400">לא נחתם</span>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm">כתב ויתור</span>
                  <div className="flex items-center gap-2">
                    {booking.waiver_signed ? (
                      <>
                        <span className="text-xs text-green-600">✓ נחתם</span>
                        {booking.waiver_url && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (booking.waiver_url.startsWith('data:')) {
                                const win = window.open();
                                win.document.write(`<img src="${booking.waiver_url}" style="max-width:100%"/>`);
                              } else {
                                window.open(booking.waiver_url, '_blank');
                              }
                            }}
                          >
                            <Eye className="w-3 h-3" />
                          </Button>
                        )}
                      </>
                    ) : (
                      <span className="text-xs text-gray-400">לא נחתם</span>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          )}

          {/* End Rental Button */}
          {rental.status === "פעיל" && (
            <Button 
              onClick={() => setShowEndDialog(true)}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <CheckCircle2 className="w-5 h-5 ml-2" />
              סיום השכרה
            </Button>
          )}

          {/* Actions Tabs */}
          {rental.status === "פעיל" && (
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="notes">
                  <MessageSquare className="w-4 h-4 ml-2" />
                  הערות
                </TabsTrigger>
                <TabsTrigger value="extend">
                  <CalendarIcon className="w-4 h-4 ml-2" />
                  הארכה
                </TabsTrigger>
                <TabsTrigger value="payment">
                  <DollarSign className="w-4 h-4 ml-2" />
                  תשלום
                </TabsTrigger>
                <TabsTrigger value="delay">
                  <Clock className="w-4 h-4 ml-2" />
                  איחור
                </TabsTrigger>
              </TabsList>

              <TabsContent value="notes" className="mt-4">
                <Card className="p-4">
                  {rental.notes && (
                    <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                      <pre className="text-sm whitespace-pre-wrap font-sans">{rental.notes}</pre>
                    </div>
                  )}
                  
                  <div className="space-y-3">
                    <div>
                      <Label>הערה חדשה</Label>
                      <Textarea
                        placeholder="הוסף הערה..."
                        value={noteText}
                        onChange={(e) => setNoteText(e.target.value)}
                        rows={3}
                      />
                    </div>
                    <Button 
                      onClick={handleAddNote} 
                      disabled={!noteText.trim() || isProcessing}
                      className="w-full bg-cyan-600 hover:bg-cyan-700"
                    >
                      {isProcessing ? (
                        <>מעדכן...</>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4 ml-1" />
                          עדכן הערה
                        </>
                      )}
                    </Button>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="extend" className="mt-4">
                <Card className="p-4">
                  <div className="space-y-4">
                    <div>
                      <Label>סוג הארכה</Label>
                      <Select value={extendType} onValueChange={setExtendType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="חצי יום">חצי יום</SelectItem>
                          <SelectItem value="24 שעות">24 שעות</SelectItem>
                          <SelectItem value="שבוע">שבוע</SelectItem>
                          <SelectItem value="חודש">חודש</SelectItem>
                          <SelectItem value="ימים">מספר ימים</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {extendType === "ימים" && (
                      <div>
                        <Label>מספר ימים</Label>
                        <Input
                          type="number"
                          placeholder="30"
                          value={extendDays}
                          onChange={(e) => setExtendDays(e.target.value)}
                        />
                      </div>
                    )}

                    <div className="border-t pt-4 mt-4">
                      <Label className="font-medium mb-2 block">או הארכה עד תאריך מסוים:</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-sm">תאריך</Label>
                          <Input
                            type="date"
                            value={extensionDate}
                            onChange={(e) => setExtensionDate(e.target.value)}
                            min={rental.planned_end_date}
                          />
                        </div>
                        <div>
                          <Label className="text-sm">שעה</Label>
                          <Input
                            type="time"
                            value={extensionTime}
                            onChange={(e) => setExtensionTime(e.target.value)}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="p-3 bg-gray-50 rounded text-sm">
                      <p className="text-gray-600">
                        תאריך סיום נוכחי: {format(new Date(rental.planned_end_date), "dd/MM/yyyy")}
                      </p>
                    </div>

                    <Button 
                      onClick={handleExtendRental}
                      disabled={isProcessing}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      {isProcessing ? (
                        <>מעדכן...</>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4 ml-1" />
                          עדכן הארכה
                        </>
                      )}
                    </Button>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="payment" className="mt-4">
                <Card className="p-4">
                  <div className="space-y-4">
                    <div>
                      <Label>סכום לתשלום</Label>
                      <Input
                        type="number"
                        placeholder="0"
                        value={paymentAmount}
                        onChange={(e) => setPaymentAmount(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>אמצעי תשלום</Label>
                      <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="מזומן">מזומן</SelectItem>
                          <SelectItem value="אשראי">אשראי</SelectItem>
                          <SelectItem value="צ'ק">צ'ק</SelectItem>
                          <SelectItem value="העברה בנקאית">העברה בנקאית</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button 
                      onClick={handleAddPayment}
                      disabled={!paymentAmount || isProcessing}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      {isProcessing ? (
                        <>מעדכן...</>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4 ml-1" />
                          עדכן תשלום
                        </>
                      )}
                    </Button>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="delay" className="mt-4">
                <Card className="p-4">
                  <div className="space-y-4">
                    <div>
                      <Label>שעות איחור</Label>
                      <Input
                        type="number"
                        placeholder="מספר שעות"
                        value={delayHours}
                        onChange={(e) => setDelayHours(e.target.value)}
                      />
                    </div>

                    <div className="p-3 bg-yellow-50 rounded text-sm">
                      <p className="text-gray-700">
                        <strong>תעריף איחור שעתי:</strong> ₪{rental.vehicle_id ? "50" : "50"} לשעה
                      </p>
                      {delayHours && (
                        <p className="text-gray-700 mt-1">
                          <strong>עלות איחור:</strong> ₪{(parseFloat(delayHours) * 50).toLocaleString()}
                        </p>
                      )}
                    </div>

                    <Button 
                      onClick={async () => {
                        if (!delayHours || parseFloat(delayHours) <= 0) {
                          toast.error("נא להזין מספר שעות תקין");
                          return;
                        }

                        setIsProcessing(true);
                        try {
                          const delayCost = parseFloat(delayHours) * 50;
                          const newTotal = (rental.total_cost || rental.base_cost) + delayCost;
                          const newRemaining = newTotal - (rental.paid_amount || 0);

                          await updateMutation.mutateAsync({
                            id: rental.id,
                            data: {
                              additional_charges: (rental.additional_charges || 0) + delayCost,
                              additional_charges_details: (rental.additional_charges_details || "") + `\nאיחור: ${delayHours} שעות - ₪${delayCost}`,
                              total_cost: newTotal,
                              remaining_payment: newRemaining
                            }
                          });

                          setDelayHours("");
                          toast.success("עלות האיחור נוספה בהצלחה");
                        } catch (error) {
                          toast.error("שגיאה בעדכון איחור");
                        } finally {
                          setIsProcessing(false);
                        }
                      }}
                      disabled={!delayHours || isProcessing}
                      className="w-full bg-orange-600 hover:bg-orange-700"
                    >
                      {isProcessing ? (
                        <>מעדכן...</>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4 ml-1" />
                          עדכן איחור
                        </>
                      )}
                    </Button>
                  </div>
                </Card>
              </TabsContent>
              </Tabs>
              )}

              {/* Notes (for completed rentals) */}
          {rental.status !== "פעיל" && rental.notes && (
            <Card className="p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                הערות
              </h3>
              <div className="p-3 bg-gray-50 rounded-lg">
                <pre className="text-sm whitespace-pre-wrap font-sans">{rental.notes}</pre>
              </div>
            </Card>
          )}

          <Button onClick={onClose} variant="outline" className="w-full">
            סגור
          </Button>
        </div>
      </DialogContent>

      {/* End Rental Dialog */}
      <Dialog open={showEndDialog} onOpenChange={setShowEndDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>סיום השכרה</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Card className="p-3 bg-gray-50">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-gray-500">לקוח:</span>
                  <p className="font-medium">{rental?.customer_name}</p>
                </div>
                <div>
                  <span className="text-gray-500">רכב:</span>
                  <p className="font-medium">{rental?.vehicle_details}</p>
                </div>
                <div>
                  <span className="text-gray-500">ק"מ התחלה:</span>
                  <p className="font-medium">{rental?.start_km}</p>
                </div>
              </div>
            </Card>

            <div>
              <Label>ק"מ סיום *</Label>
              <Input
                type="number"
                value={endKm}
                onChange={(e) => setEndKm(e.target.value)}
                placeholder="קמ בסיום"
              />
            </div>

            <div>
              <Label>חיובים נוספים</Label>
              <Input
                type="number"
                value={additionalCharges}
                onChange={(e) => setAdditionalCharges(e.target.value)}
                placeholder="0"
              />
            </div>

            <div className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={() => setShowEndDialog(false)}
                disabled={isProcessing}
              >
                ביטול
              </Button>
              <Button 
                onClick={async () => {
                  if (!endKm) {
                    toast.error("נא למלא ק\"מ סיום");
                    return;
                  }

                  setIsProcessing(true);
                  try {
                    const actualEndDate = format(new Date(), "yyyy-MM-dd");
                    const actualEndTime = format(new Date(), "HH:mm");
                    const extraCharges = parseFloat(additionalCharges) || 0;
                    const totalCost = (rental.base_cost || 0) + extraCharges;
                    const remainingPayment = totalCost - (rental.paid_amount || 0);

                    await updateMutation.mutateAsync({
                      id: rental.id,
                      data: {
                        status: "הושלם",
                        actual_end_date: actualEndDate,
                        actual_end_time: actualEndTime,
                        end_km: parseInt(endKm),
                        additional_charges: extraCharges,
                        total_cost: totalCost,
                        remaining_payment: remainingPayment
                      }
                    });

                    // Update vehicle
                    const vehicles = await base44.entities.Vehicle.list();
                    const vehicle = vehicles.find(v => v.id === rental.vehicle_id);
                    if (vehicle) {
                      await base44.entities.Vehicle.update(rental.vehicle_id, {
                        status: "זמין",
                        current_km: parseInt(endKm)
                      });
                    }

                    setShowEndDialog(false);
                    onClose();
                    toast.success("ההשכרה הסתיימה בהצלחה");
                  } catch (error) {
                    toast.error("שגיאה בסיום השכרה");
                  } finally {
                    setIsProcessing(false);
                  }
                }}
                disabled={!endKm || isProcessing}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                {isProcessing ? "מסיים..." : "סיים השכרה"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Dialog>
  );
}