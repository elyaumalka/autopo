import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Camera, Upload, Check } from "lucide-react";
import { toast } from "react-hot-toast";

export default function VehiclePhotos() {
  const [photos, setPhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  
  const urlParams = new URLSearchParams(window.location.search);
  const rentalId = urlParams.get("rental");
  const customerName = urlParams.get("customer");
  const vehicleDetails = urlParams.get("vehicle");
  const date = urlParams.get("date");

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files);
    setUploading(true);

    try {
      const uploadedUrls = [];
      for (const file of files) {
        const result = await base44.integrations.Core.UploadFile({ file });
        uploadedUrls.push(result.file_url);
      }
      
      setPhotos([...photos, ...uploadedUrls]);
      toast.success(`${files.length} תמונות הועלו בהצלחה`);
    } catch (error) {
      toast.error("שגיאה בהעלאת התמונות");
    } finally {
      setUploading(false);
    }
  };

  const handleComplete = async () => {
    if (photos.length === 0) {
      toast.error("נא להעלות לפחות תמונה אחת");
      return;
    }

    try {
      // Update rental with photos
      await base44.entities.Rental.update(rentalId, {
        notes: `תמונות רכב בתחילת השכרה:\n${photos.join("\n")}`
      });

      toast.success("התמונות נשמרו בהצלחה!");
      
      setTimeout(() => {
        window.close();
      }, 2000);
    } catch (error) {
      toast.error("שגיאה בשמירת התמונות");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-6" dir="rtl">
      <div className="max-w-4xl mx-auto">
        <Card className="p-6">
          <div className="text-center mb-6">
            <Camera className="w-16 h-16 mx-auto mb-4 text-cyan-600" />
            <h1 className="text-2xl font-bold mb-2">צילום תמונות רכב</h1>
            <div className="text-gray-600 space-y-1">
              <p className="font-medium">שוכר: {customerName}</p>
              <p>רכב: {vehicleDetails}</p>
              <p>תאריך: {date}</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <input
                type="file"
                accept="image/*"
                capture="environment"
                multiple
                onChange={handleFileChange}
                className="hidden"
                id="photo-input"
              />
              <label htmlFor="photo-input" className="cursor-pointer">
                <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p className="text-lg font-medium mb-1">לחץ לצילום או העלאת תמונות</p>
                <p className="text-sm text-gray-500">צלם את הרכב מכל הזוויות</p>
              </label>
            </div>

            {photos.length > 0 && (
              <div>
                <h3 className="font-semibold mb-3">תמונות שהועלו ({photos.length})</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {photos.map((url, i) => (
                    <div key={i} className="relative aspect-square">
                      <img 
                        src={url} 
                        alt={`תמונה ${i + 1}`}
                        className="w-full h-full object-cover rounded-lg border"
                      />
                      <div className="absolute top-2 right-2 bg-green-500 text-white rounded-full p-1">
                        <Check className="w-4 h-4" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Button 
              onClick={handleComplete}
              disabled={photos.length === 0 || uploading}
              className="w-full bg-cyan-600 hover:bg-cyan-700 text-lg py-6"
            >
              {uploading ? "מעלה..." : "סיים והשלם"}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}