import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  FileText, 
  Mail, 
  CreditCard, 
  DollarSign, 
  CheckCircle, 
  Loader2,
  ArrowLeft,
  ArrowRight,
  Send
} from "lucide-react";
import { toast } from "react-hot-toast";
import { format } from "date-fns";

export default function RentalStartWizard({ booking, customer, vehicle, onComplete, onCancel, onEditBooking, readOnly = false }) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [signInPerson, setSignInPerson] = useState(true);
  const canvasRef = React.useRef(null);
  const [isDrawing, setIsDrawing] = React.useState(false);
  const [hasSignature, setHasSignature] = React.useState(false);

  // Reset signature when step changes
  React.useEffect(() => {
    setHasSignature(false);
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      }
    }
  }, [step]);
  const [data, setData] = useState({
    start_km: vehicle?.current_km || 0,
    start_time: format(new Date(), "HH:mm"),
    end_time: booking?.end_time || "",
    rental_cost: booking?.rental_cost || 0,
    contract_url: booking?.contract_url || "",
    declaration_url: booking?.declaration_url || "",
    waiver_url: booking?.waiver_url || "",
    contract_signed: booking?.contract_signed || false,
    declaration_signed: booking?.declaration_signed || false,
    waiver_signed: booking?.waiver_signed || false,
    credit_hold: booking?.credit_hold || 0,
    payment_method: booking?.payment_method || "אשראי",
    paid_amount: booking?.deposit_amount || 0,
    invoice_number: "",
    employee_phone: "",
    terms_accepted: false
  });

  const [showFullTerms, setShowFullTerms] = useState(false);

  React.useEffect(() => {
    if (canvasRef.current && signInPerson && (step === 2 || step === 3 || step === 4)) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
      }
    }
  }, [signInPerson, step]);

  const startDrawing = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    setIsDrawing(true);
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const draw = (e) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
    setHasSignature(true);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasSignature(false);
  };

  const saveSignature = async () => {
    setLoading(true);
    try {
      const canvas = canvasRef.current;
      const signatureData = canvas.toDataURL();
      let docUrl = signatureData;

      // Create PDF with signature embedded for all document types
      const tempDiv = document.createElement('div');
      tempDiv.style.position = 'absolute';
      tempDiv.style.right = '-9999px';
      tempDiv.style.width = '210mm';
      tempDiv.style.padding = '20mm';
      tempDiv.style.fontFamily = 'Arial, sans-serif';
      tempDiv.style.direction = 'rtl';
      tempDiv.style.backgroundColor = 'white';
      tempDiv.style.fontSize = '12px';
      tempDiv.style.lineHeight = '1.6';

      if (step === 2) {
        // Contract - Complete full version
        tempDiv.innerHTML = `
          <div style="text-align: center; margin-bottom: 10px;">
            <h1 style="font-size: 18px; margin: 0; font-weight: bold;">חוזה השכרת רכב</h1>
          </div>

          <div style="margin-bottom: 8px; font-size: 9px;">
            <h3 style="font-size: 11px; margin-bottom: 3px; font-weight: bold;">פרטי השוכר:</h3>
            <p style="margin: 1px 0;">שם: ${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</p>
            <p style="margin: 1px 0;">ת.ז: ${customer?.id_number || ''}</p>
            <p style="margin: 1px 0;">טלפון: ${customer?.phone || ''}</p>
          </div>

          <div style="margin-bottom: 8px; font-size: 9px;">
            <h3 style="font-size: 11px; margin-bottom: 3px; font-weight: bold;">פרטי הרכב:</h3>
            <p style="margin: 1px 0;">רכב: ${vehicle.manufacturer} ${vehicle.model}</p>
            <p style="margin: 1px 0;">מספר רישוי: ${vehicle.license_plate}</p>
          </div>

          <div style="margin-bottom: 8px; font-size: 9px;">
            <h3 style="font-size: 11px; margin-bottom: 3px; font-weight: bold;">פרטי ההשכרה:</h3>
            <p style="margin: 1px 0;">מתאריך: ${booking.start_date} עד: ${booking.end_date}</p>
            <p style="margin: 1px 0;">עלות: ${booking.rental_cost?.toLocaleString()} ש"ח</p>
          </div>

          <div style="margin-bottom: 8px; font-size: 8px; line-height: 1.3;">
            <h3 style="font-size: 10px; margin-bottom: 3px; font-weight: bold;">תנאים והגבלות:</h3>
            <p style="margin: 2px 0;"><strong>1.</strong> מורשה לנהוג רק נהג הרשום בחוזה ההשכרה. העברה או מסירת ההחזקה ברכב לנהג אחר מהווה הפרה יסודית של ההסכם ויחול בזה כל מה שנאמר בסעיף 8.</p>
            <p style="margin: 2px 0;"><strong>2.</strong> נהיגה ברכב בשבתות וחגי ישראל אסורה, ותגרור חיוב מלא בנזקים למשכיר. הדבר ייחשב כהפרה יסודית של ההסכם.</p>
            <p style="margin: 2px 0;"><strong>3.</strong> השוכר יישא באחריות מלאה לכל נזק הנובע מנהיגה רשלנית, פראית, בדרך לא סלולה או בניגוד לחוקי התעבורה, לרבות נזקים עקיפים כגון ימי השבתה כתוצאה מהחרמת הרכב ע"י המשטרה ו/או העמדתו במוסך.</p>
            <p style="margin: 2px 0;"><strong>4.</strong> בכול מקרה אין שום כיסוי ביטוחי ואינו כלול בגובה ההשתתפות העצמית כל נזק שיקרה בגג ו/או במרכב תחתון ו/או בגלגלים ו/או בצמיגים או בשמשות וכול ההוצאות חלות עליו ואינו כלול בביטוח כלשהו.</p>
            <p style="margin: 2px 0;"><strong>5.</strong> נסיעה תוך התעלמות מנורות אזהרה תחייב את הנהג בתשלום מלוא הנזק שנגרם!</p>
            <p style="margin: 2px 0;"><strong>6.</strong> השוכר אחראי באופן בלעדי לכל עבירת תנועה או חניה בתקופת ההשכרה. בגין טיפול בדוח תחויב עמלת טיפול בסך 100 ₪ + מע"מ. המשכירה אינה מתחייבת להסב דוחות או לעדכן את השוכר על דבר קיומם, והשוכר יישא בכל תשלום או נזק שייגרם למשכירה עקב כך, כולל ריביות, פיגורים ונזקים עקיפים.</p>
            <p style="margin: 2px 0;"><strong>7.</strong> בנסיעה בכבישי אגרה (לרבות כביש 6), יחויב השוכר בדמי טיפול של 45 ₪ + מע"מ עבור כל חשבונית, בנוסף לעלות האגרה עצמה.</p>
            <p style="margin: 2px 0;"><strong>8.</strong> השוכר מתחייב להחזיר את הרכב עם מיכל דלק מלא ולצרף חשבונית תדלוק הכוללת את מספר הרכב. אי-תדלוק מלא יחויב בעלות הדלק החסר ובתוספת של 80 ₪ + מע"מ.</p>
            <p style="margin: 2px 0;"><strong>9.</strong> החזרת הרכב באיחור של מעל 20 דקות מהמועד יחויב את השוכר בקנס של 50 ש''ח על כל שעה נוספת.</p>
            <p style="margin: 2px 0;"><strong>10.</strong> במקרה של תאונה או נזק, על השוכר להודיע מיד למשכירה ולהימנע מהמשך נסיעה ללא אישור. חובה לתעד את זירת האירוע ולמסור פרטים מזהים של כל המעורבים. הפרת סעיף זה – גם בתום לב – תיחשב כהפרת הסכם, והשוכר יישא באחריות מלאה לכל נזק שייגרם לרבות נזק ישיר או עקיף.</p>
            <p style="margin: 2px 0;"><strong>11.</strong> התניות בחוזה זה הינן התניות יסודיות והפרת כל אחד מהם תזכה את המשכירה בפיצויים מוסכמים מראש בסך 30,000 ₪ מבלי כל צורך בהוכחת נזק ומבלי לפגוע בזכותה של החברה לסעדים נוספים, ובנוסף השוכר ישא בכל הנזקים שיגרמו כתוצאה מכך ולא יהיה שום כיסוי ביטוחי באופן זה.</p>
            <p style="margin: 2px 0;"><strong>12.</strong> כל תיקון, שינוי מהותי או התערבות במבנה או במערכות הרכב, מכל סוג שהוא, שיבוצע על ידי השוכר או מטעמו, ללא אישור מראש ובכתב מהמשכירה – יהווה הפרה יסודית של ההסכם ויחויב בפיצויים כפי שמופיע בסעיף 8.</p>
            <p style="margin: 2px 0;"><strong>13.</strong> השוכר מצהיר שידוע לו כי במידה והחזרת הרכב תבוצע בשעות הלילה הרכב יבדק שוב בשעות הבוקר ומוסכם מראש כי מקבל הרכב נציג המשכירה נאמן בחוות דעתו בעניין זה.</p>
            <p style="margin: 2px 0;"><strong>14.</strong> בכל מקרה בו ייעשה שימוש ברכב שלא בהתאם להוראות חוזה זה ו/או לדין, לא יחול כל כיסוי נזקים, לרבות כיסויים שרכש השוכר או שכלולים בדמי השכירות, והשוכר יישא במלוא הנזק שייגרם לרכב, חלפיו וחלקיו (כולל בגין אבדן ו/או גניבה) ו/או לצד ג'.</p>
            <p style="margin: 2px 0;"><strong>15.</strong> השוכר נותן את הסכמתו לכך שהמשכירה תגבה כל תשלום שמגיע לה ע''פ הסכם זה באמצעות הכ.א. שמסר השוכר בעת לקיחת רכב, וזאת בלי הודעה מוקדמת או אישור מטעמו.</p>
            <p style="margin: 2px 0;"><strong>16.</strong> השוכר מודע לכך שבכל מקרה של תקלה או תאונה אין מחויבות למשכירה להעמיד רכב חילופי וכן לא יהיה על המשכירה תביעה על שום נזק שנגרם לשוכר כתוצאה מהתקלה, לרבות אך לא רק תשלום למונית או לאמצעי תחבורה אחר או כל דבר אחר שנגרם כתוצאה מכך.</p>
            <p style="margin: 2px 0;"><strong>17.</strong> אני מאשר כי קראתי והבנתי את ההסכם בשני צידי הדף ובנספחיו ואני מסכים ואני אחראי אישית לקיום כל ההתחייבויות ולכל התנאים עפ''י הסכם זה.</p>
          </div>

          <div style="margin: 8px 0; padding: 8px; background: #fff3cd; border: 1px solid #ffc107; font-size: 8px;">
            <p style="margin: 1px 0; font-weight: bold;">הוצע ללקוח רכישת ביטוח משלים בהשתתפות עצמית לתקרה של 2000 ש''ח תמורת תשלום נוסף, והוא סרב.</p>
            <p style="margin: 1px 0;">גובה השתתפות עצמית על נזקים או תאונות במקרה של ויתור ואי רכישת הביטוח המשלים - <strong>6,500 ₪</strong>, נהג חדש או מתחת לגיל 24 <strong>9,000 ש''ח</strong> לפני מע''מ.</p>
          </div>

          <div style="margin-top: 15px;">
            <p style="font-size: 9px; margin-bottom: 3px; font-weight: bold;">חתימת השוכר:</p>
            <img src="${signatureData}" style="max-width: 100px; height: auto;"/>
            <p style="margin-top: 5px; font-size: 8px;">${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</p>
            <p style="font-size: 8px;">${new Date().toLocaleDateString('he-IL')}</p>
          </div>
        `;
      } else if (step === 3) {
        // Waiver - Complete full version
        tempDiv.innerHTML = `
          <div style="text-align: center; margin-bottom: 12px;">
            <h1 style="font-size: 16px; margin: 0; font-weight: bold;">דרישה לחתימה על כתב ויתור מראש ובכתב</h1>
            <p style="font-size: 10px; margin: 5px 0;">שאינו הוראה מהוראות הסכם ההשכרה</p>
          </div>

          <p style="margin-bottom: 8px; font-size: 10px;"><strong>לכבוד: ע.מ. אוטופה השכרת רכב מקבוצת מ. אלימלך ישיר כאר ח.פ 515856920 (להלן ''החברה'').</strong></p>

          <p style="margin-bottom: 8px; font-size: 11px; font-weight: bold;">הנדון: כתב ויתור על כיסוי ביטוחי משלים והסכמה לגובה השתתפות עצמית על סך 6500 ש''ח (ששת אלפים וחמש מאות ש''ח) ובמקרה של נהג חדש או מתחת לגיל 24 9000 ש''ח פלוס מע''מ.</p>

          <p style="margin-bottom: 12px; font-size: 10px;">לחוזה השכרת רכב מיום <strong>${booking.start_date}</strong></p>

          <div style="font-size: 9px; line-height: 1.4;">
            <p style="margin: 6px 0;"><strong>1.</strong> אני החתום מטה: <strong>${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</strong> ת.ז <strong>${customer?.id_number || ''}</strong> מצהיר בזאת כי קראתי את חוזה ההשכרה של החברה במלואו וכי הבנתי את כל הכתוב בו.</p>
            
            <p style="margin: 6px 0;"><strong>2.</strong> הנני מצהיר כי בטרם חתמתי על חוזה ההשכרה הוצעו לי על ידי החברה לרכוש ביטוחים משלימים בנוסף לביטוח הקיים. וזאת לצורך העמדת גובה ההשתתפות העצמית על הסכום המרבי בהתאם לסעיף 1 לנוהל משרד התחבורה.</p>
            
            <p style="margin: 6px 0;"><strong>3.</strong> הנני מצהיר מסכים ומודיע כי אני מוותר מראש על רכישת מלא הכיסויים הביטוחיים שהוצעו לי, וזאת ביודעין שבמקרה ביטוחי אחויב בגובה ההשתתפות העצמית על סך 6500 ש''ח (ששת אלפים וחמש מאות ש''ח) ובמקרה של נהג חדש או מתחת לגיל 24 9000 ש''ח פלוס מע''מ והנני מוותר על טענתי לפיה מדובר בסכום הגבוה מהקבוע בנוהל דלעיל.</p>
            
            <p style="margin: 6px 0;"><strong>4.</strong> הנני מצהיר כי לאחר שקראתי, הבנתי שקלתי את כל הנתונים ולאחר שהוסברו לי ההשלכות של אי רכישת ביטוח משלים לצורך הפחתת גובה ההשתתפות העצמית החלטתי כי הנני מוותר מפורשות על כל ביטוח משלים זה או אחר והנני מאשר את גובה ההשתתפות העצמית שנקבעה על ידי חברת ההשכרה ואין ולא תהיינה לי כלפי חברת ההשכרה איזשהן טענות ו/או מענות ו/או דרישה כספית ו/או שאינה כספית בגין גובה ההשתתפות העצמית. והנני מוותר בזאת על כל תביעה או דרישה או קובלנה עתידית נגד החברה בעניין זה.</p>
            
            <p style="margin: 6px 0;"><strong>5.</strong> הנני מצהיר כי בטרם חתמתי על חוזה ההשכרה הובהר בפני נוהל משרד התחבורה מיום 6.5.2009 עניין ההשתתפות העצמית של כלי רכב המיועדים להשכרה, והנני מצהיר כי הבנתי את האמור בו וכי הנני מבין את משמעותו.</p>
            
            <p style="margin: 6px 0;"><strong>6.</strong> כתב וויתור זה יחול על חוזה ההשכרה הרשום לעיל ועל כל חוזה שכירות אחר שנובע מתוקף חוזה שכירות זה לרבות הארכת מועד החזרת הרכב ו/או החלפה לרכב אחר ו/או חלופי, וכן יחול על כל המתחייב בחוזה זה או בחוזה אחר הנובע מתוקף חוזה זה.</p>
            
            <p style="margin: 6px 0;"><strong>7.</strong> הנני מצהיר כי קראתי הבנתי ואישרתי האמור בכתב ויתור זה.</p>
            
            <p style="margin: 6px 0;"><strong>8.</strong> ולראיה באתי על החתום:</p>
          </div>

          <div style="margin-top: 25px;">
            <p style="font-size: 10px; margin-bottom: 5px;"><strong>שם מלא: ${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</strong></p>
            <p style="font-size: 10px; margin-bottom: 5px;"><strong>ת.ז: ${customer?.id_number || ''}</strong></p>
            <p style="font-size: 10px; margin-bottom: 5px;"><strong>חתימה:</strong></p>
            <img src="${signatureData}" style="max-width: 120px; height: auto;"/>
            <p style="margin-top: 8px; font-size: 9px;">${new Date().toLocaleDateString('he-IL')}</p>
          </div>
        `;
      } else if (step === 4) {
        // Declaration - Complete full version
        tempDiv.innerHTML = `
          <div style="text-align: center; margin-bottom: 15px;">
            <h1 style="font-size: 16px; margin: 0; font-weight: bold;">הצהרת נהג / אישור קבלת רכב השכרה</h1>
          </div>

          <div style="margin-bottom: 12px; font-size: 10px; line-height: 1.6;">
            <p style="margin: 5px 0;">אני הח"מ <strong>${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</strong> מספר ת.ז/דרכון <strong>${customer?.id_number || ''}</strong></p>
            
            <p style="margin: 5px 0;">מצהיר/ה ומאשר/ת בזאת כי ביום <strong>${booking.start_date}</strong> שעה <strong>${data.start_time || "______"}</strong></p>
            
            <p style="margin: 5px 0;">ועד יום <strong>${booking.end_date}</strong> בשעה <strong>${booking.end_time || "______"}</strong></p>
            
            <p style="margin: 5px 0;">אני עדין עומד לרשות חברת מ.אלימלך ריש קאר בע"מ</p>
            
            <p style="margin: 5px 0;">במידה והחזירו אותי אחר מועד זה (להלן תקופת השימוש)</p>
            
            <p style="margin: 8px 0;">ניתנה לי זכות שימוש ברכב מסוג <strong>${vehicle.manufacturer} ${vehicle.model}</strong> מספר רישוי <strong>${vehicle.license_plate}</strong></p>
            
            <p style="margin: 8px 0;">אני מצהיר בזאת כי הנני מקבל אחריות מלאה על נזק ו/או אובדן/גניבה מכל סוג שהוא לרכב ו/או לכלי תשלום הנדרשים מכח בטחון</p>
            
            <p style="margin: 8px 0;">מאשר בזאת לחברת מ.אלימלך ריש קאר בע"מ</p>
          </div>

          <div style="margin-top: 30px;">
            <p style="font-size: 11px; margin-bottom: 5px;"><strong>שם מלא: ${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</strong></p>
            
            <p style="font-size: 11px; margin-bottom: 5px; margin-top: 15px;"><strong>חתימה:</strong></p>
            <img src="${signatureData}" style="max-width: 120px; height: auto;"/>
            
            <p style="font-size: 10px; margin-top: 15px;"><strong>ת"ז: ${customer?.id_number || ''}</strong></p>
            
            <p style="font-size: 9px; margin-top: 10px;">${new Date().toLocaleDateString('he-IL')}</p>
          </div>
        `;
      }

      if (step === 2 || step === 3 || step === 4) {
        document.body.appendChild(tempDiv);

        // Capture the div as image
        const canvasImg = await html2canvas(tempDiv, {
          scale: 2,
          useCORS: true,
          logging: false
        });

        document.body.removeChild(tempDiv);

        // Create PDF and add the image
        const doc = new jsPDF('p', 'mm', 'a4');
        const imgData = canvasImg.toDataURL('image/png');
        const imgWidth = 210;
        const imgHeight = (canvasImg.height * imgWidth) / canvasImg.width;

        doc.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);

        const pdfBlob = doc.output("blob");
        const fileName = step === 2 ? "contract_signed.pdf" : step === 3 ? "waiver_signed.pdf" : "declaration_signed.pdf";
        const pdfFile = new File([pdfBlob], fileName, { type: "application/pdf" });
        const uploadResult = await base44.integrations.Core.UploadFile({ file: pdfFile });
        docUrl = uploadResult.file_url;
      }

      if (step === 2) {
        setData({ ...data, contract_signed: true, contract_url: docUrl });
        clearSignature();
        setLoading(false);
        setStep(3);
        return;
      } else if (step === 3) {
        setData({ ...data, waiver_signed: true, waiver_url: docUrl });
        clearSignature();
        setLoading(false);
        setStep(4);
        return;
      } else if (step === 4) {
        setData({ ...data, declaration_signed: true, declaration_url: docUrl });
        clearSignature();
        setLoading(false);
        setStep(5);
        return;
      }
    } catch (error) {
      console.error('Error saving signature:', error);
      toast.error("שגיאה בשמירת חתימה");
    } finally {
      clearSignature();
      setLoading(false);
    }
  };

  const generateAndSendContract = async () => {
    setLoading(true);
    try {
      // Create PDF
      const doc = new jsPDF();
      
      // Add Hebrew font support
      doc.setR2L(true);
      doc.setLanguage("he");
      
      let y = 20;
      
      // Title
      doc.setFontSize(20);
      doc.text("חוזה השכרת רכב", 105, y, { align: "center" });
      y += 15;
      
      // Customer details
      doc.setFontSize(14);
      doc.text("פרטי השוכר:", 190, y, { align: "right" });
      y += 8;
      doc.setFontSize(11);
      doc.text(`שם: ${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}`, 190, y, { align: "right" });
      y += 6;
      doc.text(`ת.ז: ${customer?.id_number || ''}`, 190, y, { align: "right" });
      y += 6;
      doc.text(`טלפון: ${customer?.phone || ''}`, 190, y, { align: "right" });
      y += 10;
      
      // Vehicle details
      doc.setFontSize(14);
      doc.text("פרטי הרכב:", 190, y, { align: "right" });
      y += 8;
      doc.setFontSize(11);
      doc.text(`רכב: ${vehicle.manufacturer} ${vehicle.model}`, 190, y, { align: "right" });
      y += 6;
      doc.text(`מספר רישוי: ${vehicle.license_plate}`, 190, y, { align: "right" });
      y += 10;
      
      // Rental details
      doc.setFontSize(14);
      doc.text("פרטי ההשכרה:", 190, y, { align: "right" });
      y += 8;
      doc.setFontSize(11);
      doc.text(`מתאריך: ${booking.start_date}`, 190, y, { align: "right" });
      y += 6;
      doc.text(`עד תאריך: ${booking.end_date}`, 190, y, { align: "right" });
      y += 6;
      doc.text(`עלות: ${booking.rental_cost?.toLocaleString()} ש"ח`, 190, y, { align: "right" });
      y += 12;
      
      // Terms
      doc.setFontSize(14);
      doc.text("תנאי החוזה:", 190, y, { align: "right" });
      y += 8;
      doc.setFontSize(10);
      const terms = [
        "1. מורשה לנהוג רק נהג הרשום בחוזה ההשכרה",
        "2. השוכר יישא באחריות מלאה לכל נזק הנובע מנהיגה רשלנית",
        "3. השוכר אחראי לכל עבירת תנועה או חניה בתקופת ההשכרה",
        "4. במקרה של תאונה או נזק - הודעה מיידית למשכירה",
        "5. השתתפות עצמית: 6,500 ש\"ח"
      ];
      
      terms.forEach(term => {
        if (y > 270) {
          doc.addPage();
          y = 20;
        }
        doc.text(term, 190, y, { align: "right" });
        y += 7;
      });
      
      // Signature area
      y += 15;
      if (y > 250) {
        doc.addPage();
        y = 20;
      }
      doc.setFontSize(12);
      doc.text("מקום לחתימה:", 190, y, { align: "right" });
      y += 15;
      doc.line(40, y, 170, y);
      y += 8;
      doc.setFontSize(10);
      doc.text(new Date().toLocaleDateString('he-IL'), 105, y, { align: "center" });
      
      // Save PDF as blob
      const pdfBlob = doc.output("blob");
      const pdfFile = new File([pdfBlob], "contract.pdf", { type: "application/pdf" });
      
      // Upload PDF
      const uploadResult = await base44.integrations.Core.UploadFile({ file: pdfFile });
      const pdfUrl = uploadResult.file_url;
      
      const signatureLink = `${window.location.origin}/sign?type=contract&id=${booking.id}&doc=${encodeURIComponent(pdfUrl)}`;

      await base44.integrations.Core.SendEmail({
        to: customer?.email || customer?.phone || "",
        subject: `חוזה השכרת רכב - ${vehicle.manufacturer} ${vehicle.model}`,
        body: `שלום ${customer?.first_name || booking.customer_name.split(' ')[0]},

      מצורף חוזה השכרת הרכב לחתימה דיגיטלית.

לחתימה על החוזה, לחץ על הקישור הבא:
${signatureLink}

בברכה,
צוות ניהול השכרת רכב`
      });

      setData({ ...data, contract_url: pdfUrl });
      toast.success("החוזה נשלח ללקוח בהצלחה");
    } catch (error) {
      console.error(error);
      toast.error("שגיאה בשליחת החוזה");
    } finally {
      setLoading(false);
    }
  };

  const generateAndSendDeclaration = async () => {
    setLoading(true);
    try {
      const declarationHtml = `
<!DOCTYPE html>
<html dir="rtl">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; padding: 40px; line-height: 1.8; }
    h1 { text-align: center; color: #1e3a5f; }
    .info { background: #f0f0f0; padding: 20px; margin: 20px 0; border-radius: 8px; }
    .signature-box { border: 2px dashed #ccc; padding: 40px; margin-top: 40px; text-align: center; }
  </style>
</head>
<body>
  <h1>הצהרת נהג / אישור קבלת רכב השכרה</h1>
  
  <div class="info">
    <p>אני הח"מ <strong>${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</strong></p>
    <p>מספר ת.ז/דרכון: <strong>${customer?.id_number || ''}</strong></p>
    <p>מצהיר/ה ומאשר/ת באת לי מיום <strong>${booking.start_date}</strong></p>
    <p>בשעה <strong>${booking.start_time || "______"}</strong></p>
    <p>ועד יום <strong>${booking.end_date}</strong> בשעה <strong>${booking.end_time || "______"}</strong></p>
  </div>

  <div class="info">
    <p>מס' רכב: <strong>${vehicle.license_plate}</strong></p>
    <p>פרטי השוכר: <strong>${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</strong></p>
    <p>מספר רישיון: <strong>______</strong></p>
  </div>

  <div class="info">
    <h3>פרטי השכרה:</h3>
    <p>תאריך יציאה: <strong>${booking.start_date}</strong> שעת היציאה: <strong>${booking.start_time || "______"}</strong></p>
    <p>תאריך החזרה: <strong>${booking.end_date}</strong> שעת החזרה: <strong>${booking.end_time || "______"}</strong></p>
    <p>סך ק"מ המותר לנסיעה: <strong>${vehicle.km_limit || "______"}</strong> מחיר: <strong>______</strong></p>
  </div>

  <p>נותנה לי זכות שימוש ברכב מסוג <strong>${vehicle.manufacturer} ${vehicle.model}</strong></p>
  <p>מספר רישוי <strong>${vehicle.license_plate}</strong></p>
  <p>אני מצהיר בזאת כי הנני מקבל/ת אחריות מלאה על כוח דין (היינה/תעבורה/קנס משטרתי)</p>
  <p>אני מצהיר בזאת כי הנני מקבל/ת ואו אחראי מחוייב לתשלומים</p>
  <p>לרבות כבל קנס ו/או חיוב השלומים</p>
  <p>הנדרשים ממנה כברח אגרה</p>
  <p>מאשר באת לחבר ת.מ.אלימלך ישיר קאר בע"מ</p>

  <div class="signature-box">
    <p><strong>שם מלא: ______________________</strong></p>
    <p><strong>חתימה: ______________________</strong></p>
    <p><strong>מייל: ______________________</strong></p>
  </div>

  <p style="margin-top: 40px; text-align: center;">
    <strong>בברכה,<br>חברת ת.מ.אלימלך ישיר קאר בע"מ</strong>
  </p>
</body>
</html>`;

      const signatureLink = `${window.location.origin}/sign?type=declaration&id=${booking.id}`;

      await base44.integrations.Core.SendEmail({
        to: customer?.email || customer?.phone || "",
        subject: `תצהיר קבלת רכב - ${vehicle.manufacturer} ${vehicle.model}`,
        body: `שלום ${customer?.first_name || booking.customer_name.split(' ')[0]},

      מצורף תצהיר קבלת הרכב.

${declarationHtml}

לחתימה על התצהיר, לחץ על הקישור הבא:
${signatureLink}

בברכה,
צוות ניהול השכרת רכב`
      });

      setData({ ...data, declaration_url: signatureLink });
      toast.success("התצהיר נשלח ללקוח בהצלחה");
    } catch (error) {
      console.error(error);
      toast.error("שגיאה בשליחת התצהיר");
    } finally {
      setLoading(false);
    }
  };

  const generateAndSendWaiver = async () => {
    setLoading(true);
    try {
      const waiverHtml = `
<!DOCTYPE html>
<html dir="rtl">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; padding: 40px; line-height: 1.8; }
    h1 { text-align: center; color: #1e3a5f; }
    .section { margin: 20px 0; }
    .signature-box { border: 2px dashed #ccc; padding: 40px; margin-top: 40px; text-align: center; }
  </style>
</head>
<body>
  <h1>דרישה לחתימה על כתב ויתור מראש ובכתב</h1>
  
  <p><strong>לכבוד: ע.מ. אוטופה השכרת רכב מקבוצת מ. אלימלך ישיר כאר ח.פ 515856920</strong></p>

  <h3>הנדון: כתב ויתור על כיסוי ביטוחי משלים והסכמה לגובה השתתפות עצמית על סך 6500 ש"ח</h3>
  <p>(ששת אלפים וחמש מאות ש"ח) ובמקרה של נהג חדש או מתחת לגיל 24 9000 ש"ח פלוס מע"מ.</p>

  <p>לחוזה השכרת רכב מיום <strong>${booking.start_date}</strong></p>

  <div class="section">
    <p>1. אני החתום מטה: <strong>${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</strong> ת.ז <strong>${customer?.id_number || ''}</strong> מצהיר בזאת כי קראתי את חוזה ההשכרה של החברה במלואו וכי הבנתי את כל הכתוב בו.</p>

    <p>2. הנני מצהיר כי בטרם חתמתי על חוזה ההשכרה הוצעו לי על ידי החברה לרכוש ביטוחים משלימים בנוסף לביטוח הקיים. וזאת לצורך העמדת גובה ההשתתפות העצמית על הסכום המרבי בהתאם לסעיף 1 לנוהל משרד התחבורה.</p>

    <p>3. הנני מצהיר מסכים ומודיע כי אני מוותר מראש על רכישת מלא הכיסויים הביטוחיים שהוצעו לי, וזאת ביודעין שבמקרה ביטוחי אחויב בגובה ההשתתפות העצמית על סך 6500 ש"ח (ששת אלפים וחמש מאות ש"ח) ובמקרה של נהג חדש או מתחת לגיל 24 9000 ש"ח פלוס מע"מ.</p>

    <p>4. הנני מצהיר כי לאחר שקראתי, הבנתי שקלתי את כל הנתונים ולאחר שהוסברו לי ההשלכות של אי רכישת ביטוח משלים לצורך הפחתת גובה ההשתתפות העצמית החלטתי כי הנני מוותר מפורשות על כל ביטוח משלים.</p>

    <p>5. הנני מצהיר כי בטרם חתמתי על חוזה ההשכרה הובהר בפני נוהל משרד התחבורה מיום 6.5.2009 עניין ההשתתפות העצמית של כלי רכב המיועדים להשכרה.</p>

    <p>6. כתב וויתור זה יחול על חוזה ההשכרה הרשום לעיל ועל כל חוזה שכירות אחר שנובע מתוקף חוזה שכירות זה.</p>

    <p>7. הנני מצהיר כי קראתי הבנתי ואישרתי האמור בכתב ויתור זה.</p>
  </div>

  <div class="signature-box">
    <p><strong>שם מלא: ${customer?.first_name || booking.customer_name} ${customer?.last_name || ''}</strong></p>
    <p><strong>חתימה (חותמת אם נדרש): ______________________</strong></p>
    <p><strong>תאריך: ${new Date().toLocaleDateString('he-IL')}</strong></p>
  </div>
</body>
</html>`;

      const signatureLink = `${window.location.origin}/sign?type=waiver&id=${booking.id}`;

      await base44.integrations.Core.SendEmail({
        to: customer?.email || customer?.phone || "",
        subject: `כתב ויתור - השכרת רכב ${vehicle.manufacturer} ${vehicle.model}`,
        body: `שלום ${customer?.first_name || booking.customer_name.split(' ')[0]},

      מצורף כתב ויתור על כיסוי ביטוחי משלים.

${waiverHtml}

לחתימה על כתב הויתור, לחץ על הקישור הבא:
${signatureLink}

בברכה,
צוות ניהול השכרת רכב`
      });

      setData({ ...data, waiver_url: signatureLink });
      toast.success("כתב הויתור נשלח ללקוח בהצלחה");
    } catch (error) {
      console.error(error);
      toast.error("שגיאה בשליחת כתב הויתור");
    } finally {
      setLoading(false);
    }
  };

  const handleComplete = async () => {
    setLoading(true);
    try {
      // Get current user to fetch employee phone
      const currentUser = await base44.auth.me();
      const employeePhone = currentUser.employee_phone;

      // Create rental
      const rentalData = {
        booking_id: booking.id,
        customer_id: booking.customer_id,
        customer_name: booking.customer_name,
        vehicle_id: booking.vehicle_id,
        vehicle_details: booking.vehicle_details,
        start_date: booking.start_date,
        start_time: data.start_time,
        start_km: data.start_km,
        planned_end_date: booking.end_date,
        planned_end_time: data.end_time,
        base_cost: data.rental_cost,
        total_cost: data.rental_cost,
        paid_amount: data.paid_amount,
        remaining_payment: data.rental_cost - data.paid_amount,
        credit_hold: data.credit_hold,
        payment_method: data.payment_method,
        invoice_number: data.invoice_number,
        status: "פעיל"
      };

      const rental = await base44.entities.Rental.create(rentalData);

      // Send vehicle photos link to employee phone if configured
      if (employeePhone) {
        const photoLink = `${window.location.origin}/vehicle-photos?rental=${rental.id}&customer=${encodeURIComponent(booking.customer_name)}&vehicle=${encodeURIComponent(booking.vehicle_details)}&date=${booking.start_date}`;
        
        await base44.integrations.Core.SendEmail({
          to: employeePhone,
          subject: "צילום תמונות רכב - השכרה חדשה",
          body: `שלום,\n\nנא לצלם את הרכב לפני מסירה ללקוח:\n\nלקוח: ${booking.customer_name}\nרכב: ${booking.vehicle_details}\n\nקישור לצילום:\n${photoLink}\n\nבהצלחה!`
        });
      }

      // Update booking
      await base44.entities.Booking.update(booking.id, { 
        status: "פעיל",
        start_time: data.start_time,
        end_time: data.end_time,
        contract_url: data.contract_url,
        contract_signed: data.contract_signed,
        declaration_url: data.declaration_url,
        declaration_signed: data.declaration_signed,
        waiver_url: data.waiver_url,
        waiver_signed: data.waiver_signed,
        credit_hold: data.credit_hold
      });

      // Update vehicle
      await base44.entities.Vehicle.update(booking.vehicle_id, { 
        status: "מושכר",
        current_km: data.start_km
      });

      // Create income record
      if (data.paid_amount > 0) {
        await base44.entities.Income.create({
          customer_id: booking.customer_id,
          customer_name: booking.customer_name,
          rental_id: rental.id,
          vehicle_id: booking.vehicle_id,
          amount: data.paid_amount,
          date: booking.start_date,
          type: "השכרה",
          payment_method: data.payment_method,
          invoice_number: data.invoice_number
        });
      }

      toast.success("ההשכרה התחילה בהצלחה!");
      
      // Wait a bit for the toast to show, then close
      setTimeout(() => {
        onComplete();
      }, 500);
    } catch (error) {
      console.error("Error starting rental:", error);
      toast.error(`שגיאה בתחילת ההשכרה: ${error.message || 'שגיאה לא ידועה'}`);
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Progress */}
      <div className="flex items-center justify-between">
        {["פרטים", "חוזה", "ויתור", "תצהיר", "תשלום", "סיכום"].map((s, i) => (
          <div key={i} className="flex items-center">
            <div className={`
              w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium
              ${step > i + 1 ? 'bg-green-600 text-white' : step === i + 1 ? 'bg-cyan-600 text-white' : 'bg-gray-200 text-gray-500'}
            `}>
              {step > i + 1 ? <CheckCircle className="w-4 h-4" /> : i + 1}
            </div>
            <span className={`mr-1 text-xs ${step >= i + 1 ? 'text-gray-900' : 'text-gray-400'}`}>{s}</span>
            {i < 5 && <div className="w-6 h-0.5 bg-gray-200 mx-1" />}
          </div>
        ))}
      </div>

      {/* Step 1: Details */}
      {step === 1 && (
        <div className="space-y-4">
          <Card className="p-4 bg-gray-50">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span className="text-gray-500">לקוח:</span>
                <p className="font-medium">{customer?.first_name || booking.customer_name} {customer?.last_name || ''}</p>
              </div>
              <div>
                <span className="text-gray-500">רכב:</span>
                <p className="font-medium">{vehicle.manufacturer} {vehicle.model}</p>
              </div>
              <div>
                <span className="text-gray-500">תאריכים:</span>
                <p className="font-medium">{booking.start_date} עד {booking.end_date}</p>
              </div>
              <div>
                <span className="text-gray-500">עלות:</span>
                <p className="font-medium">₪{data.rental_cost?.toLocaleString()}</p>
              </div>
            </div>
          </Card>

          {!readOnly && (
            <div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  if (confirm("האם לחזור לעריכת ההזמנה?")) {
                    if (onEditBooking) {
                      onEditBooking();
                    } else {
                      onCancel();
                    }
                  }
                }}
                className="w-full text-orange-600 border-orange-300"
              >
                שנה לקוח או ביטול הזמנה
              </Button>
            </div>
          )}

          <div>
            <Label>עלות השכרה</Label>
            <Input
              type="number"
              value={data.rental_cost}
              onChange={(e) => setData({ ...data, rental_cost: parseFloat(e.target.value) || 0 })}
              disabled={readOnly}
            />
          </div>

          <div>
            <Label>ק"מ התחלה</Label>
            <Input
              type="number"
              value={data.start_km}
              onChange={(e) => setData({ ...data, start_km: parseInt(e.target.value) || 0 })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>שעת לקיחה</Label>
              <Input
                type="time"
                value={data.start_time}
                onChange={(e) => setData({ ...data, start_time: e.target.value })}
              />
            </div>
            <div>
              <Label>שעת החזרה</Label>
              <Input
                type="time"
                value={data.end_time}
                onChange={(e) => setData({ ...data, end_time: e.target.value })}
              />
            </div>
          </div>

          <Button onClick={() => setStep(2)} className="w-full bg-cyan-600">
            המשך לחוזה
            <ArrowLeft className="w-4 h-4 mr-2" />
          </Button>
        </div>
      )}

      {/* Step 2: Contract */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="flex items-center justify-center gap-4 mb-4">
            <Button
              variant={signInPerson ? "default" : "outline"}
              onClick={() => setSignInPerson(true)}
              className={signInPerson ? "bg-cyan-600" : ""}
            >
              חתימה במקום
            </Button>
            <Button
              variant={!signInPerson ? "default" : "outline"}
              onClick={() => setSignInPerson(false)}
              className={!signInPerson ? "bg-cyan-600" : ""}
            >
              שליחה ללקוח
            </Button>
          </div>

          <div className="text-center p-6 bg-blue-50 rounded-lg">
            <FileText className="w-12 h-12 text-blue-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">חוזה השכרה</h3>
            <p className="text-sm text-gray-600 mb-4">
              {signInPerson 
                ? "הלקוח יחתום על 3 מסמכים במקום"
                : "המערכת תייצר חוזה מותאם אישית ותשלח אותו ללקוח לחתימה דיגיטלית"}
            </p>
            
            {signInPerson ? (
              data.contract_signed ? (
                <div className="space-y-3">
                  <div className="p-3 bg-green-100 text-green-800 rounded-lg text-sm">
                    ✓ החוזה נחתם
                  </div>
                  <Button 
                    variant="outline"
                    onClick={() => setData({ ...data, contract_signed: false })}
                  >
                    חתום מחדש
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="border rounded-lg p-4 bg-white max-h-96 overflow-y-auto text-right text-sm mb-4">
                    <h2 className="text-xl font-bold text-center mb-4">חוזה השכרת רכב</h2>
                    
                    <div className="space-y-3">
                      <div>
                        <h3 className="font-semibold mb-2">פרטי השוכר:</h3>
                        <p>שם: {customer?.first_name || booking.customer_name} {customer?.last_name || ''}</p>
                        <p>ת.ז: {customer?.id_number || ''}</p>
                        <p>טלפון: {customer?.phone || ''}</p>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold mb-2">פרטי הרכב:</h3>
                        <p>רכב: {vehicle.manufacturer} {vehicle.model}</p>
                        <p>מספר רישוי: {vehicle.license_plate}</p>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold mb-2">פרטי ההשכרה:</h3>
                        <p>מתאריך: {booking.start_date}</p>
                        <p>עד תאריך: {booking.end_date}</p>
                        <p>עלות: {booking.rental_cost?.toLocaleString()} ש"ח</p>
                      </div>
                      
                      <div>
                        <h3 className="font-semibold mb-2">תנאים והגבלות:</h3>
                        <div className="bg-gray-50 p-3 rounded max-h-40 overflow-y-auto text-xs">
                          <p>1. מורשה לנהוג רק נהג הרשום בחוזה ההשכרה</p>
                          <p>2. נהיגה בשבתות וחגי ישראל אסורה</p>
                          <p>3. השוכר יישא באחריות מלאה לכל נזק הנובע מנהיגה רשלנית</p>
                          <p>4. אין כיסוי ביטוחי לנזקים בגג, מרכב תחתון, גלגלים, צמיגים ושמשות</p>
                          <p>5. השוכר אחראי לכל עבירת תנועה או חניה - עמלת טיפול 100₪</p>
                          {showFullTerms && (
                            <>
                              <p>6. נסיעה בכבישי אגרה - דמי טיפול 45₪ לחשבונית</p>
                              <p>7. החזרת רכב עם מיכל דלק מלא - אחרת חיוב 80₪</p>
                              <p>8. איחור בהחזרה - 50₪ לשעה</p>
                              <p>9. תאונה - הודעה מיידית למשכירה</p>
                              <p>10. הפרת תנאי החוזה - פיצוי 30,000₪</p>
                              <p>11. השתתפות עצמית: 6,500 ש"ח (נהג חדש/מתחת לגיל 24: 9,000₪)</p>
                            </>
                          )}
                        </div>
                        <Button 
                          variant="link" 
                          size="sm"
                          onClick={() => setShowFullTerms(!showFullTerms)}
                          className="text-blue-600 mt-1"
                        >
                          {showFullTerms ? "הסתר תנאים מלאים" : "הצג תנאים מלאים"}
                        </Button>
                      </div>

                      <div className="flex items-center gap-2 bg-yellow-50 p-3 rounded border border-yellow-200">
                        <Checkbox
                          id="terms"
                          checked={data.terms_accepted}
                          onCheckedChange={(c) => setData({ ...data, terms_accepted: c })}
                        />
                        <Label htmlFor="terms" className="text-sm font-medium cursor-pointer">
                          אני מאשר שקראתי והבנתי את כל התנאים וההגבלות
                        </Label>
                      </div>
                      </div>
                      </div>

                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 bg-white">
                      <p className="text-sm text-gray-600 mb-2">חתמו כאן:</p>
                    <canvas
                      ref={canvasRef}
                      width={400}
                      height={200}
                      className="border border-gray-300 rounded cursor-crosshair mx-auto"
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                    />
                    <div className="flex gap-2 mt-3 justify-center">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={clearSignature}
                        disabled={!hasSignature}
                      >
                        נקה
                      </Button>
                      <Button 
                        size="sm"
                        onClick={saveSignature}
                        disabled={!hasSignature || !data.terms_accepted}
                        className="bg-blue-600"
                      >
                        שמור חתימה
                      </Button>
                      </div>
                      </div>
                      {!data.terms_accepted && (
                      <p className="text-xs text-red-600 text-center">יש לאשר את התנאים וההגבלות</p>
                      )}
                      </div>
                      )
                      ) : !data.contract_url ? (
              <Button 
                onClick={generateAndSendContract}
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                    יוצר ושולח...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 ml-2" />
                    צור ושלח חוזה
                  </>
                )}
              </Button>
            ) : (
              <div className="space-y-3">
                <div className="p-3 bg-green-100 text-green-800 rounded-lg text-sm">
                  ✓ החוזה נשלח ללקוח
                </div>
                <div className="flex items-center gap-2 justify-center">
                  <Checkbox
                    id="contract-signed"
                    checked={data.contract_signed}
                    onCheckedChange={(c) => setData({ ...data, contract_signed: c })}
                  />
                  <Label htmlFor="contract-signed">החוזה נחתם</Label>
                </div>
              </div>
            )}
            </div>

            <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep(1)}>
              <ArrowRight className="w-4 h-4 ml-2" />
              חזרה
            </Button>
            <Button 
              onClick={() => setStep(3)}
              disabled={!data.contract_signed}
              className="flex-1 bg-cyan-600"
            >
              המשך לכתב ויתור
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
            </div>
        </div>
      )}

      {/* Step 3: Waiver */}
      {step === 3 && (
        <div className="space-y-4">
          <div className="text-center p-6 bg-red-50 rounded-lg">
            <FileText className="w-12 h-12 text-red-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">כתב ויתור על ביטוח משלים</h3>
            <p className="text-sm text-gray-600 mb-4">
              כתב ויתור המאשר את גובה ההשתתפות העצמית
            </p>

            {signInPerson ? (
              data.waiver_signed ? (
                <div className="space-y-3">
                  <div className="p-3 bg-green-100 text-green-800 rounded-lg text-sm">
                    ✓ כתב הויתור נחתם
                  </div>
                  <Button 
                    variant="outline"
                    onClick={() => setData({ ...data, waiver_signed: false })}
                  >
                    חתום מחדש
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="border rounded-lg p-4 bg-white max-h-96 overflow-y-auto text-right text-sm mb-4">
                    <h2 className="text-xl font-bold text-center mb-4">כתב ויתור על כיסוי ביטוחי משלים</h2>
                    
                    <div className="space-y-3">
                      <p className="font-semibold text-center">לכבוד: ע.מ. אוטופה השכרת רכב מקבוצת מ. אלימלך ישיר כאר ח.פ 515856920</p>
                      
                      <h3 className="font-semibold text-sm mt-4">הנדון: כתב ויתור על כיסוי ביטוחי משלים והסכמה לגובה השתתפות עצמית על סך 6500 ש"ח</h3>
                      <p className="text-xs">(ששת אלפים וחמש מאות ש"ח) ובמקרה של נהג חדש או מתחת לגיל 24 - 9000 ש"ח פלוס מע"מ.</p>
                      
                      <p className="mt-3">לחוזה השכרת רכב מיום <strong>{booking.start_date}</strong></p>
                      
                      <div className="space-y-2 mt-4 text-xs">
                        <p><strong>1.</strong> אני החתום מטה: <strong>{customer?.first_name || booking.customer_name} {customer?.last_name || ''}</strong> ת.ז <strong>{customer?.id_number || ''}</strong> מצהיר בזאת כי קראתי את חוזה ההשכרה של החברה במלואו וכי הבנתי את כל הכתוב בו.</p>
                        
                        <p><strong>2.</strong> הנני מצהיר כי בטרם חתמתי על חוזה ההשכרה הוצעו לי על ידי החברה לרכוש ביטוחים משלימים בנוסף לביטוח הקיים. וזאת לצורך העמדת גובה ההשתתפות העצמית על הסכום המרבי בהתאם לסעיף 1 לנוהל משרד התחבורה.</p>
                        
                        <p><strong>3.</strong> הנני מצהיר מסכים ומודיע כי אני מוותר מראש על רכישת מלא הכיסויים הביטוחיים שהוצעו לי, וזאת ביודעין שבמקרה ביטוחי אחויב בגובה ההשתתפות העצמית על סך 6500 ש"ח (ששת אלפים וחמש מאות ש"ח) ובמקרה של נהג חדש או מתחת לגיל 24 - 9000 ש"ח פלוס מע"מ והנני מוותר על טענתי לפיה מדובר בסכום הגבוה מהקבוע בנוהל דלעיל.</p>
                        
                        <p><strong>4.</strong> הנני מצהיר כי לאחר שקראתי, הבנתי שקלתי את כל הנתונים ולאחר שהוסברו לי ההשלכות של אי רכישת ביטוח משלים לצורך הפחתת גובה ההשתתפות העצמית החלטתי כי הנני מוותר מפורשות על כל ביטוח משלים זה או אחר והנני מאשר את גובה ההשתתפות העצמית שנקבעה על ידי חברת ההשכרה ואין ולא תהיינה לי כלפי חברת ההשכרה איזשהן טענות ו/או מענות ו/או דרישה כספית ו/או שאינה כספית בגין גובה ההשתתפות העצמית.</p>
                        
                        <p><strong>5.</strong> הנני מצהיר כי בטרם חתמתי על חוזה ההשכרה הובהר בפני נוהל משרד התחבורה מיום 6.5.2009 עניין ההשתתפות העצמית של כלי רכב המיועדים להשכרה, והנני מצהיר כי הבנתי את האמור בו וכי הנני מבין את משמעותו.</p>
                        
                        <p><strong>6.</strong> כתב וויתור זה יחול על חוזה ההשכרה הרשום לעיל ועל כל חוזה שכירות אחר שנובע מתוקף חוזה שכירות זה לרבות הארכת מועד החזרת הרכב ו/או החלפה לרכב אחר ו/או חלופי, וכן יחול על כל המתחייב בחוזה זה או בחוזה אחר הנובע מתוקף חוזה זה.</p>
                        
                        <p><strong>7.</strong> הנני מצהיר כי קראתי הבנתי ואישרתי האמור בכתב ויתור זה.</p>
                      </div>
                    </div>
                  </div>

                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 bg-white">
                    <p className="text-sm text-gray-600 mb-2">חתמו כאן:</p>
                    <canvas
                      ref={canvasRef}
                      width={400}
                      height={200}
                      className="border border-gray-300 rounded cursor-crosshair mx-auto"
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                    />
                    <div className="flex gap-2 mt-3 justify-center">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={clearSignature}
                        disabled={!hasSignature}
                      >
                        נקה
                      </Button>
                      <Button 
                        size="sm"
                        onClick={saveSignature}
                        disabled={!hasSignature}
                        className="bg-red-600"
                      >
                        שמור חתימה
                      </Button>
                      </div>
                      </div>
                      </div>
                      )
                      ) : !data.waiver_url ? (
                      <Button 
                      onClick={generateAndSendWaiver}
                      disabled={loading}
                      className="bg-red-600 hover:bg-red-700"
                      >
                      {loading ? (
                      <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      יוצר ושולח...
                      </>
                      ) : (
                      <>
                      <Send className="w-4 h-4 ml-2" />
                      צור ושלח כתב ויתור
                      </>
                      )}
                      </Button>
                      ) : (
                      <div className="space-y-3">
                      <div className="p-3 bg-green-100 text-green-800 rounded-lg text-sm">
                      ✓ כתב הויתור נשלח ללקוח
                      </div>
                      <div className="flex items-center gap-2 justify-center">
                      <Checkbox
                      id="waiver-signed"
                      checked={data.waiver_signed}
                      onCheckedChange={(c) => setData({ ...data, waiver_signed: c })}
                      />
                      <Label htmlFor="waiver-signed">כתב הויתור נחתם</Label>
                      </div>
                      </div>
                      )}
                      </div>

                      <div className="flex gap-3">
                      <Button variant="outline" onClick={() => setStep(2)}>
                      <ArrowRight className="w-4 h-4 ml-2" />
                      חזרה
                      </Button>
                      <Button 
                      onClick={() => setStep(4)}
                      disabled={!data.waiver_signed}
                      className="flex-1 bg-cyan-600"
                      >
                      המשך לתצהיר
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      </Button>
                      </div>
                      </div>
                      )}

      {/* Step 4: Declaration */}
      {step === 4 && (
        <div className="space-y-4">
          <div className="text-center p-6 bg-purple-50 rounded-lg">
            <FileText className="w-12 h-12 text-purple-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">תצהיר קבלת רכב</h3>
            <p className="text-sm text-gray-600 mb-4">
              הצהרת נהג / אישור קבלת רכב השכרה
            </p>
            
            {signInPerson ? (
              data.declaration_signed ? (
                <div className="space-y-3">
                  <div className="p-3 bg-green-100 text-green-800 rounded-lg text-sm">
                    ✓ התצהיר נחתם
                  </div>
                  <Button 
                    variant="outline"
                    onClick={() => setData({ ...data, declaration_signed: false })}
                  >
                    חתום מחדש
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="border rounded-lg p-4 bg-white max-h-96 overflow-y-auto text-right text-sm mb-4">
                    <h2 className="text-xl font-bold text-center mb-4">הצהרת נהג / אישור קבלת רכב השכרה</h2>

                    <div className="space-y-3">
                      <p>אני הח"מ <strong>{customer?.first_name || booking.customer_name} {customer?.last_name || ''}</strong></p>
                      <p>מספר ת.ז/דרכון: <strong>{customer?.id_number || ''}</strong></p>
                      <p>מצהיר/ה ומאשר/ת כי קיבלתי ביום <strong>{booking.start_date}</strong></p>
                      <p>בשעה <strong>{data.start_time || "______"}</strong></p>
                      <p>ועד יום <strong>{booking.end_date}</strong> בשעה <strong>{booking.end_time || "______"}</strong></p>

                      <div className="mt-4">
                        <p>מס' רכב: <strong>{vehicle.license_plate}</strong></p>
                        <p>פרטי השוכר: <strong>{customer?.first_name || booking.customer_name} {customer?.last_name || ''}</strong></p>
                      </div>

                      <div className="mt-4">
                        <h4 className="font-semibold">פרטי השכרה:</h4>
                        <p>תאריך יציאה: <strong>{booking.start_date}</strong> שעת היציאה: <strong>{data.start_time || "______"}</strong></p>
                        <p>תאריך החזרה: <strong>{booking.end_date}</strong> שעת החזרה: <strong>{booking.end_time || "______"}</strong></p>
                        <p>סך ק"מ המותר לנסיעה: <strong>{vehicle.km_limit || "______"}</strong></p>
                      </div>

                      <div className="mt-4 space-y-1 text-xs">
                        <p>נותנת לי זכות שימוש ברכב מסוג <strong>{vehicle.manufacturer} {vehicle.model}</strong> מספר רישוי <strong>{vehicle.license_plate}</strong></p>
                        <p>אני מצהיר בזאת כי הנני מקבל/ת אחריות מלאה על כל דוח תנועה/קנס משטרתי</p>
                        <p>אני מצהיר בזאת כי הנני מקבל/ת ומחויב לתשלומים לרבות כל קנס ו/או חיוב תשלומים</p>
                        <p>הנדרשים ממנו כדוח אגרה</p>
                        <p>מאשר את כל האמור לחברת ע.מ. אוטופה ישיר קאר בע"מ</p>
                      </div>
                    </div>
                    </div>

                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 bg-white">
                    <p className="text-sm text-gray-600 mb-2">חתמו כאן:</p>
                    <canvas
                      ref={canvasRef}
                      width={400}
                      height={200}
                      className="border border-gray-300 rounded cursor-crosshair mx-auto"
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                    />
                    <div className="flex gap-2 mt-3 justify-center">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={clearSignature}
                        disabled={!hasSignature}
                      >
                        נקה
                      </Button>
                      <Button 
                        size="sm"
                        onClick={saveSignature}
                        disabled={!hasSignature}
                        className="bg-purple-600"
                      >
                        שמור חתימה
                      </Button>
                    </div>
                  </div>
                </div>
              )
            ) : !data.declaration_url ? (
              <Button 
                onClick={generateAndSendDeclaration}
                disabled={loading}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                    יוצר ושולח...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 ml-2" />
                    צור ושלח תצהיר
                  </>
                )}
              </Button>
            ) : (
              <div className="space-y-3">
                <div className="p-3 bg-green-100 text-green-800 rounded-lg text-sm">
                  ✓ התצהיר נשלח ללקוח
                </div>
                <div className="flex items-center gap-2 justify-center">
                  <Checkbox
                    id="declaration-signed"
                    checked={data.declaration_signed}
                    onCheckedChange={(c) => setData({ ...data, declaration_signed: c })}
                  />
                  <Label htmlFor="declaration-signed">התצהיר נחתם</Label>
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep(3)}>
              <ArrowRight className="w-4 h-4 ml-2" />
              חזרה
            </Button>
            <Button 
              onClick={() => setStep(5)}
              disabled={!data.declaration_signed}
              className="flex-1 bg-cyan-600"
            >
              המשך לתשלום
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 5: Payment */}
      {step === 5 && (
        <div className="space-y-4">
          <div className="p-4 bg-orange-50 rounded-lg">
            <CreditCard className="w-8 h-8 text-orange-600 mb-2" />
            <h3 className="font-semibold mb-3">תשלום ומסגרת אשראי</h3>
            
            <div className="space-y-3">
              <div>
                <Label>תפיסת מסגרת אשראי</Label>
                <Input
                  type="number"
                  value={data.credit_hold}
                  onChange={(e) => setData({ ...data, credit_hold: parseFloat(e.target.value) || 0 })}
                  placeholder="סכום למסגרת"
                />
                <p className="text-xs text-gray-500 mt-1">
                  מסגרת המוחזקת לכיסוי נזקים/דוחות
                </p>
              </div>

              <div>
                <Label>אמצעי תשלום</Label>
                <Select 
                  value={data.payment_method} 
                  onValueChange={(v) => setData({ ...data, payment_method: v })}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="מזומן">מזומן</SelectItem>
                    <SelectItem value="אשראי">אשראי</SelectItem>
                    <SelectItem value="צ'ק">צ'ק</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>סכום ששולם כעת</Label>
                <Input
                  type="number"
                  value={data.paid_amount}
                  onChange={(e) => setData({ ...data, paid_amount: parseFloat(e.target.value) || 0 })}
                />
              </div>

              <div className="p-3 bg-white rounded border">
                <div className="flex justify-between text-sm mb-1">
                  <span>עלות כוללת:</span>
                  <span>₪{data.rental_cost?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm mb-1">
                  <span>שולם:</span>
                  <span className="text-green-600">₪{data.paid_amount?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold border-t pt-2">
                  <span>נותר לתשלום:</span>
                  <span className="text-red-600">₪{(data.rental_cost - data.paid_amount)?.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep(4)}>
              <ArrowRight className="w-4 h-4 ml-2" />
              חזרה
            </Button>
            <Button 
              onClick={() => setStep(6)}
              className="flex-1 bg-cyan-600"
            >
              המשך לסיכום
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 6: Summary & Invoice */}
      {step === 6 && (
        <div className="space-y-4">
          <div className="p-4 bg-green-50 rounded-lg">
            <CheckCircle className="w-8 h-8 text-green-600 mb-2" />
            <h3 className="font-semibold mb-3">סיכום והוצאת חשבונית</h3>
            
            <Card className="p-4 mb-4 bg-white">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">ק"מ התחלה:</span>
                  <span className="font-medium">{data.start_km}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">חוזה נחתם:</span>
                  <span className="font-medium">{data.contract_signed ? "✓ כן" : "✗ לא"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">תצהיר נחתם:</span>
                  <span className="font-medium">{data.declaration_signed ? "✓ כן" : "✗ לא"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">כתב ויתור נחתם:</span>
                  <span className="font-medium">{data.waiver_signed ? "✓ כן" : "✗ לא"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">מסגרת אשראי:</span>
                  <span className="font-medium">₪{data.credit_hold?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">תשלום:</span>
                  <span className="font-medium">₪{data.paid_amount?.toLocaleString()} ({data.payment_method})</span>
                </div>
              </div>
            </Card>

            <div>
              <Label>מספר חשבונית (אופציונלי)</Label>
              <Input
                value={data.invoice_number}
                onChange={(e) => setData({ ...data, invoice_number: e.target.value })}
                placeholder="מספר חשבונית"
              />
            </div>

            <div className="p-3 bg-blue-50 rounded text-sm">
              <p className="text-gray-700">
                <strong>שליחת קישור לצילום רכב:</strong> יישלח אוטומטית לטלפון המוגדר במערכת
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep(5)}>
              <ArrowRight className="w-4 h-4 ml-2" />
              חזרה
            </Button>
            <Button 
              onClick={handleComplete}
              disabled={loading}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                  יוצר השכרה...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 ml-2" />
                  אישור והתחלת השכרה
                </>
              )}
            </Button>
          </div>
        </div>
      )}

      <Button variant="ghost" onClick={onCancel} className="w-full">
        ביטול
      </Button>
    </div>
  );
}