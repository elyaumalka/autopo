import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/shared/PageHeader";
import DataTable from "@/components/shared/DataTable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "react-hot-toast";
import { format } from "date-fns";
import { Upload, Loader2, FileSpreadsheet } from "lucide-react";

export default function HighwayBills() {
  const [isOpen, setIsOpen] = useState(false);
  const [uploadDialog, setUploadDialog] = useState(false);
  const [formData, setFormData] = useState({});
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  const { data: expenses = [], isLoading } = useQuery({
    queryKey: ["highway-expenses"],
    queryFn: async () => {
      const allExpenses = await base44.entities.Expense.list("-date");
      return allExpenses.filter(e => e.type === "כביש 6");
    }
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["vehicles"],
    queryFn: () => base44.entities.Vehicle.list()
  });

  const { data: rentals = [] } = useQuery({
    queryKey: ["rentals"],
    queryFn: () => base44.entities.Rental.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Expense.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["highway-expenses"]);
      setIsOpen(false);
      setFormData({});
      toast.success("החיוב נוסף בהצלחה");
    }
  });

  const handleSubmit = () => {
    const vehicle = vehicles.find(v => v.id === formData.vehicle_id);
    createMutation.mutate({
      ...formData,
      type: "כביש 6",
      vehicle_details: vehicle ? `${vehicle.manufacturer} ${vehicle.model} - ${vehicle.license_plate}` : "",
      amount: parseFloat(formData.amount) || 0
    });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    toast.loading("מעלה קובץ...", { id: "upload" });

    try {
      // Upload file
      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      // Extract data using LLM
      toast.loading("מעבד נתונים...", { id: "upload" });
      const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: {
          type: "object",
          properties: {
            charges: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  date: { type: "string" },
                  license_plate: { type: "string" },
                  amount: { type: "number" },
                  description: { type: "string" }
                }
              }
            }
          }
        }
      });

      if (result.status === "error") {
        throw new Error(result.details || "שגיאה בעיבוד הקובץ");
      }

      const charges = result.output?.charges || [];
      let created = 0;
      let skipped = 0;

      toast.loading(`יוצר ${charges.length} רשומות...`, { id: "upload" });

      // Create expense records
      for (const charge of charges) {
        try {
          // Find vehicle by license plate
          const vehicle = vehicles.find(v => 
            v.license_plate?.replace(/[-\s]/g, '') === charge.license_plate?.replace(/[-\s]/g, '')
          );

          if (!vehicle) {
            skipped++;
            continue;
          }

          // Find rental at that date to assign customer
          const rental = rentals.find(r =>
            r.vehicle_id === vehicle.id &&
            r.start_date <= charge.date &&
            (r.actual_end_date || r.planned_end_date) >= charge.date
          );

          await base44.entities.Expense.create({
            type: "כביש 6",
            vehicle_id: vehicle.id,
            vehicle_details: `${vehicle.manufacturer} ${vehicle.model} - ${vehicle.license_plate}`,
            date: charge.date,
            amount: charge.amount,
            description: charge.description || "חיוב כביש 6",
            payment_method: "אשראי"
          });

          // If there's a rental, create income record from customer
          if (rental) {
            await base44.entities.Income.create({
              customer_id: rental.customer_id,
              customer_name: rental.customer_name,
              rental_id: rental.id,
              vehicle_id: vehicle.id,
              amount: charge.amount,
              date: charge.date,
              type: "כביש 6",
              payment_method: "אשראי"
            });
          }

          created++;
        } catch (error) {
          console.error("Error creating expense:", error);
          skipped++;
        }
      }

      queryClient.invalidateQueries(["highway-expenses"]);
      toast.success(`נוצרו ${created} רשומות, דולגו ${skipped}`, { id: "upload" });
      setUploadDialog(false);
    } catch (error) {
      console.error(error);
      toast.error(error.message || "שגיאה בעיבוד הקובץ", { id: "upload" });
    } finally {
      setUploading(false);
    }
  };

  const totalAmount = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);

  const columns = [
    {
      header: "תאריך",
      cell: (row) => format(new Date(row.date), "dd/MM/yyyy")
    },
    {
      header: "רכב",
      accessor: "vehicle_details"
    },
    {
      header: "תיאור",
      accessor: "description"
    },
    {
      header: "סכום",
      cell: (row) => `₪${row.amount?.toLocaleString()}`
    }
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">כביש 6</h1>
          <p className="text-gray-500 mt-1">סה"כ: ₪{totalAmount.toLocaleString()}</p>
        </div>
        <div className="flex gap-3">
          <Button 
            onClick={() => setUploadDialog(true)}
            variant="outline"
            className="border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            <Upload className="w-5 h-5 ml-2" />
            העלה קובץ מכביש 6
          </Button>
          <Button 
            onClick={() => setIsOpen(true)}
            className="bg-cyan-600 hover:bg-cyan-700"
          >
            חיוב חדש
          </Button>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={expenses}
        isLoading={isLoading}
        emptyMessage="אין חיובי כביש 6"
      />

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>חיוב כביש 6 חדש</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>רכב *</Label>
              <Select 
                value={formData.vehicle_id || ""} 
                onValueChange={(v) => setFormData({ ...formData, vehicle_id: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="בחר רכב" />
                </SelectTrigger>
                <SelectContent>
                  {vehicles.map(v => (
                    <SelectItem key={v.id} value={v.id}>
                      {v.manufacturer} {v.model} - {v.license_plate}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>תאריך *</Label>
              <Input
                type="date"
                value={formData.date || ""}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
            </div>

            <div>
              <Label>סכום *</Label>
              <Input
                type="number"
                value={formData.amount || ""}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                placeholder="0"
              />
            </div>

            <div>
              <Label>תיאור</Label>
              <Input
                value={formData.description || ""}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="פרטים נוספים"
              />
            </div>

            <Button 
              onClick={handleSubmit}
              disabled={!formData.vehicle_id || !formData.date || !formData.amount}
              className="w-full bg-cyan-600"
            >
              הוסף חיוב
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Upload Excel Dialog */}
      <Dialog open={uploadDialog} onOpenChange={setUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>העלאת קובץ חיובי כביש 6</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="border-2 border-dashed rounded-lg p-8 text-center">
              <FileSpreadsheet className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-sm text-gray-600 mb-4">
                העלה קובץ Excel מכביש 6 והמערכת תשייך אוטומטית ללקוחות לפי תאריך
              </p>
              <Input
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFileUpload}
                disabled={uploading}
                className="cursor-pointer"
              />
            </div>

            {uploading && (
              <div className="flex items-center justify-center gap-2 text-blue-600">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>מעבד קובץ...</span>
              </div>
            )}

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm">
              <p className="font-semibold mb-2">💡 שדרוג עתידי</p>
              <p className="text-gray-700">
                ניתן להגדיר חיבור ישיר לכביש 6 באמצעות API שלהם לקבלת חיובים אוטומטית.
                זה כבר עובד בהרבה חברות השכרה. צור קשר לפרטים נוספים.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}