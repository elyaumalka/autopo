import React, { useState, useMemo } from "react";
import { addDays, format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, eachDayOfInterval, parseISO, isWithinInterval } from "date-fns";
import { he } from "date-fns/locale";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function BookingsCalendarView({ bookings, vehicles, onCellClick }) {
  const [viewType, setViewType] = useState("weekly");
  const [currentDate, setCurrentDate] = useState(new Date());
  const [zoom, setZoom] = useState(100);
  const [hideMonthly, setHideMonthly] = useState(false);
  const [hideWeekly, setHideWeekly] = useState(false);

  const dates = useMemo(() => {
    if (viewType === "daily") {
      return eachDayOfInterval({
        start: currentDate,
        end: addDays(currentDate, 6)
      });
    } else if (viewType === "weekly") {
      return eachDayOfInterval({
        start: startOfWeek(currentDate, { weekStartsOn: 0 }),
        end: endOfWeek(currentDate, { weekStartsOn: 0 })
      });
    } else {
      return eachDayOfInterval({
        start: startOfMonth(currentDate),
        end: endOfMonth(currentDate)
      });
    }
  }, [viewType, currentDate]);

  // Helper function to normalize time with 2-hour margin
  const normalizeTime = (timeStr) => {
    if (!timeStr) return null;
    const [hours] = timeStr.split(':').map(Number);
    
    // Morning slot (9:00-16:00) - with 2h margin: 7:00-18:00
    if (hours >= 7 && hours < 18) return 'morning';
    
    // Evening slot (16:00-9:00) - everything else
    return 'evening';
  };

  // Check if booking occupies a specific time slot
  const occupiesSlot = (booking, date, slot) => {
    if (booking.status === "בוטל") return false;

    const itemDate = format(date, 'yyyy-MM-dd');
    const startDate = booking.start_date;

    // For completed bookings, use actual end date if available
    let endDate = booking.end_date;
    if (booking.status === "הושלם" && booking.actual_end_date) {
      endDate = booking.actual_end_date;
    }

    // For 24-hour rentals - only occupy the start date
    if (booking.rental_type === "24 שעות") {
      return itemDate === startDate;
    }

    // For half-day rentals - only occupy the start date morning slot
    if (booking.rental_type === "חצי יום") {
      return itemDate === startDate && slot === 'morning';
    }

    // Check if this date is within the booking period
    // End date is exclusive (vehicle available from start of end date)
    if (itemDate < startDate || itemDate >= endDate) return false;

    // First day - check start time
    if (itemDate === startDate) {
      const startSlot = normalizeTime(booking.start_time);
      if (!startSlot) return true; // No time specified, occupy both

      if (startSlot === 'morning' && slot === 'morning') return true;
      if (startSlot === 'morning' && slot === 'evening') return true; // Both slots on start day
      if (startSlot === 'evening' && slot === 'evening') return true;
      return false;
    }

    // Middle days - occupy both slots (end date already excluded above)
    return true;
  };

  const getSlotOccupancy = (vehicleId, date, slot) => {
    const booking = bookings.find(b => 
      b.vehicle_id === vehicleId && 
      b.status !== "בוטל" &&
      occupiesSlot(b, date, slot)
    );
    
    if (booking) {
      return {
        occupied: true,
        booking: booking
      };
    }
    
    return { occupied: false };
  };

  const navigateDate = (direction) => {
    if (viewType === "daily") {
      setCurrentDate(addDays(currentDate, direction * 7));
    } else if (viewType === "weekly") {
      setCurrentDate(addDays(currentDate, direction * 7));
    } else {
      const newDate = new Date(currentDate);
      newDate.setMonth(currentDate.getMonth() + direction);
      setCurrentDate(newDate);
    }
  };

  const getViewTitle = () => {
    if (viewType === "daily") {
      return `${format(currentDate, "dd/MM/yy")} - ${format(addDays(currentDate, 6), "dd/MM/yy")}`;
    } else if (viewType === "weekly") {
      const start = startOfWeek(currentDate, { weekStartsOn: 0 });
      const end = endOfWeek(currentDate, { weekStartsOn: 0 });
      return `${format(start, "dd/MM/yy")} - ${format(end, "dd/MM/yy")}`;
    } else {
      return format(currentDate, "MMMM yyyy", { locale: he });
    }
  };

  // Check if vehicle has monthly/weekly booking in the visible period
  const hasLongTermBooking = (vehicleId, rentalType) => {
    return bookings.some(b => 
      b.vehicle_id === vehicleId && 
      b.rental_type === rentalType &&
      b.status !== "בוטל" &&
      dates.some(date => occupiesSlot(b, date, 'morning') || occupiesSlot(b, date, 'evening'))
    );
  };

  const filteredVehicles = vehicles.filter(v => {
    if (hideMonthly && hasLongTermBooking(v.id, "חודש")) return false;
    if (hideWeekly && hasLongTermBooking(v.id, "שבוע")) return false;
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Select value={viewType} onValueChange={setViewType}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">יומי</SelectItem>
              <SelectItem value="weekly">שבועי</SelectItem>
              <SelectItem value="monthly">חודשי</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => navigateDate(-1)}>
              <ChevronRight className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium min-w-[150px] text-center">
              {getViewTitle()}
            </span>
            <Button variant="outline" size="sm" onClick={() => navigateDate(1)}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
          </div>

          <Button variant="outline" size="sm" onClick={() => setCurrentDate(new Date())}>
            היום
          </Button>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 border-l pl-3">
            <label className="flex items-center gap-1 text-sm cursor-pointer">
              <input 
                type="checkbox" 
                checked={hideMonthly}
                onChange={(e) => setHideMonthly(e.target.checked)}
                className="rounded"
              />
              <span>הסתר חודשי</span>
            </label>
            <label className="flex items-center gap-1 text-sm cursor-pointer">
              <input 
                type="checkbox" 
                checked={hideWeekly}
                onChange={(e) => setHideWeekly(e.target.checked)}
                className="rounded"
              />
              <span>הסתר שבועי</span>
            </label>
          </div>

          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setZoom(Math.max(50, zoom - 25))}
              disabled={zoom <= 50}
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium min-w-[60px] text-center">
              {zoom}%
            </span>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setZoom(Math.min(150, zoom + 25))}
              disabled={zoom >= 150}
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Calendar Table */}
      <Card className="p-0 overflow-x-auto">
        <table 
          className="w-full border-collapse" 
          dir="rtl"
          style={{ 
            fontSize: `${zoom}%`,
            transform: `scale(${zoom / 100})`,
            transformOrigin: 'top right'
          }}
        >
          <thead>
            <tr className="bg-gray-100 border-b-2">
              <th className="p-3 text-right font-semibold sticky right-0 bg-gray-100 border-l min-w-[120px]">
                רכב
              </th>
              {dates.map((date, i) => (
                <th key={i} colSpan="2" className="p-2 text-center font-medium text-xs border-l">
                  <div>{format(date, "EEEE", { locale: he })}</div>
                  <div className="text-gray-600">{format(date, "dd.MM")}</div>
                </th>
              ))}
            </tr>
            <tr className="bg-gray-50 border-b">
              <th className="p-2 text-xs sticky right-0 bg-gray-50 border-l"></th>
              {dates.map((date, i) => (
                <React.Fragment key={i}>
                  <th className="p-1 text-center text-[10px] text-gray-500 border-l w-20">
                    9-16
                  </th>
                  <th className="p-1 text-center text-[10px] text-gray-500 border-l w-20">
                    16-9
                  </th>
                </React.Fragment>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredVehicles.map((vehicle) => (
              <tr key={vehicle.id} className="border-b hover:bg-gray-50">
                <td className="p-3 sticky right-0 bg-white border-l">
                  <div className="text-sm font-medium">{vehicle.license_plate}</div>
                  <div className="text-xs text-gray-500">
                    {vehicle.manufacturer} {vehicle.model}
                  </div>
                </td>
                {dates.map((date, dateIdx) => (
                  <React.Fragment key={dateIdx}>
                    {/* Morning Slot (9:00-16:00) */}
                    <td 
                      className="p-1 border-l text-center cursor-pointer transition-colors"
                      onClick={() => {
                        if (vehicle.status === "בטיפול" || vehicle.status === "תאונה") {
                          return; // Don't allow booking
                        }
                        const slot = getSlotOccupancy(vehicle.id, date, 'morning');
                        if (slot.occupied) {
                          onCellClick && onCellClick(date, vehicle, slot.booking);
                        } else {
                          onCellClick && onCellClick(date, vehicle, null);
                        }
                      }}
                    >
                      {(() => {
                        // Check if vehicle is in maintenance/accident status
                        if (vehicle.status === "בטיפול" || vehicle.status === "תאונה") {
                          return (
                            <div className="p-2 rounded text-xs bg-red-100 text-red-800 border border-red-300">
                              <div className="font-medium truncate">{vehicle.status}</div>
                            </div>
                          );
                        }

                        const slot = getSlotOccupancy(vehicle.id, date, 'morning');
                        if (slot.occupied) {
                          const b = slot.booking;
                          const itemDate = format(date, 'yyyy-MM-dd');
                          const isStartDate = itemDate === b.start_date;
                          
                          let bgColor = 'bg-blue-100 text-blue-800 border border-blue-300';
                          
                          if (b.status === "הושלם") {
                            bgColor = 'bg-green-100 text-green-800 border border-green-300';
                          } else if (b.status === "פעיל") {
                            bgColor = 'bg-orange-100 text-orange-800 border border-orange-300';
                          } else if (b.rental_type === "חודש") {
                            bgColor = 'bg-amber-50 text-amber-900 border border-amber-200';
                          } else if (b.status === "מאושר") {
                            bgColor = 'bg-yellow-100 text-yellow-800 border border-yellow-300';
                          }
                          
                          return (
                            <div className={`p-2 rounded text-xs ${bgColor}`}>
                              <div className="font-medium truncate">{b.customer_name?.split(' ')[0]}</div>
                              {isStartDate && b.start_time ? (
                                <div className="text-[10px] opacity-70">{b.start_time}</div>
                              ) : (
                                <div className="text-[10px] opacity-0">00:00</div>
                              )}
                            </div>
                          );
                        }
                        return <div className="p-2 text-gray-300 hover:bg-gray-100 rounded">+</div>;
                      })()}
                    </td>
                    
                    {/* Evening Slot (16:00-9:00) */}
                    <td 
                      className="p-1 border-l text-center cursor-pointer transition-colors"
                      onClick={() => {
                        if (vehicle.status === "בטיפול" || vehicle.status === "תאונה") {
                          return; // Don't allow booking
                        }
                        const slot = getSlotOccupancy(vehicle.id, date, 'evening');
                        if (slot.occupied) {
                          onCellClick && onCellClick(date, vehicle, slot.booking);
                        } else {
                          onCellClick && onCellClick(date, vehicle, null);
                        }
                      }}
                    >
                      {(() => {
                        // Check if vehicle is in maintenance/accident status
                        if (vehicle.status === "בטיפול" || vehicle.status === "תאונה") {
                          return (
                            <div className="p-2 rounded text-xs bg-red-100 text-red-800 border border-red-300">
                              <div className="font-medium truncate">{vehicle.status}</div>
                            </div>
                          );
                        }

                        const slot = getSlotOccupancy(vehicle.id, date, 'evening');
                        if (slot.occupied) {
                          const b = slot.booking;
                          const itemDate = format(date, 'yyyy-MM-dd');
                          const isStartDate = itemDate === b.start_date;
                          
                          let bgColor = 'bg-blue-100 text-blue-800 border border-blue-300';
                          
                          if (b.status === "הושלם") {
                            bgColor = 'bg-green-100 text-green-800 border border-green-300';
                          } else if (b.status === "פעיל") {
                            bgColor = 'bg-orange-100 text-orange-800 border border-orange-300';
                          } else if (b.rental_type === "חודש") {
                            bgColor = 'bg-amber-50 text-amber-900 border border-amber-200';
                          } else if (b.status === "מאושר") {
                            bgColor = 'bg-yellow-100 text-yellow-800 border border-yellow-300';
                          }
                          
                          return (
                            <div className={`p-2 rounded text-xs ${bgColor}`}>
                              <div className="font-medium truncate">{b.customer_name?.split(' ')[0]}</div>
                              {isStartDate && b.start_time ? (
                                <div className="text-[10px] opacity-70">{b.start_time}</div>
                              ) : (
                                <div className="text-[10px] opacity-0">00:00</div>
                              )}
                            </div>
                          );
                        }
                        return <div className="p-2 text-gray-300 hover:bg-gray-100 rounded">+</div>;
                      })()}
                    </td>
                  </React.Fragment>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {/* Legend */}
      <div className="flex items-center gap-4 text-xs flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-white border"></div>
          <span>פנוי</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-yellow-100 border border-yellow-300"></div>
          <span>משוריין</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-orange-100 border border-orange-300"></div>
          <span>פעיל</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-amber-50 border border-amber-200"></div>
          <span>חודשי</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-green-100 border border-green-300"></div>
          <span>הושלם</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-red-100 border border-red-300"></div>
          <span>תיקון/תאונה</span>
        </div>
      </div>
    </div>
  );
}