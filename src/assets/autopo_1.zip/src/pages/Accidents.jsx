import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import PageHeader from "@/components/shared/PageHeader";
import DataTable from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, Car, User, FileText, Edit, Eye, Upload, X } from "lucide-react";

export default function Accidents() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedAccident, setSelectedAccident] = useState(null);
  const [viewMode, setViewMode] = useState(false);
  const [formData, setFormData] = useState({});
  const [typeFilter, setTypeFilter] = useState("all");
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  const { data: accidents = [], isLoading } = useQuery({
    queryKey: ["accidents"],
    queryFn: () => base44.entities.Accident.list("-date")
  });

  const { data: customers = [] } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list()
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["vehicles"],
    queryFn: () => base44.entities.Vehicle.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Accident.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["accidents"]);
      setIsOpen(false);
      setSelectedAccident(null);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Accident.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["accidents"]);
      setIsOpen(false);
      setSelectedAccident(null);
      setFormData({});
    }
  });

  const handleFileUpload = async (file, field) => {
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      if (field.includes('photos') || field.includes('docs')) {
        const current = formData[field] || [];
        setFormData({ ...formData, [field]: [...current, file_url] });
      } else {
        setFormData({ ...formData, [field]: file_url });
      }
    } catch (error) {
      console.error('Upload error:', error);
    } finally {
      setUploading(false);
    }
  };

  const removeFile = (field, index = null) => {
    if (index !== null) {
      const current = formData[field] || [];
      setFormData({ ...formData, [field]: current.filter((_, i) => i !== index) });
    } else {
      setFormData({ ...formData, [field]: "" });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const formDataObj = new FormData(e.target);
    const data = Object.fromEntries(formDataObj.entries());
    
    // Merge with uploaded files
    Object.assign(data, formData);
    
    if (data.estimated_cost) data.estimated_cost = parseFloat(data.estimated_cost);
    if (data.actual_cost) data.actual_cost = parseFloat(data.actual_cost);

    const customer = customers.find(c => c.id === data.customer_id);
    const vehicle = vehicles.find(v => v.id === data.vehicle_id);
    
    if (customer) data.customer_name = `${customer.first_name} ${customer.last_name}`;
    if (vehicle) data.vehicle_details = `${vehicle.manufacturer} ${vehicle.model} - ${vehicle.license_plate}`;

    if (selectedAccident) {
      updateMutation.mutate({ id: selectedAccident.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filteredAccidents = typeFilter === "all" 
    ? accidents 
    : accidents.filter(a => a.type === typeFilter);

  const openCount = accidents.filter(a => a.status !== "נסגר").length;

  const columns = [
    {
      header: "תאריך",
      cell: (row) => row.date ? format(new Date(row.date), "dd/MM/yyyy") : "-"
    },
    {
      header: "סוג",
      cell: (row) => (
        <span className={`px-2 py-1 rounded-full text-sm ${
          row.type === "תביעה חיצונית" ? "bg-red-100 text-red-800" : "bg-orange-100 text-orange-800"
        }`}>
          {row.type}
        </span>
      )
    },
    {
      header: "לקוח",
      cell: (row) => row.customer_name || "-"
    },
    {
      header: "רכב",
      cell: (row) => row.vehicle_details || "-"
    },
    {
      header: "עלות משוערת",
      cell: (row) => row.estimated_cost ? `₪${row.estimated_cost.toLocaleString()}` : "-"
    },
    {
      header: "סטטוס",
      cell: (row) => <StatusBadge status={row.status || "פתוח"} />
    },
    {
      header: "פעולות",
      cell: (row) => (
        <div className="flex gap-2">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => { setSelectedAccident(row); setViewMode(true); setIsOpen(true); }}
          >
            <Eye className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => { setSelectedAccident(row); setViewMode(false); setIsOpen(true); }}
          >
            <Edit className="w-4 h-4" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div>
      <PageHeader
        title="תאונות ותביעות"
        subtitle={`${openCount} תיקים פתוחים`}
        action={() => { setSelectedAccident(null); setViewMode(false); setIsOpen(true); }}
        actionLabel="תאונה חדשה"
        actionIcon={AlertTriangle}
      />

      <div className="mb-6">
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הסוגים</SelectItem>
            <SelectItem value="תביעה חיצונית">תביעה חיצונית</SelectItem>
            <SelectItem value="תביעה פנימית">תביעה פנימית</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <DataTable
        columns={columns}
        data={filteredAccidents}
        isLoading={isLoading}
        emptyMessage="לא נמצאו תאונות"
      />

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {viewMode ? "פרטי תאונה" : selectedAccident ? "עריכת תאונה" : "תאונה חדשה"}
            </DialogTitle>
          </DialogHeader>

          {viewMode && selectedAccident ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-500">תאריך</Label>
                  <p className="font-medium">
                    {selectedAccident.date ? format(new Date(selectedAccident.date), "dd/MM/yyyy") : "-"}
                  </p>
                </div>
                <div>
                  <Label className="text-gray-500">סוג</Label>
                  <p className="font-medium">{selectedAccident.type}</p>
                </div>
                <div>
                  <Label className="text-gray-500">לקוח</Label>
                  <p className="font-medium">{selectedAccident.customer_name || "-"}</p>
                </div>
                <div>
                  <Label className="text-gray-500">רכב</Label>
                  <p className="font-medium">{selectedAccident.vehicle_details}</p>
                </div>
              </div>

              <div>
                <Label className="text-gray-500">תיאור</Label>
                <p>{selectedAccident.description || "-"}</p>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold mb-3">פרטי הצד השני</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">שם:</span> {selectedAccident.other_party_name || "-"}
                  </div>
                  <div>
                    <span className="text-gray-500">טלפון:</span> {selectedAccident.other_party_phone || "-"}
                  </div>
                  <div>
                    <span className="text-gray-500">ת.ז.:</span> {selectedAccident.other_party_id || "-"}
                  </div>
                  <div>
                    <span className="text-gray-500">רכב:</span> {selectedAccident.other_vehicle_plate || "-"}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-500">עלות משוערת</Label>
                  <p className="font-medium">₪{selectedAccident.estimated_cost?.toLocaleString() || 0}</p>
                </div>
                <div>
                  <Label className="text-gray-500">עלות בפועל</Label>
                  <p className="font-medium">₪{selectedAccident.actual_cost?.toLocaleString() || 0}</p>
                </div>
              </div>

              <Button onClick={() => setViewMode(false)} className="w-full">
                עריכה
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <Tabs defaultValue="basic">
                <TabsList className="grid w-full grid-cols-3 mb-4">
                  <TabsTrigger value="basic">פרטי התאונה</TabsTrigger>
                  <TabsTrigger value="documents">מסמכים</TabsTrigger>
                  <TabsTrigger value="other">הצד השני</TabsTrigger>
                </TabsList>

                <TabsContent value="basic" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>סוג *</Label>
                      <Select name="type" defaultValue={selectedAccident?.type || "תביעה פנימית"}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="תביעה חיצונית">תביעה חיצונית</SelectItem>
                          <SelectItem value="תביעה פנימית">תביעה פנימית</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>תאריך *</Label>
                      <Input name="date" type="date" defaultValue={selectedAccident?.date} required />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>רכב *</Label>
                      <Select name="vehicle_id" defaultValue={selectedAccident?.vehicle_id}>
                        <SelectTrigger><SelectValue placeholder="בחר רכב" /></SelectTrigger>
                        <SelectContent>
                          {vehicles.map(v => (
                            <SelectItem key={v.id} value={v.id}>
                              {v.manufacturer} {v.model} - {v.license_plate}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>לקוח</Label>
                      <Select name="customer_id" defaultValue={selectedAccident?.customer_id}>
                        <SelectTrigger><SelectValue placeholder="בחר לקוח" /></SelectTrigger>
                        <SelectContent>
                          {customers.map(c => (
                            <SelectItem key={c.id} value={c.id}>
                              {c.first_name} {c.last_name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label>תיאור האירוע</Label>
                    <Textarea name="description" defaultValue={selectedAccident?.description} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>עלות משוערת</Label>
                      <Input name="estimated_cost" type="number" defaultValue={selectedAccident?.estimated_cost} />
                    </div>
                    <div>
                      <Label>עלות בפועל</Label>
                      <Input name="actual_cost" type="number" defaultValue={selectedAccident?.actual_cost} />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>סטטוס</Label>
                      <Select name="status" defaultValue={selectedAccident?.status || "פתוח"}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="פתוח">פתוח</SelectItem>
                          <SelectItem value="בטיפול">בטיפול</SelectItem>
                          <SelectItem value="בהמתנה לביטוח">בהמתנה לביטוח</SelectItem>
                          <SelectItem value="נסגר">נסגר</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>מספר תביעה בביטוח</Label>
                      <Input name="insurance_claim_number" defaultValue={selectedAccident?.insurance_claim_number} />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="documents" className="space-y-4">
                  <h3 className="font-semibold text-lg mb-4">מסמכים - הרכב שלנו</h3>

                  {/* Damage Photos */}
                  <div>
                    <Label>תמונות נזק</Label>
                    <div className="mt-2 space-y-2">
                      {(formData.damage_photos || []).map((url, i) => (
                        <div key={i} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                          <img src={url} alt="נזק" className="w-16 h-16 object-cover rounded" />
                          <span className="flex-1 text-sm truncate">{url.split('/').pop()}</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeFile('damage_photos', i)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                      <label className="block">
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          className="hidden"
                          onChange={async (e) => {
                            for (let file of e.target.files) {
                              await handleFileUpload(file, 'damage_photos');
                            }
                          }}
                        />
                        <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50">
                          <Upload className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                          <span className="text-sm text-gray-600">העלה תמונות נזק</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Single Documents */}
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { field: 'our_vehicle_license', label: 'רישיון רכב' },
                      { field: 'our_insurance_policy', label: 'פוליסת ביטוח' },
                      { field: 'our_id_card', label: 'תעודת זהות' },
                      { field: 'our_driver_license', label: 'רישיון נהיגה' },
                      { field: 'our_valuation_report', label: 'דוח שמאות' }
                    ].map(({ field, label }) => (
                      <div key={field}>
                        <Label>{label}</Label>
                        {formData[field] ? (
                          <div className="flex items-center gap-2 p-2 bg-gray-50 rounded mt-1">
                            <span className="flex-1 text-sm truncate">{formData[field].split('/').pop()}</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => removeFile(field)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        ) : (
                          <label className="block mt-1">
                            <input
                              type="file"
                              className="hidden"
                              onChange={(e) => handleFileUpload(e.target.files[0], field)}
                            />
                            <div className="border rounded p-2 text-center cursor-pointer hover:bg-gray-50">
                              <Upload className="w-4 h-4 mx-auto text-gray-400" />
                            </div>
                          </label>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Other Documents */}
                  <div>
                    <Label>מסמכים נוספים</Label>
                    <div className="mt-2 space-y-2">
                      {(formData.our_other_docs || []).map((url, i) => (
                        <div key={i} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                          <span className="flex-1 text-sm truncate">{url.split('/').pop()}</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeFile('our_other_docs', i)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                      <label className="block">
                        <input
                          type="file"
                          multiple
                          className="hidden"
                          onChange={async (e) => {
                            for (let file of e.target.files) {
                              await handleFileUpload(file, 'our_other_docs');
                            }
                          }}
                        />
                        <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50">
                          <Upload className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                          <span className="text-sm text-gray-600">העלה מסמכים</span>
                        </div>
                      </label>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="other" className="space-y-4">
                  <h3 className="font-semibold text-lg mb-4">פרטי הצד השני</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>שם הצד השני</Label>
                      <Input name="other_party_name" defaultValue={selectedAccident?.other_party_name} />
                    </div>
                    <div>
                      <Label>טלפון</Label>
                      <Input name="other_party_phone" defaultValue={selectedAccident?.other_party_phone} />
                    </div>
                    <div>
                      <Label>ת.ז.</Label>
                      <Input name="other_party_id" defaultValue={selectedAccident?.other_party_id} />
                    </div>
                    <div>
                      <Label>מספר רכב</Label>
                      <Input name="other_vehicle_plate" defaultValue={selectedAccident?.other_vehicle_plate} />
                    </div>
                  </div>
                  <div>
                    <Label>פרטי רכב הצד השני</Label>
                    <Textarea name="other_vehicle_details" defaultValue={selectedAccident?.other_vehicle_details} />
                  </div>

                  <h3 className="font-semibold text-lg mb-4 mt-6">מסמכים - הצד השני</h3>

                  {/* Other Party Damage Photos */}
                  <div>
                    <Label>תמונות נזק</Label>
                    <div className="mt-2 space-y-2">
                      {(formData.other_damage_photos || []).map((url, i) => (
                        <div key={i} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                          <img src={url} alt="נזק" className="w-16 h-16 object-cover rounded" />
                          <span className="flex-1 text-sm truncate">{url.split('/').pop()}</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeFile('other_damage_photos', i)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                      <label className="block">
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          className="hidden"
                          onChange={async (e) => {
                            for (let file of e.target.files) {
                              await handleFileUpload(file, 'other_damage_photos');
                            }
                          }}
                        />
                        <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50">
                          <Upload className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                          <span className="text-sm text-gray-600">העלה תמונות נזק</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Other Party Documents */}
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { field: 'other_vehicle_license', label: 'רישיון רכב' },
                      { field: 'other_insurance_policy', label: 'פוליסת ביטוח' },
                      { field: 'other_id_card', label: 'תעודת זהות' },
                      { field: 'other_driver_license', label: 'רישיון נהיגה' },
                      { field: 'other_valuation_report', label: 'דוח שמאות' }
                    ].map(({ field, label }) => (
                      <div key={field}>
                        <Label>{label}</Label>
                        {formData[field] ? (
                          <div className="flex items-center gap-2 p-2 bg-gray-50 rounded mt-1">
                            <span className="flex-1 text-sm truncate">{formData[field].split('/').pop()}</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => removeFile(field)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        ) : (
                          <label className="block mt-1">
                            <input
                              type="file"
                              className="hidden"
                              onChange={(e) => handleFileUpload(e.target.files[0], field)}
                            />
                            <div className="border rounded p-2 text-center cursor-pointer hover:bg-gray-50">
                              <Upload className="w-4 h-4 mx-auto text-gray-400" />
                            </div>
                          </label>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Other Party Additional Documents */}
                  <div>
                    <Label>מסמכים נוספים</Label>
                    <div className="mt-2 space-y-2">
                      {(formData.other_other_docs || []).map((url, i) => (
                        <div key={i} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                          <span className="flex-1 text-sm truncate">{url.split('/').pop()}</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeFile('other_other_docs', i)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                      <label className="block">
                        <input
                          type="file"
                          multiple
                          className="hidden"
                          onChange={async (e) => {
                            for (let file of e.target.files) {
                              await handleFileUpload(file, 'other_other_docs');
                            }
                          }}
                        />
                        <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50">
                          <Upload className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                          <span className="text-sm text-gray-600">העלה מסמכים</span>
                        </div>
                      </label>
                    </div>
                  </div>
                  </TabsContent>
                  </Tabs>

              <div className="flex gap-3 pt-4 mt-4 border-t">
                <Button type="submit" className="flex-1 bg-cyan-600 hover:bg-cyan-700">
                  {selectedAccident ? "עדכון" : "יצירה"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                  ביטול
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}