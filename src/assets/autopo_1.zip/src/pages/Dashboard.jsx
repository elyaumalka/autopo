import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { motion } from "framer-motion";
import {
  Car,
  Users,
  FileText,
  DollarSign,
  AlertTriangle,
  Clock,
  TrendingUp,
  Calendar,
  ArrowLeft,
  Wrench
} from "lucide-react";
import StatCard from "@/components/shared/StatCard";
import StatusBadge from "@/components/shared/StatusBadge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";

export default function Dashboard() {
  const { data: vehicles = [], isLoading: loadingVehicles } = useQuery({
    queryKey: ["vehicles"],
    queryFn: () => base44.entities.Vehicle.list()
  });

  const { data: customers = [], isLoading: loadingCustomers } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list()
  });

  const { data: rentals = [], isLoading: loadingRentals } = useQuery({
    queryKey: ["rentals"],
    queryFn: () => base44.entities.Rental.list()
  });

  const { data: incomes = [], isLoading: loadingIncomes } = useQuery({
    queryKey: ["incomes"],
    queryFn: () => base44.entities.Income.list()
  });

  const { data: maintenanceTasks = [], isLoading: loadingMaintenance } = useQuery({
    queryKey: ["maintenanceTasks"],
    queryFn: () => base44.entities.MaintenanceTask.filter({ status: "ממתין" })
  });

  const { data: collectionTasks = [], isLoading: loadingCollections } = useQuery({
    queryKey: ["collectionTasks"],
    queryFn: () => base44.entities.CollectionTask.filter({ status: "פתוח" })
  });

  const isLoading = loadingVehicles || loadingCustomers || loadingRentals || loadingIncomes;

  const activeRentals = rentals.filter(r => r.status === "פעיל");
  const availableVehicles = vehicles.filter(v => v.status === "זמין");

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const monthlyIncome = incomes
    .filter(i => {
      const d = new Date(i.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    })
    .reduce((sum, i) => sum + (i.amount || 0), 0);

  // Calculate monthly data for chart
  const monthlyData = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const month = d.getMonth();
    const year = d.getFullYear();
    const monthIncomes = incomes.filter(inc => {
      const incDate = new Date(inc.date);
      return incDate.getMonth() === month && incDate.getFullYear() === year;
    });
    monthlyData.push({
      name: format(d, "MMM"),
      income: monthIncomes.reduce((sum, inc) => sum + (inc.amount || 0), 0)
    });
  }

  const totalDebt = collectionTasks.reduce((sum, t) => sum + (t.amount - (t.paid_amount || 0)), 0);

  // Check vehicles that need attention
  const vehiclesNeedingAttention = vehicles.filter(v => {
    const needsTest = v.test_date && new Date(v.test_date) < new Date();
    const needsService = v.next_service_date && new Date(v.next_service_date) < new Date();
    return needsTest || needsService;
  });

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">שלום! 👋</h1>
        <p className="text-gray-500 mt-1">הנה סקירה של העסק שלך היום</p>
      </div>

      {/* Vehicle Alerts */}
      {vehiclesNeedingAttention.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-red-50 border-2 border-red-200 rounded-2xl p-4"
        >
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-red-600" />
            <div className="flex-1">
              <h3 className="font-semibold text-red-900">התרעות רכבים</h3>
              <p className="text-sm text-red-700">
                {vehiclesNeedingAttention.length} רכבים דורשים תשומת לב
              </p>
            </div>
            <Link 
              to={createPageUrl("Vehicles")}
              className="text-red-700 hover:text-red-900 text-sm font-medium"
            >
              צפה
            </Link>
          </div>
          <div className="mt-3 space-y-2">
            {vehiclesNeedingAttention.slice(0, 3).map((v) => (
              <div key={v.id} className="text-sm bg-white rounded-lg p-2 border border-red-200">
                <span className="font-medium">{v.license_plate}</span> - {v.manufacturer} {v.model}
                {v.test_date && new Date(v.test_date) < new Date() && (
                  <span className="text-red-600 mr-2">• דרוש טסט</span>
                )}
                {v.next_service_date && new Date(v.next_service_date) < new Date() && (
                  <span className="text-red-600 mr-2">• דרוש טיפול</span>
                )}
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="רכבים זמינים"
          value={isLoading ? "..." : `${availableVehicles.length}/${vehicles.length}`}
          icon={Car}
          color="cyan"
          subtitle={`${activeRentals.length} מושכרים כרגע`}
        />
        <StatCard
          title="לקוחות"
          value={isLoading ? "..." : customers.length}
          icon={Users}
          color="blue"
        />
        <StatCard
          title="הכנסות החודש"
          value={isLoading ? "..." : `₪${monthlyIncome.toLocaleString()}`}
          icon={DollarSign}
          color="green"
        />
        <StatCard
          title="חובות לגבייה"
          value={isLoading ? "..." : `₪${totalDebt.toLocaleString()}`}
          icon={AlertTriangle}
          color="red"
          subtitle={`${collectionTasks.length} פריטים פתוחים`}
        />
      </div>

      {/* Charts and Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Income Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:col-span-2 bg-white rounded-2xl border p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">הכנסות - 6 חודשים אחרונים</h2>
            <TrendingUp className="w-5 h-5 text-green-500" />
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyData}>
                <defs>
                  <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0891b2" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#0891b2" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip
                  formatter={(value) => [`₪${value.toLocaleString()}`, "הכנסה"]}
                  contentStyle={{ borderRadius: 12, border: "1px solid #e5e7eb" }}
                />
                <Area
                  type="monotone"
                  dataKey="income"
                  stroke="#0891b2"
                  strokeWidth={2}
                  fill="url(#incomeGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Active Rentals */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl border p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">השכרות פעילות</h2>
            <Link 
              to={createPageUrl("Rentals")}
              className="text-cyan-600 hover:text-cyan-700 text-sm flex items-center gap-1"
            >
              הכל <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
          <div className="space-y-3">
            {loadingRentals ? (
              [...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-16 rounded-xl" />
              ))
            ) : activeRentals.length === 0 ? (
              <p className="text-gray-500 text-center py-8">אין השכרות פעילות</p>
            ) : (
              activeRentals.slice(0, 5).map((rental) => (
                <div
                  key={rental.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  <div>
                    <p className="font-medium text-sm">{rental.customer_name}</p>
                    <p className="text-xs text-gray-500">{rental.vehicle_details}</p>
                  </div>
                  <div className="text-left">
                    <p className="text-xs text-gray-500">עד</p>
                    <p className="text-sm font-medium">
                      {rental.planned_end_date ? format(new Date(rental.planned_end_date), "dd/MM") : "-"}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </motion.div>
      </div>

      {/* Bottom Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Maintenance Tasks */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl border p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Wrench className="w-5 h-5 text-orange-500" />
              <h2 className="text-lg font-semibold">משימות תפעול</h2>
            </div>
            <Link 
              to={createPageUrl("MaintenanceTasks")}
              className="text-cyan-600 hover:text-cyan-700 text-sm flex items-center gap-1"
            >
              הכל <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
          <div className="space-y-3">
            {loadingMaintenance ? (
              [...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-14 rounded-xl" />
              ))
            ) : maintenanceTasks.length === 0 ? (
              <p className="text-gray-500 text-center py-6">אין משימות פתוחות</p>
            ) : (
              maintenanceTasks.slice(0, 4).map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between p-3 bg-orange-50 rounded-xl border border-orange-100"
                >
                  <div>
                    <p className="font-medium text-sm">{task.type}</p>
                    <p className="text-xs text-gray-500">{task.vehicle_details}</p>
                  </div>
                  <div className="text-left">
                    {task.due_date && (
                      <p className="text-sm text-orange-600 font-medium">
                        {format(new Date(task.due_date), "dd/MM")}
                      </p>
                    )}
                    {task.due_km && (
                      <p className="text-xs text-gray-500">{task.due_km} ק"מ</p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </motion.div>

        {/* Collection Tasks */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl border p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-red-500" />
              <h2 className="text-lg font-semibold">גבייה</h2>
            </div>
            <Link 
              to={createPageUrl("CollectionTasks")}
              className="text-cyan-600 hover:text-cyan-700 text-sm flex items-center gap-1"
            >
              הכל <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
          <div className="space-y-3">
            {loadingCollections ? (
              [...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-14 rounded-xl" />
              ))
            ) : collectionTasks.length === 0 ? (
              <p className="text-gray-500 text-center py-6">אין חובות פתוחים</p>
            ) : (
              collectionTasks.slice(0, 4).map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between p-3 bg-red-50 rounded-xl border border-red-100"
                >
                  <div>
                    <p className="font-medium text-sm">{task.customer_name}</p>
                    <p className="text-xs text-gray-500">{task.vehicle_details}</p>
                  </div>
                  <p className="text-red-600 font-bold">
                    ₪{(task.amount - (task.paid_amount || 0)).toLocaleString()}
                  </p>
                </div>
              ))
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}