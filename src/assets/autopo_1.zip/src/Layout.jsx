import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "./utils";
import {
  LayoutDashboard,
  Users,
  Car,
  Calendar,
  FileText,
  DollarSign,
  Wrench,
  CreditCard,
  CheckSquare,
  AlertTriangle,
  FileWarning,
  Menu,
  X,
  LogOut,
  ChevronDown,
  ClipboardList
} from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function Layout({ children, currentPageName }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedMenu, setExpandedMenu] = useState(null);

  // Hide layout for rental station pages
  if (currentPageName === "RentalStation" || currentPageName === "TodayDepartures" || currentPageName === "TodayReturns") {
    return <div className="min-h-screen">{children}</div>;
  }

  const menuItems = [
    { name: "ראשי", page: "Dashboard", icon: LayoutDashboard },
    { name: "הזמנות", page: "Bookings", icon: ClipboardList },
    { name: "תמונת מצב יומית", page: "DailySnapshot", icon: Calendar },
    { name: "היסטוריית השכרות", page: "Rentals", icon: FileText },
    { name: "לקוחות", page: "Customers", icon: Users },
    { name: "רכבים", page: "Vehicles", icon: Car },
    { 
      name: "כספים", 
      icon: DollarSign,
      submenu: [
        { name: "תזרים מזומנים", page: "CashFlow" },
        { name: "רווחיות רכבים", page: "VehicleFinancials" },
        { name: "הכנסות", page: "Incomes" },
        { name: "הוצאות", page: "Expenses" }
      ]
    },
    { 
      name: "משימות", 
      icon: CheckSquare,
      submenu: [
        { name: "תפעול", page: "MaintenanceTasks" },
        { name: "גבייה", page: "CollectionTasks" },
        { name: "כלליות", page: "GeneralTasks" }
      ]
    },
    { name: "דוחות", page: "TrafficTickets", icon: FileWarning },
    { name: "כביש 6", page: "HighwayBills", icon: FileText },
    { name: "תאונות", page: "Accidents", icon: AlertTriangle },
    { name: "לוח שנה", page: "CalendarView", icon: Calendar }
  ];

  const handleLogout = () => {
    base44.auth.logout();
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      <style>{`
        :root {
          --primary: #3b50a0;
          --primary-light: #4a5fb5;
          --accent: #17a2b8;
          --accent-light: #fdb913;
        }
      `}</style>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-[#3b50a0] text-white h-16 flex items-center justify-between px-4 shadow-lg">
        <button onClick={() => setSidebarOpen(true)} className="p-2">
          <Menu className="w-6 h-6" />
        </button>
        <h1 className="text-lg font-bold">Autopo CRM</h1>
        <div className="w-10"></div>
      </div>

      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed top-0 right-0 h-full w-72 bg-[#3b50a0] text-white z-50 transform transition-transform duration-300
        lg:translate-x-0
        ${sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center p-2">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693ff630f364c7fbf1f677cd/fe961bf61_myname.jpg" 
                  alt="Autopo Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-lg font-bold">Autopo CRM</h1>
                <p className="text-xs text-blue-200">ניהול השכרת רכב</p>
              </div>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-1">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <nav className="p-4 space-y-1 overflow-y-auto h-[calc(100%-180px)]">
          {menuItems.map((item) => (
            <div key={item.name}>
              {item.submenu ? (
                <div>
                  <button
                    onClick={() => setExpandedMenu(expandedMenu === item.name ? null : item.name)}
                    className={`
                      w-full flex items-center justify-between gap-3 px-4 py-3 rounded-xl transition-all
                      hover:bg-white/10
                      ${item.submenu.some(sub => sub.page === currentPageName) ? 'bg-[#17a2b8]/20 text-[#17a2b8]' : 'text-white/80'}
                    `}
                  >
                    <div className="flex items-center gap-3">
                      <item.icon className="w-5 h-5" />
                      <span className="font-medium">{item.name}</span>
                    </div>
                    <ChevronDown className={`w-4 h-4 transition-transform ${expandedMenu === item.name ? 'rotate-180' : ''}`} />
                  </button>
                  {expandedMenu === item.name && (
                    <div className="mr-8 mt-1 space-y-1">
                      {item.submenu.map((sub) => (
                        <Link
                          key={sub.page}
                          to={createPageUrl(sub.page)}
                          onClick={() => setSidebarOpen(false)}
                          className={`
                            block px-4 py-2 rounded-lg transition-all text-sm
                            ${currentPageName === sub.page ? 'bg-[#17a2b8] text-white' : 'text-white/70 hover:bg-white/10'}
                          `}
                        >
                          {sub.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  to={createPageUrl(item.page)}
                  onClick={() => setSidebarOpen(false)}
                  className={`
                    flex items-center gap-3 px-4 py-3 rounded-xl transition-all
                    ${currentPageName === item.page ? 'bg-[#17a2b8] text-white shadow-lg shadow-[#17a2b8]/30' : 'text-white/80 hover:bg-white/10'}
                  `}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.name}</span>
                </Link>
              )}
            </div>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/10">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-white/10 transition-all"
          >
            <LogOut className="w-5 h-5" />
            <span>התנתקות</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:mr-72 min-h-screen pt-16 lg:pt-0">
        <div className="p-4 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}