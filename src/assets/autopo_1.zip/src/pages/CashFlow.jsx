import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { he } from "date-fns/locale";
import PageHeader from "@/components/shared/PageHeader";
import StatCard from "@/components/shared/StatCard";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Wallet,
  CreditCard,
  Banknote,
  Receipt
} from "lucide-react";

export default function CashFlow() {
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), "yyyy-MM"));

  const { data: incomes = [] } = useQuery({
    queryKey: ["incomes"],
    queryFn: () => base44.entities.Income.list("-date")
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ["expenses"],
    queryFn: () => base44.entities.Expense.list("-date")
  });

  const { data: rentals = [] } = useQuery({
    queryKey: ["rentals"],
    queryFn: () => base44.entities.Rental.list()
  });

  const { data: customers = [] } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list()
  });

  // Filter by selected month
  const monthStart = startOfMonth(new Date(selectedMonth));
  const monthEnd = endOfMonth(new Date(selectedMonth));

  const monthIncomes = incomes.filter(i => {
    const date = new Date(i.date);
    return date >= monthStart && date <= monthEnd;
  });

  const monthExpenses = expenses.filter(e => {
    const date = new Date(e.date);
    return date >= monthStart && date <= monthEnd;
  });

  // Calculate totals by payment method
  const cashIn = monthIncomes.filter(i => i.payment_method === "מזומן")
    .reduce((sum, i) => sum + (i.amount || 0), 0);
  const creditIn = monthIncomes.filter(i => i.payment_method === "אשראי")
    .reduce((sum, i) => sum + (i.amount || 0), 0);
  const otherIn = monthIncomes.filter(i => i.payment_method && !["מזומן", "אשראי"].includes(i.payment_method))
    .reduce((sum, i) => sum + (i.amount || 0), 0);

  const cashOut = monthExpenses.filter(e => e.payment_method === "מזומן")
    .reduce((sum, e) => sum + (e.amount || 0), 0);
  const creditOut = monthExpenses.filter(e => e.payment_method === "אשראי")
    .reduce((sum, e) => sum + (e.amount || 0), 0);
  const otherOut = monthExpenses.filter(e => e.payment_method && !["מזומן", "אשראי"].includes(e.payment_method))
    .reduce((sum, e) => sum + (e.amount || 0), 0);

  const totalIncome = cashIn + creditIn + otherIn;
  const totalExpenses = cashOut + creditOut + otherOut;
  const netCash = cashIn - cashOut;
  const netCredit = creditIn - creditOut;
  const netOther = otherIn - otherOut;
  const netTotal = totalIncome - totalExpenses;

  // Calculate expected income for the month
  const calculateExpectedIncome = () => {
    const monthStart = startOfMonth(new Date(selectedMonth));
    const monthEnd = endOfMonth(new Date(selectedMonth));
    let expected = 0;
    const missingPayments = [];

    rentals.forEach(rental => {
      if (rental.status === "בוטל") return;

      const rentalStart = new Date(rental.start_date);
      const rentalEnd = new Date(rental.actual_end_date || rental.planned_end_date);

      // Check if rental overlaps with selected month
      if (rentalEnd < monthStart || rentalStart > monthEnd) return;

      const overlapStart = rentalStart > monthStart ? rentalStart : monthStart;
      const overlapEnd = rentalEnd < monthEnd ? rentalEnd : monthEnd;
      
      // Calculate days in this month
      const daysInRental = Math.ceil((rentalEnd - rentalStart) / (1000 * 60 * 60 * 24)) || 1;
      const daysInMonth = Math.ceil((overlapEnd - overlapStart) / (1000 * 60 * 60 * 24)) + 1;
      
      // Proportional cost for this month
      const proportionalCost = (rental.total_cost || rental.base_cost || 0) * (daysInMonth / daysInRental);
      expected += proportionalCost;

      // Check for missing payments
      const customer = customers.find(c => c.id === rental.customer_id);
      const paymentTiming = customer?.payment_timing || "מראש";
      
      if (paymentTiming === "מראש") {
        // Should have paid at start - check if rental started this month
        if (rentalStart >= monthStart && rentalStart <= monthEnd) {
          if ((rental.paid_amount || 0) < proportionalCost) {
            missingPayments.push({
              customer_name: rental.customer_name,
              vehicle_details: rental.vehicle_details,
              expected: proportionalCost,
              paid: rental.paid_amount || 0,
              missing: proportionalCost - (rental.paid_amount || 0),
              timing: "מראש"
            });
          }
        }
      } else {
        // Should pay at end of month - check if rental ended this month or is still active
        const now = new Date();
        if ((rentalEnd <= monthEnd && rentalEnd >= monthStart) || 
            (rental.status === "פעיל" && now >= monthEnd)) {
          if ((rental.paid_amount || 0) < proportionalCost) {
            missingPayments.push({
              customer_name: rental.customer_name,
              vehicle_details: rental.vehicle_details,
              expected: proportionalCost,
              paid: rental.paid_amount || 0,
              missing: proportionalCost - (rental.paid_amount || 0),
              timing: "בסוף החודש"
            });
          }
        }
      }
    });

    return { expected, missingPayments };
  };

  const { expected: expectedIncome, missingPayments } = calculateExpectedIncome();

  // Group transactions by date
  const allTransactions = [
    ...monthIncomes.map(i => ({ ...i, transactionType: 'income' })),
    ...monthExpenses.map(e => ({ ...e, transactionType: 'expense' }))
  ].sort((a, b) => new Date(b.date) - new Date(a.date));

  return (
    <div>
      <PageHeader
        title="תזרים מזומנים"
        subtitle="מעקב אחר כסף בקופה ומזומנים בפועל"
      />

      {/* Month Selector */}
      <div className="mb-6">
        <Label>בחר חודש</Label>
        <Input
          type="month"
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(e.target.value)}
          className="w-48"
        />
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <StatCard
          title="הכנסות צפויות"
          value={`₪${expectedIncome.toLocaleString()}`}
          icon={TrendingUp}
          color="blue"
          subtitle="לפי השכרות פעילות"
        />
        <StatCard
          title="הכנסות בפועל"
          value={`₪${totalIncome.toLocaleString()}`}
          icon={DollarSign}
          color="green"
        />
        <StatCard
          title="סה״כ הוצאות"
          value={`₪${totalExpenses.toLocaleString()}`}
          icon={TrendingDown}
          color="red"
        />
        <StatCard
          title="רווח נקי"
          value={`₪${netTotal.toLocaleString()}`}
          icon={DollarSign}
          color={netTotal >= 0 ? "green" : "red"}
        />
        <StatCard
          title="מזומן בקופה"
          value={`₪${netCash.toLocaleString()}`}
          icon={Wallet}
          color={netCash >= 0 ? "cyan" : "orange"}
        />
      </div>

      {/* Missing Payments Alert */}
      {missingPayments.length > 0 && (
        <Card className="p-6 mb-6 bg-red-50 border-2 border-red-200">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-red-100 rounded-lg">
              <Receipt className="w-5 h-5 text-red-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-red-900 mb-2">התרעת תשלומים חסרים</h3>
              <p className="text-sm text-red-700 mb-3">
                {missingPayments.length} לקוחות עם תשלומים חסרים בחודש זה
              </p>
              <div className="space-y-2">
                {missingPayments.map((payment, i) => (
                  <div key={i} className="bg-white rounded-lg p-3 border border-red-200">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-gray-900">{payment.customer_name}</p>
                        <p className="text-sm text-gray-600">{payment.vehicle_details}</p>
                        <p className="text-xs text-red-600 mt-1">מועד תשלום: {payment.timing}</p>
                      </div>
                      <div className="text-left">
                        <p className="text-sm text-gray-600">צפוי: ₪{payment.expected.toLocaleString()}</p>
                        <p className="text-sm text-gray-600">שולם: ₪{payment.paid.toLocaleString()}</p>
                        <p className="font-bold text-red-600">חסר: ₪{payment.missing.toLocaleString()}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Payment Method Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Cash */}
        <Card className="p-6 border-r-4 border-r-green-500">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-green-100 rounded-xl">
              <Banknote className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">מזומן</h3>
              <p className="text-sm text-gray-500">תנועות במזומן</p>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">נכנס:</span>
              <span className="font-bold text-green-600">₪{cashIn.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">יצא:</span>
              <span className="font-bold text-red-600">₪{cashOut.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="font-semibold">יתרה:</span>
              <span className={`font-bold text-lg ${netCash >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ₪{netCash.toLocaleString()}
              </span>
            </div>
          </div>
        </Card>

        {/* Credit */}
        <Card className="p-6 border-r-4 border-r-blue-500">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-blue-100 rounded-xl">
              <CreditCard className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">אשראי</h3>
              <p className="text-sm text-gray-500">תנועות באשראי</p>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">נכנס:</span>
              <span className="font-bold text-green-600">₪{creditIn.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">יצא:</span>
              <span className="font-bold text-red-600">₪{creditOut.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="font-semibold">יתרה:</span>
              <span className={`font-bold text-lg ${netCredit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ₪{netCredit.toLocaleString()}
              </span>
            </div>
          </div>
        </Card>

        {/* Other */}
        <Card className="p-6 border-r-4 border-r-purple-500">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-purple-100 rounded-xl">
              <Receipt className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">אחר</h3>
              <p className="text-sm text-gray-500">צ'ק / העברה</p>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">נכנס:</span>
              <span className="font-bold text-green-600">₪{otherIn.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">יצא:</span>
              <span className="font-bold text-red-600">₪{otherOut.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="font-semibold">יתרה:</span>
              <span className={`font-bold text-lg ${netOther >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ₪{netOther.toLocaleString()}
              </span>
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Transactions */}
      <Card className="p-6">
        <h3 className="font-semibold mb-4 text-lg">תנועות אחרונות</h3>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {allTransactions.map((transaction, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <div className="flex items-center gap-3 flex-1">
                <div className={`p-2 rounded-lg ${transaction.transactionType === 'income' ? 'bg-green-100' : 'bg-red-100'}`}>
                  {transaction.transactionType === 'income' ? (
                    <TrendingUp className="w-4 h-4 text-green-600" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-600" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="font-medium">
                    {transaction.transactionType === 'income' ? 'הכנסה' : 'הוצאה'} - {transaction.type}
                  </p>
                  <p className="text-sm text-gray-500">
                    {transaction.customer_name || transaction.vehicle_details || transaction.description || '-'}
                  </p>
                </div>
                <div className="text-left">
                  <p className="text-sm text-gray-500">
                    {format(new Date(transaction.date), "dd/MM/yyyy")}
                  </p>
                  <p className="text-xs text-gray-400">
                    {transaction.payment_method || '-'}
                  </p>
                </div>
              </div>
              <span className={`font-bold text-lg ml-4 ${transaction.transactionType === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                {transaction.transactionType === 'income' ? '+' : '-'}₪{transaction.amount?.toLocaleString()}
              </span>
            </div>
          ))}
          {allTransactions.length === 0 && (
            <p className="text-center text-gray-500 py-8">אין תנועות בחודש זה</p>
          )}
        </div>
      </Card>
    </div>
  );
}