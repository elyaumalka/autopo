import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format, addDays, isWithinInterval, parseISO } from "date-fns";
import PageHeader from "@/components/shared/PageHeader";
import DataTable from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Calendar, Clock, Car, User, Search, CheckCircle, ArrowLeft, Eye, FileText, ExternalLink, CalendarDays } from "lucide-react";
import RentalStartWizard from "@/components/bookings/RentalStartWizard";
import BookingsCalendarView from "@/components/bookings/BookingsCalendarView";
import QuickBookingDialog from "@/components/bookings/QuickBookingDialog";
import RentalDetailsDialog from "@/components/rentals/RentalDetailsDialog";

export default function Bookings() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({});
  const [rentalWizardOpen, setRentalWizardOpen] = useState(false);
  const [wizardBooking, setWizardBooking] = useState(null);
  const [viewingBooking, setViewingBooking] = useState(null);
  const [activeTab, setActiveTab] = useState("calendar");
  const [quickBookingOpen, setQuickBookingOpen] = useState(false);
  const [quickBookingData, setQuickBookingData] = useState(null);
  const [viewingRental, setViewingRental] = useState(null);
  const queryClient = useQueryClient();

  const { data: bookings = [], isLoading } = useQuery({
    queryKey: ["bookings"],
    queryFn: () => base44.entities.Booking.list("-created_date")
  });

  const { data: customers = [] } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list()
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["vehicles"],
    queryFn: () => base44.entities.Vehicle.list()
  });

  const { data: rentals = [] } = useQuery({
    queryKey: ["rentals"],
    queryFn: () => base44.entities.Rental.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Booking.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["bookings"]);
      setIsOpen(false);
      resetForm();
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Booking.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["bookings"]);
      setIsOpen(false);
      resetForm();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Booking.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["bookings"])
  });

  const resetForm = () => {
    setFormData({});
    setStep(1);
    setSelectedBooking(null);
  };

  const isVehicleAvailable = (vehicleId, startDate, endDate, excludeBookingId = null) => {
    // Check overlapping bookings
    const hasOverlap = bookings.some(b => {
      if (b.id === excludeBookingId) return false;
      if (b.vehicle_id !== vehicleId) return false;
      if (b.status === "בוטל" || b.status === "הושלם") return false;

      // Date range overlap check: [startDate, endDate) 
      // End date is exclusive (vehicle available from start of end date)
      return startDate < b.end_date && endDate > b.start_date;
    });

    return !hasOverlap;
  };

  const getAvailableVehicles = () => {
    if (!formData.start_date || !formData.end_date) return [];
    return vehicles.filter(v => 
      v.status !== "נמכר" && 
      v.status !== "לא פעיל" &&
      isVehicleAvailable(v.id, formData.start_date, formData.end_date, selectedBooking?.id)
    );
  };

  const handleSubmit = () => {
    const customer = customers.find(c => c.id === formData.customer_id);
    const vehicle = vehicles.find(v => v.id === formData.vehicle_id);
    
    const data = {
      ...formData,
      customer_name: customer ? `${customer.first_name} ${customer.last_name}` : "",
      vehicle_details: vehicle ? `${vehicle.manufacturer} ${vehicle.model} - ${vehicle.license_plate}` : "",
      rental_cost: formData.rental_cost ? parseFloat(formData.rental_cost) : 0,
      deposit_amount: formData.deposit_amount ? parseFloat(formData.deposit_amount) : 0,
      credit_hold: formData.credit_hold ? parseFloat(formData.credit_hold) : 0
    };

    if (selectedBooking) {
      updateMutation.mutate({ id: selectedBooking.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const startRental = (booking) => {
    setWizardBooking(booking);
    setRentalWizardOpen(true);
  };

  const handleWizardComplete = () => {
    setRentalWizardOpen(false);
    setWizardBooking(null);
    queryClient.invalidateQueries(["bookings"]);
    queryClient.invalidateQueries(["rentals"]);
    queryClient.invalidateQueries(["vehicles"]);
    queryClient.invalidateQueries(["incomes"]);
  };

  const handleCalendarCellClick = (date, vehicle, booking) => {
    if (booking) {
      // יש הזמנה קיימת
      if (booking.status === "פעיל") {
        // השכרה פעילה - פתח את חלונית עריכת השכרה
        const rental = rentals.find(r => r.booking_id === booking.id);
        if (rental) {
          setViewingRental(rental);
        }
      } else if (booking.status === "מאושר") {
        // הזמנה מאושרת - התחל השכרה
        startRental(booking);
      } else {
        // הזמנה אחרת - פתח לעריכה
        setSelectedBooking(booking);
        setFormData(booking);
        setStep(1);
        setIsOpen(true);
      }
    } else {
      // תא ריק - פתח שריון מהיר
      setQuickBookingData({ date: format(new Date(date), "yyyy-MM-dd"), vehicle });
      setQuickBookingOpen(true);
    }
  };

  const handleQuickBookingSubmit = async (bookingData) => {
    // Check for conflicts before creating
    if (!isVehicleAvailable(bookingData.vehicle_id, bookingData.start_date, bookingData.end_date)) {
      alert('הרכב כבר תפוס בתאריכים אלו. אנא בחר תאריכים אחרים.');
      return;
    }
    
    await createMutation.mutateAsync(bookingData);
    setQuickBookingOpen(false);
    setQuickBookingData(null);
  };

  const filteredBookings = bookings.filter(b => {
    const matchesSearch = 
      b.customer_name?.includes(searchTerm) ||
      b.vehicle_details?.includes(searchTerm);
    const matchesStatus = statusFilter === "all" || b.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const columns = [
    {
      header: "פעולות",
      cell: (row) => (
        <div className="flex gap-2 justify-end">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              setSelectedBooking(row);
              setFormData(row);
              setStep(1);
              setIsOpen(true);
            }}
          >
            עריכה
          </Button>
          {(row.status === "מאושר" || row.status === "ממתין") && (
            <Button 
              variant="outline" 
              size="sm"
              className="text-red-600 hover:text-red-700"
              onClick={() => deleteMutation.mutate(row.id)}
            >
              מחק
            </Button>
          )}
          {row.status === "מאושר" && (
            <Button 
              size="sm" 
              className="bg-green-600 hover:bg-green-700"
              onClick={() => startRental(row)}
            >
              <CheckCircle className="w-4 h-4 ml-1" />
              התחל השכרה
            </Button>
          )}
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setViewingBooking(row)}
          >
            <Eye className="w-4 h-4" />
          </Button>
        </div>
      )
    },
    {
      header: "סטטוס",
      cell: (row) => <StatusBadge status={row.status || "ממתין"} />
    },
    {
      header: "תשלום",
      cell: (row) => {
        const total = row.rental_cost || 0;
        const paid = row.deposit_amount || 0;
        const remaining = total - paid;
        
        return (
          <div className="text-sm">
            <div className="font-medium">₪{total.toLocaleString()}</div>
            {paid > 0 && (
              <div className="text-green-600">שולם: ₪{paid.toLocaleString()}</div>
            )}
            {remaining > 0 && (
              <div className="text-red-600">נותר: ₪{remaining.toLocaleString()}</div>
            )}
          </div>
        );
      }
    },
    {
      header: "תאריך סיום",
      cell: (row) => (
        <div className="text-sm">
          {row.end_date ? format(new Date(row.end_date), "dd/MM/yy") : "-"}
        </div>
      )
    },
    {
      header: "תאריך התחלה",
      cell: (row) => (
        <div className="text-sm">
          {row.start_date ? format(new Date(row.start_date), "dd/MM/yy") : "-"}
        </div>
      )
    },
    {
      header: "רכב",
      cell: (row) => (
        <div className="flex items-center gap-2 justify-end">
          <span>{row.vehicle_details}</span>
          <Car className="w-4 h-4 text-gray-400" />
        </div>
      )
    },
    {
      header: "לקוח",
      cell: (row) => (
        <div className="flex items-center gap-2 justify-end">
          <span className="font-medium">{row.customer_name}</span>
          <User className="w-4 h-4 text-gray-400" />
        </div>
      )
    }
  ];

  return (
    <div>
      <PageHeader
        title="הזמנות"
        subtitle={`${bookings.length} הזמנות`}
        action={() => { resetForm(); setIsOpen(true); }}
        actionLabel="הזמנה חדשה"
      />

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="flex flex-row-reverse">
          <TabsTrigger value="calendar">
            <CalendarDays className="w-4 h-4 ml-2" />
            תמונת מצב
          </TabsTrigger>
          <TabsTrigger value="list">
            <FileText className="w-4 h-4 ml-2" />
            רשימת הזמנות
          </TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-6 mt-6">
          <div className="flex flex-col sm:flex-row gap-4 sm:flex-row-reverse">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="חיפוש..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10"
          />
        </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">הכל</SelectItem>
                <SelectItem value="מאושר">מאושר</SelectItem>
                <SelectItem value="פעיל">פעיל</SelectItem>
                <SelectItem value="הושלם">הושלם</SelectItem>
                <SelectItem value="בוטל">בוטל</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <DataTable
            columns={columns}
            data={filteredBookings}
            isLoading={isLoading}
            emptyMessage="לא נמצאו הזמנות"
          />
        </TabsContent>

        <TabsContent value="calendar" className="mt-6">
          <BookingsCalendarView 
            bookings={bookings} 
            vehicles={vehicles}
            onCellClick={handleCalendarCellClick}
          />
        </TabsContent>
      </Tabs>

      {/* Quick Booking Dialog */}
      {quickBookingData && (
        <QuickBookingDialog
          isOpen={quickBookingOpen}
          onClose={() => {
            setQuickBookingOpen(false);
            setQuickBookingData(null);
          }}
          onSubmit={handleQuickBookingSubmit}
          onSubmitAndStart={async (bookingData) => {
            // Check for conflicts before creating
            if (!isVehicleAvailable(bookingData.vehicle_id, bookingData.start_date, bookingData.end_date)) {
              alert('הרכב כבר תפוס בתאריכים אלו. אנא בחר תאריכים אחרים.');
              return;
            }
            
            const newBooking = await createMutation.mutateAsync(bookingData);
            setQuickBookingOpen(false);
            setQuickBookingData(null);
            setWizardBooking(newBooking);
            setRentalWizardOpen(true);
          }}
          date={quickBookingData.date}
          vehicle={quickBookingData.vehicle}
          customers={customers}
        />
      )}

      {/* Rental Details Dialog */}
      <RentalDetailsDialog
        rental={viewingRental}
        isOpen={!!viewingRental}
        onClose={() => setViewingRental(null)}
      />

      {/* Rental Start Wizard */}
      <Dialog open={rentalWizardOpen} onOpenChange={setRentalWizardOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>תחילת השכרה</DialogTitle>
          </DialogHeader>
          {wizardBooking && (
            <RentalStartWizard
              booking={wizardBooking}
              customer={customers.find(c => c.id === wizardBooking.customer_id)}
              vehicle={vehicles.find(v => v.id === wizardBooking.vehicle_id)}
              onComplete={handleWizardComplete}
              onCancel={() => setRentalWizardOpen(false)}
              onEditBooking={() => {
                setRentalWizardOpen(false);
                setSelectedBooking(wizardBooking);
                setFormData(wizardBooking);
                setStep(1);
                setIsOpen(true);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isOpen} onOpenChange={(open) => { setIsOpen(open); if (!open) resetForm(); }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedBooking ? "עריכת הזמנה" : "הזמנה חדשה"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Progress Steps */}
            <div className="flex items-center justify-between mb-6">
              {["תאריכים", "רכב", "פרטים"].map((s, i) => (
                <div key={i} className="flex items-center">
                  <div className={`
                    w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
                    ${step > i + 1 ? 'bg-cyan-600 text-white' : step === i + 1 ? 'bg-cyan-600 text-white' : 'bg-gray-200 text-gray-500'}
                  `}>
                    {i + 1}
                  </div>
                  <span className={`mr-2 text-sm ${step >= i + 1 ? 'text-gray-900' : 'text-gray-400'}`}>{s}</span>
                  {i < 2 && <div className="w-12 h-0.5 bg-gray-200 mx-2" />}
                </div>
              ))}
            </div>

            {step === 1 && (
              <div className="space-y-4">
                <div>
                  <Label>לקוח *</Label>
                  <Select 
                    value={formData.customer_id || ""} 
                    onValueChange={(v) => setFormData({ ...formData, customer_id: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="בחר לקוח" />
                    </SelectTrigger>
                    <SelectContent>
                      {customers.map(c => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.first_name} {c.last_name} - {c.phone}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>תאריך התחלה *</Label>
                    <Input
                      type="date"
                      value={formData.start_date || ""}
                      onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>שעת התחלה</Label>
                    <Input
                      type="time"
                      value={formData.start_time || ""}
                      onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>תאריך סיום *</Label>
                    <Input
                      type="date"
                      value={formData.end_date || ""}
                      onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>שעת סיום</Label>
                    <Input
                      type="time"
                      value={formData.end_time || ""}
                      onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                    />
                  </div>
                </div>

                {selectedBooking && (
                  <div className="flex gap-3 pt-4 border-t">
                    <Button 
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        if (confirm('האם אתה בטוח שברצונך לבטל הזמנה זו?')) {
                          deleteMutation.mutate(selectedBooking.id);
                          setIsOpen(false);
                        }
                      }}
                    >
                      ביטול הזמנה
                    </Button>
                    <Button 
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        setFormData({ ...formData, customer_id: "" });
                        setStep(1);
                      }}
                    >
                      שרייון ללקוח אחר
                    </Button>
                  </div>
                )}

                <Button 
                  onClick={() => setStep(2)}
                  disabled={!formData.customer_id || !formData.start_date || !formData.end_date}
                  className="w-full bg-cyan-600 hover:bg-cyan-700"
                >
                  המשך
                  <ArrowLeft className="w-4 h-4 mr-2" />
                </Button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <h3 className="font-semibold">רכבים זמינים בתאריכים הנבחרים</h3>
                
                {getAvailableVehicles().length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    אין רכבים זמינים בתאריכים אלו
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-3 max-h-80 overflow-y-auto">
                    {getAvailableVehicles().map(vehicle => (
                      <Card
                        key={vehicle.id}
                        className={`p-4 cursor-pointer transition-all ${
                          formData.vehicle_id === vehicle.id 
                            ? 'border-2 border-cyan-600 bg-cyan-50' 
                            : 'hover:border-gray-300'
                        }`}
                        onClick={() => setFormData({ ...formData, vehicle_id: vehicle.id })}
                      >
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{vehicle.manufacturer} {vehicle.model}</p>
                            <p className="text-sm text-gray-500">{vehicle.license_plate} | {vehicle.vehicle_type}</p>
                          </div>
                          <div className="text-left">
                            <p className="font-bold text-cyan-600">₪{vehicle.daily_rate}/יום</p>
                            <p className="text-sm text-gray-500">₪{vehicle.monthly_rate}/חודש</p>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}

                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setStep(1)}>חזרה</Button>
                  <Button 
                    onClick={() => setStep(3)}
                    disabled={!formData.vehicle_id}
                    className="flex-1 bg-cyan-600 hover:bg-cyan-700"
                  >
                    המשך
                  </Button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>עלות השכרה</Label>
                    <Input
                      type="number"
                      value={formData.rental_cost || ""}
                      onChange={(e) => setFormData({ ...formData, rental_cost: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>סכום מקדמה</Label>
                    <Input
                      type="number"
                      value={formData.deposit_amount || ""}
                      onChange={(e) => setFormData({ ...formData, deposit_amount: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>מסגרת אשראי</Label>
                    <Input
                      type="number"
                      value={formData.credit_hold || ""}
                      onChange={(e) => setFormData({ ...formData, credit_hold: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>אמצעי תשלום</Label>
                    <Select 
                      value={formData.payment_method || ""} 
                      onValueChange={(v) => setFormData({ ...formData, payment_method: v })}
                    >
                      <SelectTrigger><SelectValue placeholder="בחר" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="מזומן">מזומן</SelectItem>
                        <SelectItem value="אשראי">אשראי</SelectItem>
                        <SelectItem value="צ'ק">צ'ק</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>סטטוס תשלום</Label>
                    <Select 
                      value={formData.payment_status || "לא שולם"} 
                      onValueChange={(v) => setFormData({ ...formData, payment_status: v })}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="לא שולם">לא שולם</SelectItem>
                        <SelectItem value="מקדמה">מקדמה</SelectItem>
                        <SelectItem value="שולם">שולם</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>סטטוס הזמנה</Label>
                    <Select 
                      value={formData.status || "מאושר"} 
                      onValueChange={(v) => setFormData({ ...formData, status: v })}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="מאושר">מאושר</SelectItem>
                        <SelectItem value="בוטל">בוטל</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox
                    id="extension"
                    checked={formData.extension_option || false}
                    onCheckedChange={(c) => setFormData({ ...formData, extension_option: c })}
                  />
                  <Label htmlFor="extension">אופציה להארכה</Label>
                </div>

                <div>
                  <Label>הערות</Label>
                  <Textarea
                    value={formData.notes || ""}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>

                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setStep(2)}>חזרה</Button>
                  <Button 
                    onClick={handleSubmit}
                    className="flex-1 bg-cyan-600 hover:bg-cyan-700"
                  >
                    {selectedBooking ? "עדכון" : "יצירת הזמנה"}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* View Booking Details Dialog */}
      <Dialog open={!!viewingBooking} onOpenChange={() => setViewingBooking(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>פרטי הזמנה</DialogTitle>
          </DialogHeader>

          {viewingBooking && (
            <div className="space-y-6">
              {/* Basic Info */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <Label className="text-gray-500">לקוח</Label>
                  <p className="font-medium">{viewingBooking.customer_name}</p>
                </div>
                <div>
                  <Label className="text-gray-500">רכב</Label>
                  <p className="font-medium">{viewingBooking.vehicle_details}</p>
                </div>
                <div>
                  <Label className="text-gray-500">תאריך התחלה</Label>
                  <p className="font-medium">
                    {viewingBooking.start_date} {viewingBooking.start_time || ""}
                  </p>
                </div>
                <div>
                  <Label className="text-gray-500">תאריך סיום</Label>
                  <p className="font-medium">
                    {viewingBooking.end_date} {viewingBooking.end_time || ""}
                  </p>
                </div>
                <div>
                  <Label className="text-gray-500">עלות</Label>
                  <p className="font-medium text-lg">₪{viewingBooking.rental_cost?.toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-gray-500">סטטוס</Label>
                  <StatusBadge status={viewingBooking.status} />
                </div>
              </div>

              {/* Documents Status */}
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-4">מסמכים וחתימות</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-blue-600" />
                        <span className="font-medium">חוזה השכרה</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {viewingBooking.contract_signed ? (
                          <>
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            <span className="text-green-600 font-medium">נחתם</span>
                            {viewingBooking.contract_url && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  if (viewingBooking.contract_url.startsWith('data:')) {
                                    const win = window.open();
                                    win.document.write(`<img src="${viewingBooking.contract_url}" style="max-width:100%"/>`);
                                  } else {
                                    window.open(viewingBooking.contract_url, '_blank');
                                  }
                                }}
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                            )}
                          </>
                        ) : viewingBooking.contract_url ? (
                          <span className="text-yellow-600">נשלח - ממתין לחתימה</span>
                        ) : (
                          <span className="text-gray-400">טרם נשלח</span>
                        )}
                      </div>
                    </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-purple-600" />
                        <span className="font-medium">תצהיר קבלת רכב</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {viewingBooking.declaration_signed ? (
                          <>
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            <span className="text-green-600 font-medium">נחתם</span>
                            {viewingBooking.declaration_url && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  if (viewingBooking.declaration_url.startsWith('data:')) {
                                    const win = window.open();
                                    win.document.write(`<img src="${viewingBooking.declaration_url}" style="max-width:100%"/>`);
                                  } else {
                                    window.open(viewingBooking.declaration_url, '_blank');
                                  }
                                }}
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                            )}
                          </>
                        ) : viewingBooking.declaration_url ? (
                          <span className="text-yellow-600">נשלח - ממתין לחתימה</span>
                        ) : (
                          <span className="text-gray-400">טרם נשלח</span>
                        )}
                      </div>
                    </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-red-600" />
                        <span className="font-medium">כתב ויתור</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {viewingBooking.waiver_signed ? (
                          <>
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            <span className="text-green-600 font-medium">נחתם</span>
                            {viewingBooking.waiver_url && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  if (viewingBooking.waiver_url.startsWith('data:')) {
                                    const win = window.open();
                                    win.document.write(`<img src="${viewingBooking.waiver_url}" style="max-width:100%"/>`);
                                  } else {
                                    window.open(viewingBooking.waiver_url, '_blank');
                                  }
                                }}
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                            )}
                          </>
                        ) : viewingBooking.waiver_url ? (
                          <span className="text-yellow-600">נשלח - ממתין לחתימה</span>
                        ) : (
                          <span className="text-gray-400">טרם נשלח</span>
                        )}
                      </div>
                    </div>
                </div>
              </div>

              {/* Payment Info */}
              {(viewingBooking.deposit_amount || viewingBooking.credit_hold) && (
                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-4">תשלום</h3>
                  <div className="space-y-2">
                    {viewingBooking.deposit_amount && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">מקדמה:</span>
                        <span className="font-medium">₪{viewingBooking.deposit_amount.toLocaleString()}</span>
                      </div>
                    )}
                    {viewingBooking.credit_hold && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">מסגרת אשראי:</span>
                        <span className="font-medium">₪{viewingBooking.credit_hold.toLocaleString()}</span>
                      </div>
                    )}
                    {viewingBooking.payment_method && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">אמצעי תשלום:</span>
                        <span className="font-medium">{viewingBooking.payment_method}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Notes */}
              {viewingBooking.notes && (
                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-2">הערות</h3>
                  <p className="text-gray-600 whitespace-pre-wrap">{viewingBooking.notes}</p>
                </div>
              )}

              <Button onClick={() => setViewingBooking(null)} className="w-full">
                סגור
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}