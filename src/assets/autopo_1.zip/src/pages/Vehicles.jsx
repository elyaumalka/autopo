import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import PageHeader from "@/components/shared/PageHeader";
import StatusBadge from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, Edit, Trash2, Eye, Car, Fuel, Calendar, Gauge, 
  DollarSign, Key, Settings
} from "lucide-react";
import { motion } from "framer-motion";

export default function Vehicles() {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [viewMode, setViewMode] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [formState, setFormState] = useState({});
  const queryClient = useQueryClient();

  const { data: vehicles = [], isLoading } = useQuery({
    queryKey: ["vehicles"],
    queryFn: () => base44.entities.Vehicle.list("-created_date")
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      // Validate required fields
      if (!data.license_plate || !data.manufacturer || !data.model) {
        throw new Error('חובה למלא: מספר רישוי, יצרן ודגם');
      }
      
      // Remove empty string values - convert to null or remove
      Object.keys(data).forEach(key => {
        if (data[key] === '') {
          delete data[key];
        }
      });
      
      console.log('Creating vehicle with data:', data);
      return base44.entities.Vehicle.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["vehicles"]);
      setIsOpen(false);
      setSelectedVehicle(null);
      setFormState({});
    },
    onError: (error) => {
      console.error('Error creating vehicle:', error);
      console.error('Error response:', error.response?.data);
      alert('שגיאה ביצירת רכב: ' + (error.response?.data?.message || error.message || 'שגיאה לא ידועה'));
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => {
      // Remove empty string values
      Object.keys(data).forEach(key => {
        if (data[key] === '') {
          delete data[key];
        }
      });
      console.log('Updating vehicle with data:', data);
      return base44.entities.Vehicle.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["vehicles"]);
      setIsOpen(false);
      setSelectedVehicle(null);
      setFormState({});
    },
    onError: (error) => {
      console.error('Error updating vehicle:', error);
      console.error('Error response:', error.response?.data);
      alert('שגיאה בעדכון רכב: ' + (error.response?.data?.message || error.message || 'שגיאה לא ידועה'));
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Vehicle.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["vehicles"])
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    
    // Merge with existing formState to preserve values from other tabs
    const mergedData = { ...formState, ...data };
    
    console.log('Form data:', mergedData);
    
    // Convert numeric fields
    const numericFields = [
      'year', 'license_fee', 'current_km', 'last_service_km', 'km_to_next_service',
      'monthly_rate', 'daily_rate', 'half_day_rate', 'km_limit', 'extra_km_price',
      'hourly_delay_rate', 'hand', 'purchase_price', 'keys_count', 'total_income',
      'sale_price'
    ];
    numericFields.forEach(field => {
      if (mergedData[field] && mergedData[field] !== '') mergedData[field] = parseFloat(mergedData[field]);
    });

    if (selectedVehicle) {
      updateMutation.mutate({ id: selectedVehicle.id, data: mergedData });
    } else {
      createMutation.mutate(mergedData);
    }
  };
  
  const handleFieldChange = (e) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
  };

  const filteredVehicles = vehicles.filter(v => {
    const matchesSearch = 
      v.license_plate?.includes(searchTerm) ||
      v.manufacturer?.includes(searchTerm) ||
      v.model?.includes(searchTerm);
    const matchesStatus = statusFilter === "all" || v.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusColors = {
    "זמין": "border-green-200 bg-green-50",
    "מושכר": "border-blue-200 bg-blue-50",
    "בטיפול": "border-orange-200 bg-orange-50",
    "לא פעיל": "border-gray-200 bg-gray-50",
    "נמכר": "border-purple-200 bg-purple-50"
  };

  return (
    <div>
      <PageHeader
        title="רכבים"
        subtitle={`${vehicles.length} רכבים | ${vehicles.filter(v => v.status === "זמין").length} זמינים`}
        action={() => { setSelectedVehicle(null); setViewMode(false); setFormState({}); setIsOpen(true); }}
        actionLabel="רכב חדש"
      />

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="חיפוש לפי מספר רישוי, יצרן או דגם..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="סינון סטטוס" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">הכל</SelectItem>
            <SelectItem value="זמין">זמין</SelectItem>
            <SelectItem value="מושכר">מושכר</SelectItem>
            <SelectItem value="בטיפול">בטיפול</SelectItem>
            <SelectItem value="לא פעיל">לא פעיל</SelectItem>
            <SelectItem value="נמכר">נמכר</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="p-6 animate-pulse">
              <div className="h-32 bg-gray-200 rounded-lg mb-4" />
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
              <div className="h-4 bg-gray-200 rounded w-1/2" />
            </Card>
          ))}
        </div>
      ) : filteredVehicles.length === 0 ? (
        <div className="text-center py-12 text-gray-500">לא נמצאו רכבים</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredVehicles.map((vehicle, i) => (
            <motion.div
              key={vehicle.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card 
                className={`p-5 border-2 transition-all hover:shadow-lg cursor-pointer ${statusColors[vehicle.status] || 'border-gray-200'}`}
                onClick={() => { setSelectedVehicle(vehicle); setViewMode(true); setFormState(vehicle); setIsOpen(true); }}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-bold text-lg">{vehicle.manufacturer} {vehicle.model}</h3>
                    <p className="text-gray-500 text-sm">{vehicle.license_plate}</p>
                  </div>
                  <StatusBadge status={vehicle.status || "זמין"} />
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>{vehicle.year}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Fuel className="w-4 h-4" />
                    <span>{vehicle.fuel_type || "-"}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Gauge className="w-4 h-4" />
                    <span>{vehicle.current_km?.toLocaleString() || 0} ק"מ</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Car className="w-4 h-4" />
                    <span>{vehicle.vehicle_type || "-"}</span>
                  </div>
                </div>

                {/* Alerts */}
                {(() => {
                  const needsTest = vehicle.test_date && new Date(vehicle.test_date) < new Date();
                  const needsService = vehicle.next_service_date && new Date(vehicle.next_service_date) < new Date();
                  if (needsTest || needsService) {
                    return (
                      <div className="mt-3 p-2 bg-red-100 border border-red-300 rounded text-xs text-red-800">
                        {needsTest && <div>⚠️ דרוש טסט</div>}
                        {needsService && <div>⚠️ דרוש טיפול</div>}
                      </div>
                    );
                  }
                })()}

                <div className="flex items-center justify-between pt-3 border-t">
                  <div className="text-cyan-600 font-bold">
                    ₪{vehicle.daily_rate?.toLocaleString() || 0} / יום
                  </div>
                  <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => { setSelectedVehicle(vehicle); setViewMode(false); setFormState(vehicle); setIsOpen(true); }}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      className="text-red-500"
                      onClick={() => deleteMutation.mutate(vehicle.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {viewMode ? "פרטי רכב" : selectedVehicle ? "עריכת רכב" : "רכב חדש"}
            </DialogTitle>
          </DialogHeader>

          {viewMode && selectedVehicle ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-gray-500">מספר רישוי</Label>
                  <p className="font-medium">{selectedVehicle.license_plate}</p>
                </div>
                <div>
                  <Label className="text-gray-500">יצרן / דגם</Label>
                  <p className="font-medium">{selectedVehicle.manufacturer} {selectedVehicle.model}</p>
                </div>
                <div>
                  <Label className="text-gray-500">שנת ייצור</Label>
                  <p className="font-medium">{selectedVehicle.year}</p>
                </div>
                <div>
                  <Label className="text-gray-500">צבע</Label>
                  <p className="font-medium">{selectedVehicle.color || "-"}</p>
                </div>
                <div>
                  <Label className="text-gray-500">סוג דלק</Label>
                  <p className="font-medium">{selectedVehicle.fuel_type || "-"}</p>
                </div>
                <div>
                  <Label className="text-gray-500">ק"מ נוכחי</Label>
                  <p className="font-medium">{selectedVehicle.current_km?.toLocaleString() || 0}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 p-4 bg-cyan-50 rounded-xl">
                <div className="text-center">
                  <p className="text-sm text-gray-500">יומי</p>
                  <p className="font-bold text-cyan-600">₪{selectedVehicle.daily_rate || 0}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-500">חצי יום</p>
                  <p className="font-bold text-cyan-600">₪{selectedVehicle.half_day_rate || 0}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-500">חודשי</p>
                  <p className="font-bold text-cyan-600">₪{selectedVehicle.monthly_rate || 0}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-500">מחיר קנייה</Label>
                  <p className="font-medium">₪{selectedVehicle.purchase_price?.toLocaleString() || 0}</p>
                </div>
                <div>
                  <Label className="text-gray-500">סך הכנסות</Label>
                  <p className="font-medium text-green-600">₪{selectedVehicle.total_income?.toLocaleString() || 0}</p>
                </div>
              </div>

              <Button onClick={() => setViewMode(false)} className="w-full">
                עריכה
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} key={selectedVehicle?.id || 'new'}>
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid w-full grid-cols-4 mb-4">
                  <TabsTrigger value="basic">בסיסי</TabsTrigger>
                  <TabsTrigger value="rates">תעריפים</TabsTrigger>
                  <TabsTrigger value="service">טיפולים</TabsTrigger>
                  <TabsTrigger value="docs">מסמכים</TabsTrigger>
                </TabsList>

                <TabsContent value="basic" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>מספר רישוי *</Label>
                      <Input 
                        name="license_plate" 
                        value={formState.license_plate || ''} 
                        onChange={handleFieldChange}
                        required 
                      />
                    </div>
                    <div>
                      <Label>סוג רכב</Label>
                      <select 
                        name="vehicle_type" 
                        value={formState.vehicle_type || ''}
                        onChange={handleFieldChange}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <option value="">בחר סוג</option>
                        <option value="5 מקומות">5 מקומות</option>
                        <option value="7 מקומות">7 מקומות</option>
                      </select>
                    </div>
                    <div>
                      <Label>יצרן *</Label>
                      <Input 
                        name="manufacturer" 
                        value={formState.manufacturer || ''} 
                        onChange={handleFieldChange}
                        required 
                      />
                    </div>
                    <div>
                      <Label>דגם *</Label>
                      <Input 
                        name="model" 
                        value={formState.model || ''} 
                        onChange={handleFieldChange}
                        required 
                      />
                    </div>
                    <div>
                      <Label>צבע</Label>
                      <Input 
                        name="color" 
                        value={formState.color || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>שנת ייצור</Label>
                      <Input 
                        name="year" 
                        type="number" 
                        value={formState.year || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>סוג דלק</Label>
                      <select 
                        name="fuel_type" 
                        value={formState.fuel_type || ''}
                        onChange={handleFieldChange}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <option value="">בחר סוג דלק</option>
                        <option value="בנזין">בנזין</option>
                        <option value="דיזל">דיזל</option>
                        <option value="היברידי">היברידי</option>
                        <option value="חשמלי">חשמלי</option>
                      </select>
                    </div>
                    <div>
                      <Label>יד</Label>
                      <Input 
                        name="hand" 
                        type="number" 
                        value={formState.hand || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>תוקף רישוי</Label>
                      <Input 
                        name="license_expiry" 
                        type="date" 
                        value={formState.license_expiry || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>סטטוס</Label>
                      <select 
                        name="status" 
                        value={formState.status || "זמין"}
                        onChange={handleFieldChange}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <option value="זמין">זמין</option>
                        <option value="מושכר">מושכר</option>
                        <option value="בטיפול">בטיפול</option>
                        <option value="לא פעיל">לא פעיל</option>
                        <option value="נמכר">נמכר</option>
                      </select>
                    </div>
                    <div>
                      <Label>כמות מפתחות</Label>
                      <Input 
                        name="keys_count" 
                        type="number" 
                        value={formState.keys_count || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>קוד לרכב</Label>
                      <Input 
                        name="vehicle_code" 
                        value={formState.vehicle_code || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="rates" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>תעריף יומי</Label>
                      <Input 
                        name="daily_rate" 
                        type="number" 
                        value={formState.daily_rate || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>תעריף חצי יום</Label>
                      <Input 
                        name="half_day_rate" 
                        type="number" 
                        value={formState.half_day_rate || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>תעריף חודשי</Label>
                      <Input 
                        name="monthly_rate" 
                        type="number" 
                        value={formState.monthly_rate || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>הגבלת ק"מ</Label>
                      <Input 
                        name="km_limit" 
                        type="number" 
                        value={formState.km_limit || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>מחיר קילומטר נוסף</Label>
                      <Input 
                        name="extra_km_price" 
                        type="number" 
                        step="0.1" 
                        value={formState.extra_km_price || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>תעריף איחור שעתי</Label>
                      <Input 
                        name="hourly_delay_rate" 
                        type="number" 
                        value={formState.hourly_delay_rate || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="service" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>תאריך קנייה</Label>
                      <Input 
                        name="purchase_date" 
                        type="date" 
                        value={formState.purchase_date || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>מחיר קנייה</Label>
                      <Input 
                        name="purchase_price" 
                        type="number" 
                        value={formState.purchase_price || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>תאריך טסט</Label>
                      <Input 
                        name="test_date" 
                        type="date" 
                        value={formState.test_date || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>תאריך טיפול אחרון</Label>
                      <Input 
                        name="last_service_date" 
                        type="date" 
                        value={formState.last_service_date || ''} 
                        onChange={(e) => {
                          const date = e.target.value;
                          handleFieldChange(e);
                          // Calculate next service date (4 months later)
                          if (date) {
                            const serviceDate = new Date(date);
                            serviceDate.setMonth(serviceDate.getMonth() + 4);
                            setFormState(prev => ({ 
                              ...prev, 
                              last_service_date: date,
                              next_service_date: format(serviceDate, 'yyyy-MM-dd')
                            }));
                          }
                        }}
                      />
                    </div>
                    <div>
                      <Label>תאריך טיפול הבא (אוטומטי)</Label>
                      <Input 
                        name="next_service_date" 
                        type="date" 
                        value={formState.next_service_date || ''} 
                        disabled
                        className="bg-gray-50"
                      />
                    </div>
                    <div>
                      <Label>החלפת בלמים אחרון</Label>
                      <Input 
                        name="last_brake_replacement" 
                        type="date" 
                        value={formState.last_brake_replacement || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>שטיפה אחרונה</Label>
                      <Input 
                        name="last_wash_date" 
                        type="date" 
                        value={formState.last_wash_date || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>בדיקת בטיחות אחרונה</Label>
                      <Input 
                        name="last_safety_check" 
                        type="date" 
                        value={formState.last_safety_check || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>ק"מ נוכחי</Label>
                      <Input 
                        name="current_km" 
                        type="number" 
                        value={formState.current_km || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                    <div>
                      <Label>סך הכנסות</Label>
                      <Input 
                        name="total_income" 
                        type="number" 
                        value={formState.total_income || ''} 
                        onChange={handleFieldChange}
                      />
                    </div>
                  </div>
                  <div>
                    <Label>הערות</Label>
                    <Textarea 
                      name="notes" 
                      value={formState.notes || ''} 
                      onChange={handleFieldChange}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="docs" className="space-y-4">
                  <div className="space-y-4">
                    <div>
                      <Label>רישיון רכב</Label>
                      <Input
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const result = await base44.integrations.Core.UploadFile({ file });
                            setFormState(prev => ({ ...prev, vehicle_license_doc: result.file_url }));
                          }
                        }}
                      />
                      {formState.vehicle_license_doc && (
                        <div className="mt-2 flex items-center gap-2">
                          <a
                            href={formState.vehicle_license_doc}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-cyan-600 hover:underline text-sm"
                          >
                            צפה במסמך
                          </a>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const link = document.createElement('a');
                              link.href = formState.vehicle_license_doc;
                              link.download = 'vehicle_license.pdf';
                              link.click();
                            }}
                          >
                            הורד
                          </Button>
                        </div>
                      )}
                    </div>

                    <div>
                      <Label>ביטוח</Label>
                      <Input
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const result = await base44.integrations.Core.UploadFile({ file });
                            setFormState(prev => ({ ...prev, insurance_doc: result.file_url }));
                          }
                        }}
                      />
                      {formState.insurance_doc && (
                        <div className="mt-2 flex items-center gap-2">
                          <a
                            href={formState.insurance_doc}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-cyan-600 hover:underline text-sm"
                          >
                            צפה במסמך
                          </a>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const link = document.createElement('a');
                              link.href = formState.insurance_doc;
                              link.download = 'insurance.pdf';
                              link.click();
                            }}
                          >
                            הורד
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              <div className="flex gap-3 pt-4 mt-4 border-t">
                <Button type="submit" className="flex-1 bg-cyan-600 hover:bg-cyan-700">
                  {selectedVehicle ? "עדכון" : "יצירה"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                  ביטול
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}