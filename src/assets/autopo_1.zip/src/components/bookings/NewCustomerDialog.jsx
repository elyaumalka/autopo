import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Upload, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function NewCustomerDialog({ isOpen, onClose, onCustomerCreated, initialName }) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    first_name: initialName?.split(' ')[0] || "",
    last_name: initialName?.split(' ').slice(1).join(' ') || "",
    phone: "",
    email: "",
    id_number: "",
    address: "",
    city: "",
  });
  const [licenseFront, setLicenseFront] = useState(null);
  const [licenseBack, setLicenseBack] = useState(null);

  const handleFileUpload = async (file, type) => {
    if (!file) return null;
    
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      return result.file_url;
    } catch (error) {
      console.error('Error uploading file:', error);
      return null;
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      // Upload license images
      const frontUrl = licenseFront ? await handleFileUpload(licenseFront, 'front') : null;
      const backUrl = licenseBack ? await handleFileUpload(licenseBack, 'back') : null;

      // Create customer
      const customerData = {
        ...formData,
        license_front_image: frontUrl,
        license_back_image: backUrl,
      };

      const newCustomer = await base44.entities.Customer.create(customerData);
      onCustomerCreated(newCustomer);
    } catch (error) {
      console.error('Error creating customer:', error);
      alert('שגיאה ביצירת לקוח');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>הוספת לקוח חדש</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>שם פרטי *</Label>
              <Input
                value={formData.first_name}
                onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                placeholder="שם פרטי"
              />
            </div>
            <div>
              <Label>שם משפחה *</Label>
              <Input
                value={formData.last_name}
                onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                placeholder="שם משפחה"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>טלפון *</Label>
              <Input
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="טלפון"
              />
            </div>
            <div>
              <Label>ת.ז. *</Label>
              <Input
                value={formData.id_number}
                onChange={(e) => setFormData({ ...formData, id_number: e.target.value })}
                placeholder="מספר תעודת זהות"
              />
            </div>
          </div>

          <div>
            <Label>אימייל</Label>
            <Input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="כתובת אימייל"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>כתובת</Label>
              <Input
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="כתובת"
              />
            </div>
            <div>
              <Label>עיר</Label>
              <Input
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                placeholder="עיר"
              />
            </div>
          </div>

          <div className="border-t pt-4">
            <h3 className="font-semibold mb-3">רישיון נהיגה</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>צד קדמי</Label>
                <div className="mt-2">
                  <label className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-gray-400">
                    <div className="text-center">
                      {licenseFront ? (
                        <div className="text-sm text-green-600">✓ קובץ נבחר</div>
                      ) : (
                        <>
                          <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                          <div className="text-sm text-gray-500">העלה תמונה</div>
                        </>
                      )}
                    </div>
                    <input
                      type="file"
                      className="hidden"
                      accept="image/*"
                      onChange={(e) => setLicenseFront(e.target.files[0])}
                    />
                  </label>
                </div>
              </div>
              <div>
                <Label>צד אחורי</Label>
                <div className="mt-2">
                  <label className="flex items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-gray-400">
                    <div className="text-center">
                      {licenseBack ? (
                        <div className="text-sm text-green-600">✓ קובץ נבחר</div>
                      ) : (
                        <>
                          <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                          <div className="text-sm text-gray-500">העלה תמונה</div>
                        </>
                      )}
                    </div>
                    <input
                      type="file"
                      className="hidden"
                      accept="image/*"
                      onChange={(e) => setLicenseBack(e.target.files[0])}
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button variant="outline" onClick={onClose} disabled={loading}>
              ביטול
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={loading || !formData.first_name || !formData.last_name || !formData.phone || !formData.id_number}
              className="flex-1 bg-cyan-600 hover:bg-cyan-700"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                  שומר...
                </>
              ) : (
                'שמור לקוח'
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}