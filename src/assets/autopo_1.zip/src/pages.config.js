import Accidents from './pages/Accidents';
import Bookings from './pages/Bookings';
import CalendarView from './pages/CalendarView';
import CashFlow from './pages/CashFlow';
import CollectionTasks from './pages/CollectionTasks';
import Customers from './pages/Customers';
import DailySnapshot from './pages/DailySnapshot';
import Dashboard from './pages/Dashboard';
import Expenses from './pages/Expenses';
import GeneralTasks from './pages/GeneralTasks';
import HighwayBills from './pages/HighwayBills';
import Incomes from './pages/Incomes';
import MaintenanceTasks from './pages/MaintenanceTasks';
import RentalStation from './pages/RentalStation';
import Rentals from './pages/Rentals';
import Sign from './pages/Sign';
import TabletSignatures from './pages/TabletSignatures';
import TodayRentals from './pages/TodayRentals';
import TrafficTickets from './pages/TrafficTickets';
import VehicleFinancials from './pages/VehicleFinancials';
import VehiclePhotos from './pages/VehiclePhotos';
import Vehicles from './pages/Vehicles';
import TodayDepartures from './pages/TodayDepartures';
import TodayReturns from './pages/TodayReturns';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Accidents": Accidents,
    "Bookings": Bookings,
    "CalendarView": CalendarView,
    "CashFlow": CashFlow,
    "CollectionTasks": CollectionTasks,
    "Customers": Customers,
    "DailySnapshot": DailySnapshot,
    "Dashboard": Dashboard,
    "Expenses": Expenses,
    "GeneralTasks": GeneralTasks,
    "HighwayBills": HighwayBills,
    "Incomes": Incomes,
    "MaintenanceTasks": MaintenanceTasks,
    "RentalStation": RentalStation,
    "Rentals": Rentals,
    "Sign": Sign,
    "TabletSignatures": TabletSignatures,
    "TodayRentals": TodayRentals,
    "TrafficTickets": TrafficTickets,
    "VehicleFinancials": VehicleFinancials,
    "VehiclePhotos": VehiclePhotos,
    "Vehicles": Vehicles,
    "TodayDepartures": TodayDepartures,
    "TodayReturns": TodayReturns,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};