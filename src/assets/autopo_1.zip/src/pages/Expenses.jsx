import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import PageHeader from "@/components/shared/PageHeader";
import DataTable from "@/components/shared/DataTable";
import StatCard from "@/components/shared/StatCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Receipt, TrendingDown, Fuel, Wrench, Edit, Trash2 } from "lucide-react";

export default function Expenses() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedExpense, setSelectedExpense] = useState(null);
  const [filterType, setFilterType] = useState("all");
  const queryClient = useQueryClient();

  const { data: expenses = [], isLoading } = useQuery({
    queryKey: ["expenses"],
    queryFn: () => base44.entities.Expense.list("-date")
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["vehicles"],
    queryFn: () => base44.entities.Vehicle.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Expense.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["expenses"]);
      setIsOpen(false);
      setSelectedExpense(null);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Expense.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["expenses"]);
      setIsOpen(false);
      setSelectedExpense(null);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Expense.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["expenses"])
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    data.amount = parseFloat(data.amount);
    data.is_recurring = data.is_recurring === "on";

    const vehicle = vehicles.find(v => v.id === data.vehicle_id);
    if (vehicle) {
      data.vehicle_details = `${vehicle.manufacturer} ${vehicle.model} - ${vehicle.license_plate}`;
    }

    if (selectedExpense) {
      updateMutation.mutate({ id: selectedExpense.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const monthlyTotal = expenses
    .filter(e => {
      const d = new Date(e.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    })
    .reduce((sum, e) => sum + (e.amount || 0), 0);

  const yearlyTotal = expenses
    .filter(e => new Date(e.date).getFullYear() === currentYear)
    .reduce((sum, e) => sum + (e.amount || 0), 0);

  const recurringTotal = expenses
    .filter(e => e.is_recurring)
    .reduce((sum, e) => sum + (e.amount || 0), 0);

  const filteredExpenses = filterType === "all" 
    ? expenses 
    : expenses.filter(e => e.type === filterType);

  const typeIcons = {
    "דלק": Fuel,
    "טיפול": Wrench,
    "ביטוח": Receipt,
    "רישוי": Receipt,
    "תיקון": Wrench
  };

  const columns = [
    {
      header: "תאריך",
      cell: (row) => row.date ? format(new Date(row.date), "dd/MM/yyyy") : "-"
    },
    {
      header: "סוג",
      cell: (row) => (
        <span className="px-2 py-1 bg-orange-100 text-orange-800 rounded-full text-sm">
          {row.type}
        </span>
      )
    },
    { header: "רכב", accessor: "vehicle_details" },
    { header: "תיאור", accessor: "description" },
    {
      header: "סכום",
      cell: (row) => (
        <span className="font-bold text-red-600">₪{row.amount?.toLocaleString() || 0}</span>
      )
    },
    {
      header: "קבועה",
      cell: (row) => row.is_recurring ? (
        <span className="text-green-600">✓</span>
      ) : null
    },
    {
      header: "פעולות",
      cell: (row) => (
        <div className="flex gap-2">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => { setSelectedExpense(row); setIsOpen(true); }}
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            className="text-red-500"
            onClick={() => deleteMutation.mutate(row.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div>
      <PageHeader
        title="הוצאות"
        subtitle={`הוצאות החודש: ₪${monthlyTotal.toLocaleString()}`}
        action={() => { setSelectedExpense(null); setIsOpen(true); }}
        actionLabel="הוצאה חדשה"
      />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard
          title="הוצאות החודש"
          value={`₪${monthlyTotal.toLocaleString()}`}
          icon={TrendingDown}
          color="red"
        />
        <StatCard
          title="סה״כ שנתי"
          value={`₪${yearlyTotal.toLocaleString()}`}
          icon={Receipt}
          color="orange"
        />
        <StatCard
          title="הוצאות קבועות"
          value={`₪${recurringTotal.toLocaleString()}`}
          icon={Receipt}
          color="purple"
        />
      </div>

      {/* Filters */}
      <div className="mb-6">
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="סינון לפי סוג" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הסוגים</SelectItem>
            <SelectItem value="דלק">דלק</SelectItem>
            <SelectItem value="טיפול">טיפול</SelectItem>
            <SelectItem value="ביטוח">ביטוח</SelectItem>
            <SelectItem value="רישוי">רישוי</SelectItem>
            <SelectItem value="תיקון">תיקון</SelectItem>
            <SelectItem value="שטיפה">שטיפה</SelectItem>
            <SelectItem value="חניה">חניה</SelectItem>
            <SelectItem value="כביש 6">כביש 6</SelectItem>
            <SelectItem value="הוצאה קבועה">הוצאה קבועה</SelectItem>
            <SelectItem value="אחר">אחר</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <DataTable
        columns={columns}
        data={filteredExpenses}
        isLoading={isLoading}
        emptyMessage="לא נמצאו הוצאות"
      />

      {/* Add/Edit Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedExpense ? "עריכת הוצאה" : "הוצאה חדשה"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>רכב</Label>
              <Select name="vehicle_id" defaultValue={selectedExpense?.vehicle_id}>
                <SelectTrigger>
                  <SelectValue placeholder="בחר רכב (אופציונלי)" />
                </SelectTrigger>
                <SelectContent>
                  {vehicles.map(v => (
                    <SelectItem key={v.id} value={v.id}>
                      {v.manufacturer} {v.model} - {v.license_plate}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>סוג *</Label>
                <Select name="type" defaultValue={selectedExpense?.type || "אחר"}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="דלק">דלק</SelectItem>
                    <SelectItem value="טיפול">טיפול</SelectItem>
                    <SelectItem value="ביטוח">ביטוח</SelectItem>
                    <SelectItem value="רישוי">רישוי</SelectItem>
                    <SelectItem value="תיקון">תיקון</SelectItem>
                    <SelectItem value="שטיפה">שטיפה</SelectItem>
                    <SelectItem value="חניה">חניה</SelectItem>
                    <SelectItem value="כביש 6">כביש 6</SelectItem>
                    <SelectItem value="הוצאה קבועה">הוצאה קבועה</SelectItem>
                    <SelectItem value="אחר">אחר</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>סכום *</Label>
                <Input 
                  name="amount" 
                  type="number" 
                  defaultValue={selectedExpense?.amount}
                  required 
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>תאריך *</Label>
                <Input 
                  name="date" 
                  type="date" 
                  defaultValue={selectedExpense?.date || format(new Date(), "yyyy-MM-dd")}
                  required 
                />
              </div>
              <div>
                <Label>אמצעי תשלום</Label>
                <Select name="payment_method" defaultValue={selectedExpense?.payment_method}>
                  <SelectTrigger><SelectValue placeholder="בחר" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="מזומן">מזומן</SelectItem>
                    <SelectItem value="אשראי">אשראי</SelectItem>
                    <SelectItem value="צ'ק">צ'ק</SelectItem>
                    <SelectItem value="העברה בנקאית">העברה בנקאית</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>תיאור</Label>
              <Textarea 
                name="description" 
                defaultValue={selectedExpense?.description}
              />
            </div>
            <div className="flex items-center gap-2">
              <Checkbox 
                id="is_recurring" 
                name="is_recurring"
                defaultChecked={selectedExpense?.is_recurring}
              />
              <Label htmlFor="is_recurring">הוצאה קבועה/חוזרת</Label>
            </div>
            <div className="flex gap-3 pt-4">
              <Button type="submit" className="flex-1 bg-cyan-600 hover:bg-cyan-700">
                {selectedExpense ? "עדכון" : "שמירה"}
              </Button>
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                ביטול
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}