import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format, startOfYear, endOfYear, eachMonthOfInterval } from "date-fns";
import { he } from "date-fns/locale";
import PageHeader from "@/components/shared/PageHeader";
import DataTable from "@/components/shared/DataTable";
import StatCard from "@/components/shared/StatCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DollarSign, TrendingUp, Calendar, CreditCard } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";

export default function Incomes() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const queryClient = useQueryClient();

  const { data: incomes = [], isLoading } = useQuery({
    queryKey: ["incomes"],
    queryFn: () => base44.entities.Income.list("-date")
  });

  const { data: customers = [] } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Income.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["incomes"]);
      setIsOpen(false);
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    data.amount = parseFloat(data.amount);
    
    const customer = customers.find(c => c.id === data.customer_id);
    if (customer) {
      data.customer_name = `${customer.first_name} ${customer.last_name}`;
    }
    
    createMutation.mutate(data);
  };

  const currentYear = new Date().getFullYear();
  const months = eachMonthOfInterval({
    start: startOfYear(new Date()),
    end: endOfYear(new Date())
  });

  // Filter incomes
  const filteredIncomes = incomes.filter(income => {
    const incomeDate = new Date(income.date);
    const matchesMonth = selectedMonth === "all" || incomeDate.getMonth() === parseInt(selectedMonth);
    const matchesType = selectedType === "all" || income.type === selectedType;
    return matchesMonth && matchesType;
  });

  // Calculate stats
  const totalYearly = incomes
    .filter(i => new Date(i.date).getFullYear() === currentYear)
    .reduce((sum, i) => sum + (i.amount || 0), 0);

  const currentMonth = new Date().getMonth();
  const monthlyTotal = incomes
    .filter(i => {
      const d = new Date(i.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    })
    .reduce((sum, i) => sum + (i.amount || 0), 0);

  // Monthly chart data
  const monthlyData = months.map(month => {
    const monthIncomes = incomes.filter(i => {
      const d = new Date(i.date);
      return d.getMonth() === month.getMonth() && d.getFullYear() === currentYear;
    });
    return {
      name: format(month, "MMM", { locale: he }),
      amount: monthIncomes.reduce((sum, i) => sum + (i.amount || 0), 0)
    };
  });

  // Type breakdown
  const typeBreakdown = {};
  filteredIncomes.forEach(income => {
    const type = income.type || "אחר";
    typeBreakdown[type] = (typeBreakdown[type] || 0) + (income.amount || 0);
  });
  const pieData = Object.entries(typeBreakdown).map(([name, value]) => ({ name, value }));
  const COLORS = ['#0891b2', '#06b6d4', '#22d3ee', '#67e8f9', '#a5f3fc', '#cffafe'];

  const columns = [
    {
      header: "תאריך",
      cell: (row) => row.date ? format(new Date(row.date), "dd/MM/yyyy") : "-"
    },
    { header: "לקוח", accessor: "customer_name" },
    {
      header: "סוג",
      cell: (row) => (
        <span className="px-2 py-1 bg-cyan-100 text-cyan-800 rounded-full text-sm">
          {row.type}
        </span>
      )
    },
    { header: "אמצעי תשלום", accessor: "payment_method" },
    {
      header: "סכום",
      cell: (row) => (
        <span className="font-bold text-green-600">₪{row.amount?.toLocaleString() || 0}</span>
      )
    }
  ];

  return (
    <div>
      <PageHeader
        title="הכנסות"
        subtitle={`סה"כ השנה: ₪${totalYearly.toLocaleString()}`}
        action={() => setIsOpen(true)}
        actionLabel="הכנסה חדשה"
      />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard
          title="הכנסות החודש"
          value={`₪${monthlyTotal.toLocaleString()}`}
          icon={DollarSign}
          color="green"
        />
        <StatCard
          title="סה״כ שנתי"
          value={`₪${totalYearly.toLocaleString()}`}
          icon={TrendingUp}
          color="cyan"
        />
        <StatCard
          title="ממוצע חודשי"
          value={`₪${Math.round(totalYearly / (currentMonth + 1)).toLocaleString()}`}
          icon={Calendar}
          color="blue"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border p-6">
          <h3 className="font-semibold mb-4">הכנסות לפי חודש</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip
                  formatter={(value) => [`₪${value.toLocaleString()}`, "הכנסה"]}
                  contentStyle={{ borderRadius: 12 }}
                />
                <Bar dataKey="amount" fill="#0891b2" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-2xl border p-6">
          <h3 className="font-semibold mb-4">התפלגות לפי סוג</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {pieData.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `₪${value.toLocaleString()}`} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4 mb-6">
        <Select value={selectedMonth} onValueChange={setSelectedMonth}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="חודש" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל החודשים</SelectItem>
            {months.map((month, i) => (
              <SelectItem key={i} value={i.toString()}>
                {format(month, "MMMM", { locale: he })}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="סוג" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הסוגים</SelectItem>
            <SelectItem value="השכרה">השכרה</SelectItem>
            <SelectItem value="קילומטרז' נוסף">קילומטרז' נוסף</SelectItem>
            <SelectItem value="דוח תנועה">דוח תנועה</SelectItem>
            <SelectItem value="כביש 6">כביש 6</SelectItem>
            <SelectItem value="נזק">נזק</SelectItem>
            <SelectItem value="אחר">אחר</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <DataTable
        columns={columns}
        data={filteredIncomes}
        isLoading={isLoading}
        emptyMessage="לא נמצאו הכנסות"
      />

      {/* Add Income Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>הכנסה חדשה</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>לקוח (אופציונלי)</Label>
              <Select name="customer_id">
                <SelectTrigger>
                  <SelectValue placeholder="בחר לקוח או השאר ריק" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map(c => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.first_name} {c.last_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>סכום *</Label>
                <Input name="amount" type="number" required />
              </div>
              <div>
                <Label>תאריך *</Label>
                <Input name="date" type="date" defaultValue={format(new Date(), "yyyy-MM-dd")} required />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>סוג *</Label>
                <Select name="type" defaultValue="השכרה">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="השכרה">השכרה</SelectItem>
                    <SelectItem value="קילומטרז' נוסף">קילומטרז' נוסף</SelectItem>
                    <SelectItem value="דוח תנועה">דוח תנועה</SelectItem>
                    <SelectItem value="כביש 6">כביש 6</SelectItem>
                    <SelectItem value="נזק">נזק</SelectItem>
                    <SelectItem value="אחר">אחר</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>אמצעי תשלום</Label>
                <Select name="payment_method">
                  <SelectTrigger><SelectValue placeholder="בחר" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="מזומן">מזומן</SelectItem>
                    <SelectItem value="אשראי">אשראי</SelectItem>
                    <SelectItem value="צ'ק">צ'ק</SelectItem>
                    <SelectItem value="העברה בנקאית">העברה בנקאית</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-3 pt-4">
              <Button type="submit" className="flex-1 bg-cyan-600 hover:bg-cyan-700">
                שמירה
              </Button>
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                ביטול
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}