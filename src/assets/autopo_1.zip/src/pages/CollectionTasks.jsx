import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import PageHeader from "@/components/shared/PageHeader";
import DataTable from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DollarSign, Phone, MessageSquare, Edit, Check, User } from "lucide-react";

export default function CollectionTasks() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [callDialog, setCallDialog] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const queryClient = useQueryClient();

  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ["collectionTasks"],
    queryFn: () => base44.entities.CollectionTask.list("-created_date")
  });

  const { data: customers = [] } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.CollectionTask.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["collectionTasks"]);
      setIsOpen(false);
      setSelectedTask(null);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CollectionTask.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["collectionTasks"]);
      setIsOpen(false);
      setCallDialog(false);
      setSelectedTask(null);
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    
    data.amount = parseFloat(data.amount);
    if (data.paid_amount) data.paid_amount = parseFloat(data.paid_amount);

    const customer = customers.find(c => c.id === data.customer_id);
    if (customer) {
      data.customer_name = `${customer.first_name} ${customer.last_name}`;
    }

    if (selectedTask) {
      updateMutation.mutate({ id: selectedTask.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const addCallNote = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const notes = formData.get("notes");
    
    const callHistory = selectedTask.call_history || [];
    callHistory.push({
      date: format(new Date(), "yyyy-MM-dd HH:mm"),
      notes
    });

    updateMutation.mutate({
      id: selectedTask.id,
      data: { ...selectedTask, call_history: callHistory }
    });
  };

  const markPaid = (task) => {
    updateMutation.mutate({
      id: task.id,
      data: {
        ...task,
        status: "נסגר",
        paid_amount: task.amount
      }
    });
  };

  // Separate tasks by payment due date
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const urgentTasks = tasks.filter(t => {
    if (t.status === "נסגר") return false;
    if (!t.payment_due_date) return true; // No due date = show as urgent
    const dueDate = new Date(t.payment_due_date);
    return dueDate <= today;
  });

  const futureTasks = tasks.filter(t => {
    if (t.status === "נסגר") return false;
    if (!t.payment_due_date) return false;
    const dueDate = new Date(t.payment_due_date);
    return dueDate > today;
  });

  const filteredTasks = statusFilter === "all" 
    ? urgentTasks
    : urgentTasks.filter(t => t.status === statusFilter);

  const totalDebt = urgentTasks
    .reduce((sum, t) => sum + ((t.amount || 0) - (t.paid_amount || 0)), 0);

  const totalFutureIncome = futureTasks
    .reduce((sum, t) => sum + ((t.amount || 0) - (t.paid_amount || 0)), 0);

  const openCount = urgentTasks.filter(t => t.status === "פתוח").length;

  const columns = [
    {
      header: "לקוח",
      cell: (row) => (
        <div className="flex items-center gap-2">
          <User className="w-4 h-4 text-gray-400" />
          <div>
            <p className="font-medium">{row.customer_name}</p>
            <p className="text-sm text-gray-500">{row.vehicle_details}</p>
          </div>
        </div>
      )
    },
    {
      header: "תאריך חוב",
      cell: (row) => row.debt_date ? format(new Date(row.debt_date), "dd/MM/yyyy") : "-"
    },
    {
      header: "יעד תשלום",
      cell: (row) => {
        if (!row.payment_due_date) return "-";
        const dueDate = new Date(row.payment_due_date);
        const isOverdue = dueDate < today;
        return (
          <span className={isOverdue ? "text-red-600 font-semibold" : "text-gray-700"}>
            {format(dueDate, "dd/MM/yyyy")}
          </span>
        );
      }
    },
    {
      header: "סכום",
      cell: (row) => (
        <span className="font-bold text-red-600">₪{row.amount?.toLocaleString() || 0}</span>
      )
    },
    {
      header: "שולם",
      cell: (row) => (
        <span className="text-green-600">₪{row.paid_amount?.toLocaleString() || 0}</span>
      )
    },
    {
      header: "יתרה",
      cell: (row) => (
        <span className="font-bold text-orange-600">
          ₪{((row.amount || 0) - (row.paid_amount || 0)).toLocaleString()}
        </span>
      )
    },
    {
      header: "סטטוס",
      cell: (row) => <StatusBadge status={row.status || "פתוח"} />
    },
    {
      header: "פעולות",
      cell: (row) => (
        <div className="flex gap-2">
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => { setSelectedTask(row); setCallDialog(true); }}
          >
            <Phone className="w-4 h-4" />
          </Button>
          {row.status !== "נסגר" && (
            <Button 
              size="sm" 
              className="bg-green-600 hover:bg-green-700"
              onClick={() => markPaid(row)}
            >
              <Check className="w-4 h-4" />
            </Button>
          )}
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => { setSelectedTask(row); setIsOpen(true); }}
          >
            <Edit className="w-4 h-4" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div>
      <PageHeader
        title="משימות גבייה"
        subtitle={`${openCount} פריטים פתוחים`}
        action={() => { setSelectedTask(null); setIsOpen(true); }}
        actionLabel="משימה חדשה"
        actionIcon={DollarSign}
      />

      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <Card className="p-6 bg-red-50 border-red-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">גבייה דחופה</p>
              <p className="text-3xl font-bold text-red-600">₪{totalDebt.toLocaleString()}</p>
              <p className="text-xs text-gray-500 mt-1">תאריך תשלום עבר או לא הוגדר</p>
            </div>
            <DollarSign className="w-12 h-12 text-red-300" />
          </div>
        </Card>
        <Card className="p-6 bg-blue-50 border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">הכנסות עתידיות</p>
              <p className="text-3xl font-bold text-blue-600">₪{totalFutureIncome.toLocaleString()}</p>
              <p className="text-xs text-gray-500 mt-1">תשלומים שטרם הגיע מועדם</p>
            </div>
            <DollarSign className="w-12 h-12 text-blue-300" />
          </div>
        </Card>
      </div>

      <div className="mb-6">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">הכל</SelectItem>
            <SelectItem value="פתוח">פתוח</SelectItem>
            <SelectItem value="בטיפול">בטיפול</SelectItem>
            <SelectItem value="חלקי">חלקי</SelectItem>
            <SelectItem value="נסגר">נסגר</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="mb-6">
        <h3 className="font-semibold text-lg mb-3 text-red-600">התרעות גבייה - דורש טיפול מיידי</h3>
        <DataTable
          columns={columns}
          data={filteredTasks}
          isLoading={isLoading}
          emptyMessage="אין משימות גבייה דחופות"
        />
      </div>

      {futureTasks.length > 0 && (
        <div>
          <h3 className="font-semibold text-lg mb-3 text-blue-600">הכנסות עתידיות</h3>
          <DataTable
            columns={columns}
            data={futureTasks}
            isLoading={isLoading}
            emptyMessage="אין הכנסות עתידיות"
          />
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedTask ? "עריכת משימה" : "משימה חדשה"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>לקוח *</Label>
              <Select name="customer_id" defaultValue={selectedTask?.customer_id}>
                <SelectTrigger>
                  <SelectValue placeholder="בחר לקוח" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map(c => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.first_name} {c.last_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>סכום חוב *</Label>
                <Input name="amount" type="number" defaultValue={selectedTask?.amount} required />
              </div>
              <div>
                <Label>סכום ששולם</Label>
                <Input name="paid_amount" type="number" defaultValue={selectedTask?.paid_amount || 0} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>תאריך חוב</Label>
                <Input name="debt_date" type="date" defaultValue={selectedTask?.debt_date} />
              </div>
              <div>
                <Label>תאריך יעד לתשלום</Label>
                <Input name="payment_due_date" type="date" defaultValue={selectedTask?.payment_due_date} />
                <p className="text-xs text-gray-500 mt-1">אם לא מוגדר - יופיע כגבייה דחופה</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>סטטוס</Label>
                <Select name="status" defaultValue={selectedTask?.status || "פתוח"}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="פתוח">פתוח</SelectItem>
                    <SelectItem value="בטיפול">בטיפול</SelectItem>
                    <SelectItem value="חלקי">חלקי</SelectItem>
                    <SelectItem value="נסגר">נסגר</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>תזכורת</Label>
                <Input name="reminder_date" type="date" defaultValue={selectedTask?.reminder_date} />
              </div>
            </div>
            <div>
              <Label>סיבת החוב</Label>
              <Textarea name="reason" defaultValue={selectedTask?.reason} />
            </div>
            <div className="flex gap-3 pt-4">
              <Button type="submit" className="flex-1 bg-cyan-600 hover:bg-cyan-700">
                {selectedTask ? "עדכון" : "יצירה"}
              </Button>
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                ביטול
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Call History Dialog */}
      <Dialog open={callDialog} onOpenChange={setCallDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>היסטוריית שיחות - {selectedTask?.customer_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Existing calls */}
            <div className="max-h-60 overflow-y-auto space-y-2">
              {selectedTask?.call_history?.length > 0 ? (
                selectedTask.call_history.map((call, i) => (
                  <div key={i} className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-500">{call.date}</p>
                    <p>{call.notes}</p>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">אין שיחות קודמות</p>
              )}
            </div>

            {/* Add new call */}
            <form onSubmit={addCallNote} className="border-t pt-4">
              <Label>הוסף הערה לשיחה</Label>
              <Textarea name="notes" className="mt-2" placeholder="פרטי השיחה..." />
              <div className="flex gap-3 mt-4">
                <Button type="submit" className="flex-1 bg-cyan-600 hover:bg-cyan-700">
                  <MessageSquare className="w-4 h-4 ml-2" />
                  הוסף
                </Button>
                <Button type="button" variant="outline" onClick={() => setCallDialog(false)}>
                  סגור
                </Button>
              </div>
            </form>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}