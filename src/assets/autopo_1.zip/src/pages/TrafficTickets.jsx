import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import PageHeader from "@/components/shared/PageHeader";
import DataTable from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import StatCard from "@/components/shared/StatCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FileWarning, Car, Edit, Check, Trash2, Send, FileText, Download, Mail, Loader2 } from "lucide-react";
import { toast } from "react-hot-toast";

export default function TrafficTickets() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [formData, setFormData] = useState({ ticket_number: "", date: "", location: "" });
  const [isProcessing, setIsProcessing] = useState(false);
  const [emailDialogOpen, setEmailDialogOpen] = useState(false);
  const [currentTicket, setCurrentTicket] = useState(null);
  const [emailData, setEmailData] = useState({
    subject: "",
    body: "",
    to: "",
    includeContract: false,
    includeLicense: false,
    includeDeclaration: false,
    lawyerAppearanceDate: format(new Date(), "yyyy-MM-dd"),
    signatureDate: format(new Date(), "yyyy-MM-dd")
  });
  const queryClient = useQueryClient();

  const { data: tickets = [], isLoading } = useQuery({
    queryKey: ["trafficTickets"],
    queryFn: () => base44.entities.TrafficTicket.list("-date")
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["vehicles"],
    queryFn: () => base44.entities.Vehicle.list()
  });

  const { data: customers = [] } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list()
  });

  const { data: rentals = [] } = useQuery({
    queryKey: ["rentals"],
    queryFn: () => base44.entities.Rental.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.TrafficTicket.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["trafficTickets"]);
      setIsOpen(false);
      setSelectedTicket(null);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TrafficTicket.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["trafficTickets"]);
      setIsOpen(false);
      setSelectedTicket(null);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.TrafficTicket.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["trafficTickets"])
  });

  const autoAssignCustomer = (date, vehicleId) => {
    if (!date || !vehicleId) return null;
    
    const rental = rentals.find(r => 
      r.vehicle_id === vehicleId && 
      r.status === "פעיל" &&
      r.start_date <= date &&
      r.planned_end_date >= date
    );
    
    return rental ? { id: rental.customer_id, name: rental.customer_name } : null;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const formDataObj = new FormData(e.target);
    const data = Object.fromEntries(formDataObj.entries());
    
    data.amount = parseFloat(data.amount);
    data.driver_declaration = data.driver_declaration === "on";
    data.company_declaration = data.company_declaration === "on";

    const vehicle = vehicles.find(v => v.id === data.vehicle_id);
    
    // Auto-assign customer if not selected
    if (!data.customer_id && data.date && data.vehicle_id) {
      const assignedCustomer = autoAssignCustomer(data.date, data.vehicle_id);
      if (assignedCustomer) {
        data.customer_id = assignedCustomer.id;
        data.customer_name = assignedCustomer.name;
      }
    } else {
      const customer = customers.find(c => c.id === data.customer_id);
      if (customer) data.customer_name = `${customer.first_name} ${customer.last_name}`;
    }
    
    if (vehicle) data.vehicle_details = `${vehicle.manufacturer} ${vehicle.model} - ${vehicle.license_plate}`;

    if (selectedTicket) {
      updateMutation.mutate({ id: selectedTicket.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleDateVehicleChange = () => {
    if (formData.date && formData.vehicle_id) {
      const assignedCustomer = autoAssignCustomer(formData.date, formData.vehicle_id);
      if (assignedCustomer) {
        setFormData({ ...formData, auto_customer: assignedCustomer.name });
      }
    }
  };

  const transferToCustomer = async (ticket) => {
    // Update ticket status
    await base44.entities.TrafficTicket.update(ticket.id, { 
      ...ticket, 
      status: "הועבר ללקוח" 
    });
    
    // Create collection task
    await base44.entities.CollectionTask.create({
      customer_id: ticket.customer_id,
      customer_name: ticket.customer_name,
      vehicle_id: ticket.vehicle_id,
      vehicle_details: ticket.vehicle_details,
      debt_date: ticket.date,
      amount: ticket.amount,
      reason: `דוח תנועה מספר ${ticket.ticket_number}`,
      status: "פתוח"
    });
    
    queryClient.invalidateQueries(["trafficTickets"]);
    queryClient.invalidateQueries(["collectionTasks"]);
  };

  const markPaid = (ticket) => {
    updateMutation.mutate({
      id: ticket.id,
      data: { ...ticket, status: "שולם", paid_date: format(new Date(), "yyyy-MM-dd") }
    });
  };

  const generateCompanyDeclaration = async (ticket, customer, rental) => {
    const jsPDF = (await import('jspdf')).default;
    const doc = new jsPDF();
    doc.setR2L(true);

    let y = 20;
    doc.setFontSize(18);
    doc.text("הצהרת חברה - הסבת דוח תנועה", 105, y, { align: "center" });
    y += 15;

    doc.setFontSize(12);
    doc.text("אנו החתומים מטה, חברת ע.מ. אוטופה השכרת רכב", 190, y, { align: "right" });
    y += 8;
    doc.text("ח.פ 515856920", 190, y, { align: "right" });
    y += 12;

    doc.text(`מצהירים כי ביום ${format(new Date(ticket.date), "dd/MM/yyyy")}`, 190, y, { align: "right" });
    y += 8;
    doc.text(`הרכב ${ticket.vehicle_details}`, 190, y, { align: "right" });
    y += 8;
    doc.text(`היה מושכר ללקוח הבא:`, 190, y, { align: "right" });
    y += 12;

    doc.setFontSize(11);
    doc.text(`שם הנהג: ${customer.first_name} ${customer.last_name}`, 190, y, { align: "right" });
    y += 7;
    doc.text(`מספר ת.ז: ${customer.id_number}`, 190, y, { align: "right" });
    y += 7;
    doc.text(`טלפון: ${customer.phone}`, 190, y, { align: "right" });
    y += 7;
    doc.text(`כתובת: ${customer.address || ""} ${customer.city || ""}`, 190, y, { align: "right" });
    y += 10;

    if (rental) {
      doc.text(`תאריך התחלת השכרה: ${format(new Date(rental.start_date), "dd/MM/yyyy")}`, 190, y, { align: "right" });
      y += 7;
      doc.text(`תאריך סיום השכרה: ${format(new Date(rental.planned_end_date), "dd/MM/yyyy")}`, 190, y, { align: "right" });
      y += 10;
    }

    doc.setFontSize(12);
    doc.text(`דוח תנועה מספר: ${ticket.ticket_number}`, 190, y, { align: "right" });
    y += 7;
    doc.text(`מיקום: ${ticket.location}`, 190, y, { align: "right" });
    y += 7;
    doc.text(`סכום: ₪${ticket.amount?.toLocaleString()}`, 190, y, { align: "right" });
    y += 15;

    doc.text("בכבוד רב,", 190, y, { align: "right" });
    y += 7;
    doc.text("ע.מ. אוטופה השכרת רכב", 190, y, { align: "right" });
    y += 7;
    doc.text(new Date().toLocaleDateString('he-IL'), 190, y, { align: "right" });

    const pdfBlob = doc.output("blob");
    const pdfFile = new File([pdfBlob], "company_declaration.pdf", { type: "application/pdf" });
    const uploadResult = await base44.integrations.Core.UploadFile({ file: pdfFile });
    return uploadResult.file_url;
  };

  const downloadDocuments = async (ticket) => {
    if (!ticket.customer_id) {
      alert("לא נמצא לקוח משויך לדוח");
      return;
    }

    const customer = customers.find(c => c.id === ticket.customer_id);
    const rental = rentals.find(r => 
      r.customer_id === ticket.customer_id &&
      r.vehicle_id === ticket.vehicle_id &&
      r.start_date <= ticket.date &&
      (r.actual_end_date || r.planned_end_date) >= ticket.date
    );

    if (!customer) {
      alert("לא נמצא לקוח");
      return;
    }

    // Generate company declaration if not exists
    let companyDecUrl = ticket.declaration_url;
    if (!companyDecUrl) {
      companyDecUrl = await generateCompanyDeclaration(ticket, customer, rental);
      await base44.entities.TrafficTicket.update(ticket.id, {
        ...ticket,
        declaration_url: companyDecUrl,
        company_declaration: true
      });
    }

    // Open all documents in new tabs
    const documents = [];
    
    // Contract
    if (rental?.contract_url) {
      documents.push({ url: rental.contract_url, name: "חוזה" });
    }
    
    // Driver declaration
    if (rental?.waiver_url) {
      documents.push({ url: rental.waiver_url, name: "הצהרת נהג" });
    }
    
    // Company declaration
    if (companyDecUrl) {
      documents.push({ url: companyDecUrl, name: "הצהרת חברה" });
    }
    
    // Driver's license
    if (customer.license_front_image) {
      documents.push({ url: customer.license_front_image, name: "רישיון קדמי" });
    }
    if (customer.license_back_image) {
      documents.push({ url: customer.license_back_image, name: "רישיון אחורי" });
    }

    // Open all documents
    documents.forEach(doc => {
      window.open(doc.url, '_blank');
    });

    if (documents.length === 0) {
      alert("לא נמצאו מסמכים להורדה");
    }
  };

  const openEmailDialog = async (ticket) => {
    if (!ticket.customer_id) {
      alert("לא נמצא לקוח משויך לדוח");
      return;
    }

    const customer = customers.find(c => c.id === ticket.customer_id);
    const rental = rentals.find(r => 
      r.customer_id === ticket.customer_id &&
      r.vehicle_id === ticket.vehicle_id &&
      r.start_date <= ticket.date &&
      (r.actual_end_date || r.planned_end_date) >= ticket.date
    );

    if (!customer) {
      alert("לא נמצא לקוח");
      return;
    }

    // Generate company declaration if needed
    let companyDecUrl = ticket.declaration_url;
    if (!companyDecUrl) {
      companyDecUrl = await generateCompanyDeclaration(ticket, customer, rental);
      await base44.entities.TrafficTicket.update(ticket.id, {
        ...ticket,
        declaration_url: companyDecUrl,
        company_declaration: true
      });
    }

    // Prepare default email
    const subject = `הסבת דוח תנועה לנהג - מספר ${ticket.ticket_number} - ${customer.first_name} ${customer.last_name}`;
    
    const vehicle = vehicles.find(v => v.id === ticket.vehicle_id);
    
    const lawyerSignature = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693ff630f364c7fbf1f677cd/30df56c13_image.png";
    
    const defaultBody = `שלום,\n\nבצירוף מסמכים לצורך הסבת דוח תנועה מספר ${ticket.ticket_number}.\n\nבברכה,\nע.מ. אוטופה השכרת רכב`;

    setEmailData({
      subject,
      body: defaultBody,
      includeContract: !!rental?.contract_url,
      includeLicense: !!(customer.license_front_image || customer.license_back_image),
      includeDeclaration: !!rental?.waiver_url,
      lawyerAppearanceDate: format(new Date(), "yyyy-MM-dd"),
      signatureDate: format(new Date(), "yyyy-MM-dd")
    });

    setCurrentTicket({ ...ticket, customer, rental, companyDecUrl, vehicle: vehicles.find(v => v.id === ticket.vehicle_id) });
    setEmailDialogOpen(true);
  };

  const generateDeclarationPDF = async () => {
    if (!currentTicket) return null;
    
    const { customer, rental, vehicle, ticket_number, date } = currentTicket;
    const lawyerDate = emailData.lawyerAppearanceDate ? format(new Date(emailData.lawyerAppearanceDate), "dd/MM/yyyy") : "__________";
    const signDate = emailData.signatureDate ? format(new Date(emailData.signatureDate), "dd/MM/yyyy") : "__________";

    const jsPDF = (await import('jspdf')).default;
    const html2canvas = (await import('html2canvas')).default;

    // Create HTML content for PDF
    const tempDiv = document.createElement('div');
    tempDiv.style.position = 'absolute';
    tempDiv.style.right = '-9999px';
    tempDiv.style.width = '210mm';
    tempDiv.style.padding = '20mm';
    tempDiv.style.fontFamily = 'Arial, sans-serif';
    tempDiv.style.direction = 'rtl';
    tempDiv.style.backgroundColor = 'white';
    tempDiv.style.fontSize = '11px';
    tempDiv.style.lineHeight = '1.6';

    tempDiv.innerHTML = `
      <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="font-size: 18px; margin: 0; font-weight: bold;">הצהרה</h1>
      </div>

      <p style="margin-bottom: 10px;">אני הח״מ משה אלימלך ת.ז. 305162141, בשם מ. אלימלך ישיר קאר בע״מ ח.פ. 515856920, מאשר בזאת שהנתונים הרשומים מטה לקוחים ממאגרי המידע של החברה, לאחר שהוזהרתי כי עליי לומר את האמת וכי אהיה צפוי לעונשים הקבועים בחוק אם לא אעשה כן, מצהיר בזה בכתב כדלקמן:</p>

      <p style="margin: 8px 0;"><strong>א.</strong> הנני להצהיר כי אני הבעלים והמנכ"ל של חברת מ. אלימלך ישיר קאר בע״מ ח.פ. 515856920 והוסמכתי ע"י החברה להצהיר כאמור בתצהיר זה.</p>

      <p style="margin: 8px 0;"><strong>ב.</strong> אני נותן הצהרה זו עבור: הסבת דו"ח</p>
      <p style="margin: 5px 0;">עבור רכב שמספרו <strong>${vehicle?.license_plate || "________"}</strong> דו"ח מספר <strong>${ticket_number}</strong></p>
      <p style="margin: 5px 0;">לאמור כי החברה עוסקת בהשכרת כלי רכב לציבור והינה הבעלים של הרכב</p>
      <p style="margin: 5px 0;">מספר רכב: <strong>${vehicle?.license_plate || "________"}</strong></p>
      <p style="margin: 5px 0;">בתאריך העבירה הרלוונטי, היינו: <strong>${format(new Date(date), "dd/MM/yyyy")}</strong> שעת העבירה __________</p>
      <p style="margin: 5px 0;">היה הרכב שכור בשליטתו וחזקתו של תושב מדינת: <strong>ישראל</strong></p>

      <div style="margin: 15px 0;">
        <p style="margin: 3px 0;">שם הנהג: <strong>${customer.first_name} ${customer.last_name}</strong></p>
        <p style="margin: 3px 0;">מס׳ ת.ז/דרכון: <strong>${customer.id_number}</strong></p>
        <p style="margin: 3px 0;">מס׳ רישוי הנהג: <strong>${customer.license_start_year || "__________"}</strong></p>
        <p style="margin: 3px 0;">כתובת הנהג: <strong>${customer.address || ""} ${customer.city || ""}</strong></p>
      </div>

      <div style="margin: 15px 0;">
        <p style="margin: 3px 0;">תאריך יציאת הרכב: <strong>${rental?.start_date ? format(new Date(rental.start_date), "dd/MM/yyyy") : "__________"}</strong></p>
        <p style="margin: 3px 0;">שעת יציאת הרכב: <strong>${rental?.start_time || "__________"}</strong></p>
        <p style="margin: 3px 0;">תאריך חזרת הרכב: <strong>${rental?.actual_end_date ? format(new Date(rental.actual_end_date), "dd/MM/yyyy") : rental?.planned_end_date ? format(new Date(rental.planned_end_date), "dd/MM/yyyy") : "__________"}</strong></p>
        <p style="margin: 3px 0;">שעת חזרת הרכב: <strong>${rental?.actual_end_time || rental?.planned_end_time || "__________"}</strong></p>
      </div>

      <p style="margin: 15px 0;">הריני להצהיר כי לא החברה ולא איש מעובדיה לא נהג ברכב ולא ביצע בו עבירת תנועה בתאריך הנ"ל</p>

      <p style="margin: 20px 0;">חתימה המצהיר: __________</p>

      <p style="margin: 15px 0;">הנני מאשר כי ביום <strong>${lawyerDate}</strong> הופיע בפני עו״ד אביאל שטרית, במשרדי בכתובת רח' שילה 3, באשקלון מר משה אלימלך, שזוהה על ידי תעודת זהות מספר 305162141, ולאחר שהוזהר כי עליו להצהיר את האמת וכי יהיה צפוי לעונשים הקבועים בחוק אם לא יעשה כן, אישר את נכונות הצהרתו וחתם עליה בפני.</p>

      <p style="margin: 15px 0;">תאריך: <strong>${signDate}</strong></p>

      <div style="margin-top: 20px;">
        <p style="margin-bottom: 5px;">חתימה וחותמת עו״ד:</p>
        <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693ff630f364c7fbf1f677cd/30df56c13_image.png" style="max-width: 150px; height: auto;" />
      </div>
    `;

    document.body.appendChild(tempDiv);

    const canvas = await html2canvas(tempDiv, {
      scale: 2,
      useCORS: true,
      logging: false
    });

    document.body.removeChild(tempDiv);

    const doc = new jsPDF('p', 'mm', 'a4');
    const imgData = canvas.toDataURL('image/png');
    const imgWidth = 210;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    doc.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);

    const pdfBlob = doc.output("blob");
    const pdfFile = new File([pdfBlob], "declaration.pdf", { type: "application/pdf" });
    const uploadResult = await base44.integrations.Core.UploadFile({ file: pdfFile });
    return uploadResult.file_url;
  };

  const sendEmail = async () => {
    if (!currentTicket || !emailData.subject || !emailData.to) {
      alert("נא למלא את כל השדות");
      return;
    }

    setIsProcessing(true);
    toast.loading("מכין מסמכים ושולח מייל...", { id: "send-email" });

    try {
      const { customer, rental, companyDecUrl } = currentTicket;
      
      // Generate declaration PDF
      const declarationUrl = await generateDeclarationPDF();
      
      // Build HTML email body
      let finalBody = `
<!DOCTYPE html>
<html dir="rtl">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: #3b50a0; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
    .content { background: #f9f9f9; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
    .document { background: white; padding: 15px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
    .document-title { font-weight: bold; color: #3b50a0; margin-bottom: 10px; }
    .download-btn { display: inline-block; background: #17a2b8; color: white; padding: 10px 20px; 
                    text-decoration: none; border-radius: 5px; margin-top: 10px; }
    .footer { text-align: center; color: #666; font-size: 14px; padding-top: 20px; border-top: 1px solid #ddd; }
    a { color: #17a2b8; word-break: break-all; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h2 style="margin: 0;">הסבת דוח תנועה מספר ${currentTicket.ticket_number}</h2>
    </div>
    
    <div class="content">
      <p>${emailData.body || `שלום,<br><br>בצירוף מסמכים לצורך הסבת דוח תנועה מספר ${currentTicket.ticket_number}.`}</p>
    </div>
    
    <h3>מסמכים מצורפים:</h3>
    
    <div class="document">
      <div class="document-title">📄 הצהרה (PDF)</div>
      <a href="${declarationUrl}" class="download-btn">להורדת ההצהרה לחץ כאן</a>
    </div>
    
    ${emailData.includeContract && rental?.contract_url ? `
    <div class="document">
      <div class="document-title">📄 חוזה השכרה</div>
      <a href="${rental.contract_url}" class="download-btn">להורדת החוזה לחץ כאן</a>
    </div>
    ` : ''}
    
    ${emailData.includeLicense && customer.license_front_image ? `
    <div class="document">
      <div class="document-title">📄 רישיון נהיגה (צד קדמי)</div>
      <a href="${customer.license_front_image}" class="download-btn">להורדת הרישיון לחץ כאן</a>
    </div>
    ` : ''}
    
    ${emailData.includeLicense && customer.license_back_image ? `
    <div class="document">
      <div class="document-title">📄 רישיון נהיגה (צד אחורי)</div>
      <a href="${customer.license_back_image}" class="download-btn">להורדת הרישיון לחץ כאן</a>
    </div>
    ` : ''}
    
    ${emailData.includeDeclaration && rental?.waiver_url ? `
    <div class="document">
      <div class="document-title">📄 הצהרת נהג</div>
      <a href="${rental.waiver_url}" class="download-btn">להורדת ההצהרה לחץ כאן</a>
    </div>
    ` : ''}
    
    ${emailData.includeDeclaration && companyDecUrl ? `
    <div class="document">
      <div class="document-title">📄 הצהרת חברה</div>
      <a href="${companyDecUrl}" class="download-btn">להורדת ההצהרה לחץ כאן</a>
    </div>
    ` : ''}
    
    <div class="footer">
      <p><strong>בברכה,</strong></p>
      <p><strong>ע.מ. אוטופה השכרת רכב</strong></p>
      <p>טלפון: 050-1234567</p>
    </div>
  </div>
</body>
</html>`;

      await base44.integrations.Core.SendEmail({
        to: emailData.to,
        subject: emailData.subject,
        body: finalBody
      });
      
      toast.success("המייל נשלח בהצלחה!", { id: "send-email" });
      
      await updateMutation.mutateAsync({
        id: currentTicket.id,
        data: { ...currentTicket, status: "הועבר ללקוח", driver_declaration: true, company_declaration: true }
      });
      
      setEmailDialogOpen(false);
    } catch (error) {
      console.error(error);
      toast.error("שגיאה בשליחת מייל", { id: "send-email" });
    } finally {
      setIsProcessing(false);
    }
  };

  const filteredTickets = statusFilter === "all" 
    ? tickets 
    : tickets.filter(t => t.status === statusFilter);

  const totalUnpaid = tickets
    .filter(t => t.status !== "שולם")
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const newCount = tickets.filter(t => t.status === "חדש").length;

  const columns = [
    {
      header: "מספר דוח",
      accessor: "ticket_number"
    },
    {
      header: "תאריך",
      cell: (row) => row.date ? format(new Date(row.date), "dd/MM/yyyy") : "-"
    },
    {
      header: "רכב",
      cell: (row) => row.vehicle_details || "-"
    },
    {
      header: "מיקום",
      accessor: "location"
    },
    {
      header: "סכום",
      cell: (row) => (
        <span className="font-bold text-red-600">₪{row.amount?.toLocaleString() || 0}</span>
      )
    },
    {
      header: "לקוח",
      cell: (row) => row.customer_name || "-"
    },
    {
      header: "סטטוס",
      cell: (row) => <StatusBadge status={row.status || "חדש"} />
    },
    {
      header: "פעולות",
      cell: (row) => (
        <div className="flex gap-1 flex-wrap">
          <Button 
            size="sm" 
            variant="outline"
            className="text-purple-600"
            onClick={async () => {
              setIsProcessing(true);
              toast.loading("מכין מסמכים...", { id: "download-docs" });
              try {
                await downloadDocuments(row);
                toast.success("המסמכים נפתחו!", { id: "download-docs" });
              } catch (error) {
                toast.error("שגיאה בהורדת מסמכים", { id: "download-docs" });
              } finally {
                setIsProcessing(false);
              }
            }}
            disabled={isProcessing}
            title="הורד מסמכים"
          >
            {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            className="text-orange-600"
            onClick={() => openEmailDialog(row)}
            title="שלח לעירייה"
          >
            <Mail className="w-4 h-4" />
          </Button>
          {row.status === "חדש" && (
            <Button 
              size="sm" 
              variant="outline"
              className="text-blue-600"
              onClick={async () => {
                await transferToCustomer(row);
                toast.success("הדוח הועבר ללקוח");
              }}
              title="העבר ללקוח"
            >
              <Send className="w-4 h-4" />
            </Button>
          )}
          {row.status !== "שולם" && (
            <Button 
              size="sm" 
              className="bg-green-600 hover:bg-green-700"
              onClick={() => {
                markPaid(row);
                toast.success("הדוח סומן כשולם");
              }}
              title="סמן כשולם"
            >
              <Check className="w-4 h-4" />
            </Button>
          )}
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => { setSelectedTicket(row); setIsOpen(true); }}
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            className="text-red-500"
            onClick={() => deleteMutation.mutate(row.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div>
      <PageHeader
        title="דוחות תנועה"
        subtitle={`${newCount} דוחות חדשים`}
        action={() => { setSelectedTicket(null); setIsOpen(true); }}
        actionLabel="דוח חדש"
        actionIcon={FileWarning}
      />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard
          title="דוחות חדשים"
          value={newCount}
          icon={FileWarning}
          color="red"
        />
        <StatCard
          title="סה״כ לא שולם"
          value={`₪${totalUnpaid.toLocaleString()}`}
          icon={FileText}
          color="orange"
        />
        <StatCard
          title="סה״כ דוחות"
          value={tickets.length}
          icon={Car}
          color="blue"
        />
      </div>

      <div className="mb-6">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הסטטוסים</SelectItem>
            <SelectItem value="חדש">חדש</SelectItem>
            <SelectItem value="הועבר ללקוח">הועבר ללקוח</SelectItem>
            <SelectItem value="שולם">שולם</SelectItem>
            <SelectItem value="בערעור">בערעור</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <DataTable
        columns={columns}
        data={filteredTickets}
        isLoading={isLoading}
        emptyMessage="לא נמצאו דוחות תנועה"
      />

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{selectedTicket ? "עריכת דוח" : "דוח תנועה חדש"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>מספר דוח *</Label>
                <Input name="ticket_number" defaultValue={selectedTicket?.ticket_number} required />
              </div>
              <div>
                <Label>תאריך *</Label>
                <Input 
                  name="date" 
                  type="date" 
                  defaultValue={selectedTicket?.date}
                  onChange={(e) => {
                    setFormData({ ...formData, date: e.target.value });
                    setTimeout(handleDateVehicleChange, 100);
                  }}
                  required 
                />
              </div>
            </div>
            <div>
              <Label>רכב *</Label>
              <Select 
                name="vehicle_id" 
                defaultValue={selectedTicket?.vehicle_id}
                onValueChange={(v) => {
                  setFormData({ ...formData, vehicle_id: v });
                  setTimeout(handleDateVehicleChange, 100);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="בחר רכב" />
                </SelectTrigger>
                <SelectContent>
                  {vehicles.map(v => (
                    <SelectItem key={v.id} value={v.id}>
                      {v.manufacturer} {v.model} - {v.license_plate}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {formData.auto_customer && (
              <div className="p-3 bg-blue-50 rounded text-sm text-blue-800">
                ✓ שוייך אוטומטית ללקוח: {formData.auto_customer}
              </div>
            )}
            <div>
              <Label>לקוח (נהג)</Label>
              <Select name="customer_id" defaultValue={selectedTicket?.customer_id}>
                <SelectTrigger>
                  <SelectValue placeholder="בחר לקוח" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map(c => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.first_name} {c.last_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>מיקום/עירייה</Label>
                <Input 
                  name="location" 
                  defaultValue={selectedTicket?.location}
                  placeholder="עירייה או משטרה"
                />
              </div>
              <div>
                <Label>סכום *</Label>
                <Input name="amount" type="number" defaultValue={selectedTicket?.amount} required />
              </div>
            </div>
            <div>
              <Label>סטטוס</Label>
              <Select name="status" defaultValue={selectedTicket?.status || "חדש"}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="חדש">חדש</SelectItem>
                  <SelectItem value="הועבר ללקוח">הועבר ללקוח</SelectItem>
                  <SelectItem value="שולם">שולם</SelectItem>
                  <SelectItem value="בערעור">בערעור</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="driver_declaration" 
                  name="driver_declaration"
                  defaultChecked={selectedTicket?.driver_declaration}
                />
                <Label htmlFor="driver_declaration">הצהרת נהג</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="company_declaration" 
                  name="company_declaration"
                  defaultChecked={selectedTicket?.company_declaration}
                />
                <Label htmlFor="company_declaration">הצהרת חברה</Label>
              </div>
            </div>
            <div>
              <Label>הערות</Label>
              <Textarea name="notes" defaultValue={selectedTicket?.notes} />
            </div>
            <div className="flex gap-3 pt-4">
              <Button type="submit" className="flex-1 bg-cyan-600 hover:bg-cyan-700">
                {selectedTicket ? "עדכון" : "יצירה"}
              </Button>
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                ביטול
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Email Dialog */}
      <Dialog open={emailDialogOpen} onOpenChange={setEmailDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>שליחת מייל לעירייה - דוח {currentTicket?.ticket_number}</DialogTitle>
          </DialogHeader>
          
          {currentTicket && (
            <div className="space-y-4">
              {/* Customer Details */}
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold mb-2">פרטי הלקוח:</h3>
                <div className="text-sm space-y-1">
                  <p><strong>שם:</strong> {currentTicket.customer?.first_name} {currentTicket.customer?.last_name}</p>
                  <p><strong>ת.ז:</strong> {currentTicket.customer?.id_number}</p>
                  <p><strong>טלפון:</strong> {currentTicket.customer?.phone}</p>
                  <p><strong>כתובת:</strong> {currentTicket.customer?.address || ""} {currentTicket.customer?.city || ""}</p>
                </div>
              </div>

              {/* Attachments Options */}
              <div className="space-y-3">
                <h3 className="font-semibold">מסמכים לצרף:</h3>
                
                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="includeContract"
                    checked={emailData.includeContract}
                    onCheckedChange={(checked) => setEmailData({ ...emailData, includeContract: checked })}
                    disabled={!currentTicket.rental?.contract_url}
                  />
                  <Label htmlFor="includeContract" className={!currentTicket.rental?.contract_url ? "text-gray-400" : ""}>
                    חוזה השכרה {!currentTicket.rental?.contract_url && "(לא קיים)"}
                  </Label>
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="includeLicense"
                    checked={emailData.includeLicense}
                    onCheckedChange={(checked) => setEmailData({ ...emailData, includeLicense: checked })}
                    disabled={!currentTicket.customer?.license_front_image && !currentTicket.customer?.license_back_image}
                  />
                  <Label htmlFor="includeLicense" className={!currentTicket.customer?.license_front_image && !currentTicket.customer?.license_back_image ? "text-gray-400" : ""}>
                    רישיון נהיגה {!currentTicket.customer?.license_front_image && !currentTicket.customer?.license_back_image && "(לא קיים)"}
                  </Label>
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="includeDeclaration"
                    checked={emailData.includeDeclaration}
                    onCheckedChange={(checked) => setEmailData({ ...emailData, includeDeclaration: checked })}
                    disabled={!currentTicket.rental?.waiver_url && !currentTicket.companyDecUrl}
                  />
                  <Label htmlFor="includeDeclaration" className={!currentTicket.rental?.waiver_url && !currentTicket.companyDecUrl ? "text-gray-400" : ""}>
                    תצהירים (נהג + חברה) {!currentTicket.rental?.waiver_url && !currentTicket.companyDecUrl && "(לא קיימים)"}
                  </Label>
                </div>
              </div>

              {/* Dates for Declaration */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>תאריך הופעה בפני עו"ד *</Label>
                  <Input 
                    type="date"
                    value={emailData.lawyerAppearanceDate}
                    onChange={(e) => setEmailData({ ...emailData, lawyerAppearanceDate: e.target.value })}
                  />
                </div>
                <div>
                  <Label>תאריך חתימה *</Label>
                  <Input 
                    type="date"
                    value={emailData.signatureDate}
                    onChange={(e) => setEmailData({ ...emailData, signatureDate: e.target.value })}
                  />
                </div>
              </div>

              {/* Email To */}
              <div>
                <Label>למייל *</Label>
                <Input 
                  type="email"
                  value={emailData.to}
                  onChange={(e) => setEmailData({ ...emailData, to: e.target.value })}
                  placeholder="municipality@example.com"
                />
              </div>

              {/* Email Subject */}
              <div>
                <Label>כותרת המייל *</Label>
                <Input 
                  value={emailData.subject}
                  onChange={(e) => setEmailData({ ...emailData, subject: e.target.value })}
                  placeholder="כותרת המייל"
                />
              </div>

              {/* Email Body */}
              <div>
                <Label>תוכן המייל</Label>
                <Textarea 
                  value={emailData.body}
                  onChange={(e) => setEmailData({ ...emailData, body: e.target.value })}
                  placeholder="תוכן המייל..."
                  rows={6}
                  className="font-mono text-sm"
                />
                <p className="text-xs text-gray-500 mt-1">ההצהרה תישלח כמסמך PDF מצורף בנפרד</p>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <Button 
                  onClick={sendEmail}
                  disabled={isProcessing || !emailData.subject || !emailData.to}
                  className="flex-1 bg-orange-600 hover:bg-orange-700"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      שולח...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 ml-2" />
                      שלח מייל
                    </>
                  )}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setEmailDialogOpen(false)}
                  disabled={isProcessing}
                >
                  ביטול
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}