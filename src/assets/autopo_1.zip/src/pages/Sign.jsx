import React, { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { CheckCircle, FileText, Loader2, Trash2 } from "lucide-react";
import { toast } from "react-hot-toast";
import { PDFDocument } from "pdf-lib";

export default function Sign() {
  const [isSigned, setIsSigned] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const canvasRef = useRef(null);
  const [signatureData, setSignatureData] = useState(null);

  // Parse URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const documentType = urlParams.get("type");
  const bookingId = urlParams.get("id");
  const docUrl = urlParams.get("doc");

  const { data: booking, isLoading } = useQuery({
    queryKey: ["booking", bookingId],
    queryFn: async () => {
      const bookings = await base44.entities.Booking.list();
      return bookings.find(b => b.id === bookingId);
    },
    enabled: !!bookingId
  });

  const { data: customer } = useQuery({
    queryKey: ["customer", booking?.customer_id],
    queryFn: async () => {
      const customers = await base44.entities.Customer.list();
      return customers.find(c => c.id === booking.customer_id);
    },
    enabled: !!booking?.customer_id
  });

  const { data: vehicle } = useQuery({
    queryKey: ["vehicle", booking?.vehicle_id],
    queryFn: async () => {
      const vehicles = await base44.entities.Vehicle.list();
      return vehicles.find(v => v.id === booking.vehicle_id);
    },
    enabled: !!booking?.vehicle_id
  });

  const updateBookingMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Booking.update(id, data)
  });

  useEffect(() => {
    if (booking) {
      if (documentType === "contract" && booking.contract_signed) {
        setIsSigned(true);
      } else if (documentType === "declaration" && booking.declaration_signed) {
        setIsSigned(true);
      } else if (documentType === "waiver" && booking.waiver_signed) {
        setIsSigned(true);
      }
    }
  }, [booking, documentType]);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext("2d");
    ctx.strokeStyle = "#000";
    ctx.lineWidth = 2;
    ctx.lineCap = "round";
  }, []);

  const startDrawing = (e) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX || e.touches?.[0]?.clientX;
    const y = e.clientY || e.touches?.[0]?.clientY;
    const ctx = canvas.getContext("2d");
    ctx.beginPath();
    ctx.moveTo(x - rect.left, y - rect.top);
  };

  const draw = (e) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX || e.touches?.[0]?.clientX;
    const y = e.clientY || e.touches?.[0]?.clientY;
    const ctx = canvas.getContext("2d");
    ctx.lineTo(x - rect.left, y - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    setSignatureData(canvas.toDataURL());
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureData(null);
  };

  const handleSign = async () => {
    if (!signatureData) {
      toast.error("נא לחתום על המסמך");
      return;
    }

    setIsSubmitting(true);
    try {
      // Download original PDF
      const pdfResponse = await fetch(docUrl);
      const pdfBytes = await pdfResponse.arrayBuffer();
      
      // Load PDF
      const pdfDoc = await PDFDocument.load(pdfBytes);
      
      // Embed signature image
      const signatureImageBytes = await fetch(signatureData).then(r => r.arrayBuffer());
      const signatureImage = await pdfDoc.embedPng(signatureImageBytes);
      
      // Get last page
      const pages = pdfDoc.getPages();
      const lastPage = pages[pages.length - 1];
      const { width, height } = lastPage.getSize();
      
      // Add signature to bottom of page
      const signatureWidth = 200;
      const signatureHeight = 100;
      lastPage.drawImage(signatureImage, {
        x: width / 2 - signatureWidth / 2,
        y: 80,
        width: signatureWidth,
        height: signatureHeight,
      });
      
      // Save signed PDF
      const signedPdfBytes = await pdfDoc.save();
      const signedPdfBlob = new Blob([signedPdfBytes], { type: "application/pdf" });
      const signedPdfFile = new File([signedPdfBlob], "signed.pdf", { type: "application/pdf" });
      
      // Upload signed PDF
      const uploadResult = await base44.integrations.Core.UploadFile({ file: signedPdfFile });
      const signedPdfUrl = uploadResult.file_url;
      
      // Update booking with signed PDF URL
      const updateData = {};
      if (documentType === "contract") {
        updateData.contract_signed = true;
        updateData.contract_url = signedPdfUrl;
      } else if (documentType === "declaration") {
        updateData.declaration_signed = true;
        updateData.declaration_url = signedPdfUrl;
      } else if (documentType === "waiver") {
        updateData.waiver_signed = true;
        updateData.waiver_url = signedPdfUrl;
      }

      await updateBookingMutation.mutateAsync({ id: bookingId, data: updateData });
      setIsSigned(true);
      toast.success("המסמך נחתם בהצלחה!");
    } catch (error) {
      console.error("Error signing document:", error);
      toast.error("שגיאה בחתימה על המסמך");
    } finally {
      setIsSubmitting(false);
    }
  };

  const getDocumentTitle = () => {
    if (documentType === "contract") return "חוזה השכרת רכב";
    if (documentType === "declaration") return "תצהיר קבלת רכב";
    if (documentType === "waiver") return "כתב ויתור";
    return "מסמך";
  };



  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-cyan-600" />
      </div>
    );
  }

  if (!booking || !customer || !vehicle) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">מסמך לא נמצא</h2>
          <p className="text-gray-500">לא הצלחנו למצוא את המסמך המבוקש</p>
        </div>
      </div>
    );
  }

  if (isSigned) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">המסמך נחתם בהצלחה!</h2>
          <p className="text-gray-500 mb-6">
            {getDocumentTitle()} נחתם ונשמר במערכת
          </p>
          <div className="bg-gray-50 rounded-lg p-4 text-right">
            <p className="text-sm text-gray-600">
              <span className="font-semibold">שוכר:</span> {customer.first_name} {customer.last_name}
            </p>
            <p className="text-sm text-gray-600">
              <span className="font-semibold">רכב:</span> {vehicle.manufacturer} {vehicle.model}
            </p>
            <p className="text-sm text-gray-600">
              <span className="font-semibold">תאריך חתימה:</span> {format(new Date(), "dd/MM/yyyy HH:mm")}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50 p-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-l from-cyan-600 to-blue-700 text-white p-6">
            <div className="flex items-center gap-3">
              <FileText className="w-8 h-8" />
              <div>
                <h1 className="text-2xl font-bold">{getDocumentTitle()}</h1>
                <p className="text-cyan-100">נא לקרוא ולחתום על המסמך</p>
              </div>
            </div>
          </div>

          {/* Document Content */}
          <div className="p-6 border-b">
            {docUrl ? (
              <iframe
                src={docUrl}
                className="w-full h-[500px] border rounded-lg"
                title="document"
              />
            ) : (
              <div className="text-center text-gray-500 py-20">
                אין מסמך להצגה
              </div>
            )}
          </div>

          {/* Signature Section */}
          <div className="p-6 bg-gray-50">
            <div className="max-w-2xl mx-auto space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-semibold">חתמו כאן:</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={clearSignature}
                    className="text-red-600"
                  >
                    <Trash2 className="w-4 h-4 ml-1" />
                    נקה חתימה
                  </Button>
                </div>
                <canvas
                  ref={canvasRef}
                  width={600}
                  height={200}
                  className="w-full border-2 border-gray-300 rounded-lg bg-white touch-none cursor-crosshair"
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  onTouchStart={startDrawing}
                  onTouchMove={draw}
                  onTouchEnd={stopDrawing}
                />
              </div>
              <div className="text-sm text-gray-500">
                תאריך: {format(new Date(), "dd/MM/yyyy HH:mm")}
              </div>
              <Button
                onClick={handleSign}
                disabled={!signatureData || isSubmitting}
                className="w-full bg-cyan-600 hover:bg-cyan-700 text-lg h-12"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 ml-2 animate-spin" />
                    חותם...
                  </>
                ) : (
                  "אישור וחתימה"
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}