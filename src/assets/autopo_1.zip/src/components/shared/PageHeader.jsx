import React from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function PageHeader({ title, subtitle, action, actionLabel, actionIcon: ActionIcon = Plus }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">{title}</h1>
        {subtitle && <p className="text-gray-500 mt-1">{subtitle}</p>}
      </div>
      {action && (
        <Button 
          onClick={action}
          className="bg-cyan-600 hover:bg-cyan-700 shadow-lg shadow-cyan-600/30"
        >
          <ActionIcon className="w-5 h-5 ml-2" />
          {actionLabel}
        </Button>
      )}
    </div>
  );
}