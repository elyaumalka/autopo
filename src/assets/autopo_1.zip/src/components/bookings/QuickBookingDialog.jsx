import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CheckCircle2, Check, ChevronsUpDown } from "lucide-react";
import { format, addDays, addWeeks, addMonths } from "date-fns";
import NewCustomerDialog from "./NewCustomerDialog";

export default function QuickBookingDialog({ 
  isOpen, 
  onClose, 
  onSubmit,
  onSubmitAndStart, 
  date, 
  vehicle,
  customers 
}) {
  const [customerType, setCustomerType] = useState("existing"); // existing or new
  const [customerId, setCustomerId] = useState("");
  const [newCustomerName, setNewCustomerName] = useState("");
  const [startTime, setStartTime] = useState("10:00");
  const [rentalType, setRentalType] = useState("24 שעות");
  const [customEndDate, setCustomEndDate] = useState("");
  const [customEndTime, setCustomEndTime] = useState("10:00");
  const [rentalCost, setRentalCost] = useState("");
  const [customerSearch, setCustomerSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [showNewCustomerDialog, setShowNewCustomerDialog] = useState(false);
  const [tempBookingData, setTempBookingData] = useState(null);

  const filteredCustomers = customers.filter(c => {
    if (!customerSearch) return true;
    const searchLower = customerSearch.toLowerCase();
    return (
      c.first_name?.toLowerCase().includes(searchLower) ||
      c.last_name?.toLowerCase().includes(searchLower) ||
      c.phone?.includes(searchLower)
    );
  });

  const calculateEndDate = () => {
    const startDate = new Date(date);
    
    switch(rentalType) {
      case "חצי יום":
        return format(startDate, "yyyy-MM-dd");
      case "24 שעות":
        return format(addDays(startDate, 1), "yyyy-MM-dd");
      case "שבוע":
        return format(addWeeks(startDate, 1), "yyyy-MM-dd");
      case "חודש":
        return format(addMonths(startDate, 1), "yyyy-MM-dd");
      case "עד תאריך":
        return customEndDate;
      default:
        return format(addDays(startDate, 1), "yyyy-MM-dd");
    }
  };

  const getBookingData = () => {
    const selectedCustomer = customerType === "existing" 
      ? customers.find(c => c.id === customerId)
      : null;

    return {
      customer_id: customerId || "temp",
      customer_name: customerType === "existing" 
        ? (selectedCustomer ? `${selectedCustomer.first_name} ${selectedCustomer.last_name}` : "")
        : newCustomerName,
      vehicle_id: vehicle.id,
      vehicle_details: `${vehicle.manufacturer} ${vehicle.model} - ${vehicle.license_plate}`,
      start_date: date,
      start_time: startTime,
      end_date: calculateEndDate(),
      end_time: rentalType === "עד תאריך" ? customEndTime : "",
      rental_type: rentalType,
      rental_cost: rentalCost ? parseFloat(rentalCost) : 0,
      status: "מאושר"
    };
  };

  const handleSubmit = () => {
    onSubmit(getBookingData());
  };

  const handleSubmitAndStart = () => {
    const bookingData = getBookingData();
    
    // If new customer, open dialog to create customer first
    if (customerType === "new") {
      setTempBookingData(bookingData);
      setShowNewCustomerDialog(true);
    } else {
      onSubmitAndStart(bookingData);
    }
  };

  const handleNewCustomerCreated = (newCustomer) => {
    setShowNewCustomerDialog(false);
    
    // Update booking data with new customer
    const updatedBookingData = {
      ...tempBookingData,
      customer_id: newCustomer.id,
      customer_name: `${newCustomer.first_name} ${newCustomer.last_name}`
    };
    
    onSubmitAndStart(updatedBookingData);
  };

  if (!date || !vehicle) return null;

  return (
    <>
      <NewCustomerDialog
        isOpen={showNewCustomerDialog}
        onClose={() => setShowNewCustomerDialog(false)}
        onCustomerCreated={handleNewCustomerCreated}
        initialName={newCustomerName}
      />
      
      <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>שריון מהיר - {vehicle.license_plate}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-3 bg-gray-50 rounded-lg text-sm">
            <div><strong>רכב:</strong> {vehicle.manufacturer} {vehicle.model}</div>
            <div><strong>תאריך:</strong> {format(new Date(date), "dd/MM/yyyy")}</div>
          </div>

          <div>
            <Label>סוג לקוח</Label>
            <Select value={customerType} onValueChange={setCustomerType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="existing">לקוח קיים</SelectItem>
                <SelectItem value="new">לקוח חדש</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {customerType === "existing" ? (
            <div>
              <Label>בחר לקוח *</Label>
              <Popover open={open} onOpenChange={setOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={open}
                    className="w-full justify-between"
                  >
                    {customerId
                      ? (() => {
                          const selected = customers.find(c => c.id === customerId);
                          return selected ? `${selected.first_name} ${selected.last_name} - ${selected.phone}` : "בחר לקוח";
                        })()
                      : "בחר לקוח..."}
                    <ChevronsUpDown className="mr-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <div className="p-2">
                    <Input
                      placeholder="חיפוש לפי שם או טלפון..."
                      value={customerSearch}
                      onChange={(e) => setCustomerSearch(e.target.value)}
                      className="mb-2"
                    />
                    <div className="max-h-60 overflow-y-auto">
                      {filteredCustomers.length === 0 ? (
                        <div className="p-2 text-sm text-gray-500 text-center">לא נמצאו לקוחות</div>
                      ) : (
                        filteredCustomers.map((c) => (
                          <div
                            key={c.id}
                            className="flex items-center gap-2 p-2 cursor-pointer hover:bg-gray-100 rounded text-sm"
                            onClick={() => {
                              setCustomerId(c.id);
                              setOpen(false);
                            }}
                          >
                            <Check
                              className={`h-4 w-4 ${customerId === c.id ? "opacity-100" : "opacity-0"}`}
                            />
                            <div>
                              {c.first_name} {c.last_name} - {c.phone}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          ) : (
            <div>
              <Label>שם הלקוח *</Label>
              <Input
                placeholder="שם מלא"
                value={newCustomerName}
                onChange={(e) => setNewCustomerName(e.target.value)}
              />
            </div>
          )}

          <div>
            <Label>שעת יציאה</Label>
            <Input
              type="time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
            />
          </div>

          <div>
            <Label>סוג השכרה</Label>
            <Select value={rentalType} onValueChange={setRentalType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="חצי יום">חצי יום</SelectItem>
                <SelectItem value="24 שעות">24 שעות</SelectItem>
                <SelectItem value="שבוע">שבוע</SelectItem>
                <SelectItem value="חודש">חודש</SelectItem>
                <SelectItem value="עד תאריך">עד תאריך מסוים</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {rentalType === "עד תאריך" && (
            <div className="space-y-3">
              <div>
                <Label>תאריך סיום</Label>
                <Input
                  type="date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  min={date}
                />
              </div>
              <div>
                <Label>שעת סיום</Label>
                <Input
                  type="time"
                  value={customEndTime}
                  onChange={(e) => setCustomEndTime(e.target.value)}
                />
              </div>
            </div>
          )}

          {rentalType !== "עד תאריך" && (
            <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded">
              תאריך סיום משוער: {calculateEndDate() ? format(new Date(calculateEndDate()), "dd/MM/yyyy") : "-"}
            </div>
          )}

          <div>
            <Label>מחיר</Label>
            <Input
              type="number"
              placeholder="0"
              value={rentalCost}
              onChange={(e) => setRentalCost(e.target.value)}
            />
          </div>

          <div className="space-y-3 pt-2">
            <div className="flex gap-3">
              <Button
                onClick={handleSubmit}
                disabled={
                  (customerType === "existing" && !customerId) ||
                  (customerType === "new" && !newCustomerName) ||
                  (rentalType === "עד תאריך" && !customEndDate)
                }
                variant="outline"
                className="flex-1"
              >
                <CheckCircle2 className="w-4 h-4 ml-2" />
                שמור הזמנה בלבד
              </Button>
              <Button type="button" variant="outline" onClick={onClose}>
                ביטול
              </Button>
            </div>
            <Button
              onClick={handleSubmitAndStart}
              disabled={
                (customerType === "existing" && !customerId) ||
                (customerType === "new" && !newCustomerName) ||
                (rentalType === "עד תאריך" && !customEndDate)
              }
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <CheckCircle2 className="w-4 h-4 ml-2" />
              שמור והמשך להפעלת השכרה
            </Button>
          </div>
        </div>
      </DialogContent>
      </Dialog>
      </>
      );
      }