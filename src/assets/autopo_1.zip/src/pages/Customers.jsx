import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import PageHeader from "@/components/shared/PageHeader";
import DataTable from "@/components/shared/DataTable";
import StatusBadge from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Phone, Mail, MapPin, Edit, Trash2, Eye, Upload, Loader2, Sparkles, FileText, ExternalLink } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "react-hot-toast";

export default function Customers() {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [viewMode, setViewMode] = useState(false);
  const [formData, setFormData] = useState({});
  const [isProcessingLicense, setIsProcessingLicense] = useState(false);
  const queryClient = useQueryClient();

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list("-created_date")
  });

  const { data: rentals = [] } = useQuery({
    queryKey: ["rentals"],
    queryFn: () => base44.entities.Rental.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Customer.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["customers"]);
      setIsOpen(false);
      setSelectedCustomer(null);
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Customer.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(["customers"]);
      setIsOpen(false);
      setSelectedCustomer(null);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Customer.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["customers"])
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Merge form data with state data
    const formDataObj = new FormData(e.target);
    const data = { ...formData, ...Object.fromEntries(formDataObj.entries()) };
    
    if (data.license_start_year) {
      data.license_start_year = parseInt(data.license_start_year);
      // Auto-calculate seniority
      data.license_seniority = calculateSeniority(data.license_start_year);
    }

    if (selectedCustomer) {
      updateMutation.mutate({ id: selectedCustomer.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (customer) => {
    setSelectedCustomer(customer);
    setFormData(customer);
    setViewMode(false);
    setIsOpen(true);
  };

  const handleView = (customer) => {
    setSelectedCustomer(customer);
    setFormData(customer);
    setViewMode(true);
    setIsOpen(true);
  };

  const openNewCustomer = () => {
    setSelectedCustomer(null);
    setFormData({});
    setViewMode(false);
    setIsOpen(true);
  };

  const handleLicenseFrontUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingLicense(true);
    toast.loading("מעלה ומעבד את הצד הקדמי...", { id: "license-upload" });

    try {
      // Upload the file
      const uploadResult = await base44.integrations.Core.UploadFile({ file });
      const licenseImageUrl = uploadResult.file_url;

      // Extract data from the FRONT side of Israeli driving license
      const extractResult = await base44.integrations.Core.InvokeLLM({
        prompt: `זהו הצד הקדמי של רישיון נהיגה ישראלי. חלץ את המידע הבא בדיוק לפי המיקום:

1. ספרה 1: שם משפחה בעברית בלבד (לא באנגלית) - last_name
2. ספרה 2: שם פרטי בעברית בלבד (לא באנגלית) - first_name  
3. ספרה 3: תאריך לידה בפורמט yyyy-MM-dd (birth_date)
4. ספרה 4b: תוקף רישיון בפורמט yyyy-MM-dd (license_expiry) - חפש בדיוק בשורה 4b
5. ספרה 4D: מספר תעודת זהות - 9 ספרות (id_number) - חפש ליד "Driv. ID"
6. ספרה 8: כתובת מלאה בעברית (address) - כולל רחוב, מספר בית ועיר

CRITICAL: השמות חייבים להיות בעברית בלבד!
- אל תחזיר שמות באנגלית
- חפש רק את השמות בכתב עברי
- השמות בעברית מופיעים בשורות 1 ו-2
- תאריכים בפורמט yyyy-MM-dd
- ת.ז 9 ספרות
- כתובת מלאה מספרה 8
- אם לא מצאת, החזר null`,
        file_urls: [licenseImageUrl],
        response_json_schema: {
          type: "object",
          properties: {
            first_name: { type: "string" },
            last_name: { type: "string" },
            id_number: { type: "string" },
            birth_date: { type: "string" },
            license_expiry: { type: "string" },
            address: { type: "string" }
          }
        }
      });

      // Update form data with front side data
      setFormData({
        ...formData,
        license_front_image: licenseImageUrl,
        first_name: extractResult.first_name || formData.first_name,
        last_name: extractResult.last_name || formData.last_name,
        id_number: extractResult.id_number || formData.id_number,
        birth_date: extractResult.birth_date || formData.birth_date,
        license_expiry: extractResult.license_expiry || formData.license_expiry,
        address: extractResult.address || formData.address
      });

      toast.success("הצד הקדמי נשמר! כעת העלה את הצד האחורי", { id: "license-upload" });
    } catch (error) {
      console.error("Error processing license front:", error);
      toast.error("שגיאה בעיבוד הצד הקדמי", { id: "license-upload" });
    } finally {
      setIsProcessingLicense(false);
    }
  };

  const handleLicenseBackUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingLicense(true);
    toast.loading("מעלה ומעבד את הצד האחורי...", { id: "license-upload" });

    try {
      // Upload the file
      const uploadResult = await base44.integrations.Core.UploadFile({ file });
      const licenseImageUrl = uploadResult.file_url;

      // Extract data from the BACK side of Israeli driving license
      const extractResult = await base44.integrations.Core.InvokeLLM({
        prompt: `זהו הצד האחורי של רישיון נהיגה ישראלי. 
        
חפש את טבלת הרכבים (Categories of Vehicles) - ליד כל סוג רכב (A, B, C, D, E) יש שנה שמציינת מתי הורשה לנהוג ברכב זה.

חלץ את השנה הכי מוקדמת (הנמוכה ביותר) מבין כל השנים שרשומות בטבלה.
זו תהיה שנת תחילת הרישיון.

דוגמה: אם רואים:
- B: 2014
- A: 2015  
- C1: 2016

אז license_start_year צריך להיות 2014

החזר רק את השנה כמספר (license_start_year).
אם לא מצאת שום שנה, החזר null.`,
        file_urls: [licenseImageUrl],
        response_json_schema: {
          type: "object",
          properties: {
            license_start_year: { type: "number" }
          }
        }
      });

      // Calculate license seniority
      const currentYear = new Date().getFullYear();
      const licenseSeniority = extractResult.license_start_year 
        ? currentYear - extractResult.license_start_year 
        : null;

      // Update form data with back side data
      setFormData({
        ...formData,
        license_back_image: licenseImageUrl,
        license_start_year: extractResult.license_start_year || formData.license_start_year,
        license_seniority: licenseSeniority || formData.license_seniority
      });

      toast.success("שני הצדדים נקלטו בהצלחה! כל הפרטים מולאו", { id: "license-upload" });
    } catch (error) {
      console.error("Error processing license back:", error);
      toast.error("שגיאה בעיבוד הצד האחורי", { id: "license-upload" });
    } finally {
      setIsProcessingLicense(false);
    }
  };

  const calculateSeniority = (startYear) => {
    if (!startYear) return null;
    return new Date().getFullYear() - parseInt(startYear);
  };

  const calculateAge = (birthDate) => {
    if (!birthDate) return null;
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  const filteredCustomers = customers.filter(c =>
    `${c.first_name} ${c.last_name}`.includes(searchTerm) ||
    c.phone?.includes(searchTerm) ||
    c.id_number?.includes(searchTerm)
  );

  const getCustomerRentals = (customerId) => {
    return rentals.filter(r => r.customer_id === customerId);
  };

  const columns = [
    {
      header: "שם",
      cell: (row) => (
        <div className="font-medium">{row.first_name} {row.last_name}</div>
      )
    },
    {
      header: "טלפון",
      cell: (row) => (
        <a href={`tel:${row.phone}`} className="text-cyan-600 hover:underline flex items-center gap-1">
          <Phone className="w-4 h-4" />
          {row.phone}
        </a>
      )
    },
    { header: "ת.ז.", accessor: "id_number" },
    { 
      header: "גיל", 
      cell: (row) => {
        const age = calculateAge(row.birth_date);
        return age ? age : "-";
      }
    },
    { header: "עיר", accessor: "city" },
    {
      header: "סטטוס",
      cell: (row) => <StatusBadge status={row.status || "פעיל"} />
    },
    {
      header: "השכרות",
      cell: (row) => getCustomerRentals(row.id).length
    },
    {
      header: "פעולות",
      cell: (row) => (
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={() => handleView(row)}>
            <Eye className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => handleEdit(row)}>
            <Edit className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-red-500 hover:text-red-700"
            onClick={() => deleteMutation.mutate(row.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div>
      <PageHeader
        title="לקוחות"
        subtitle={`${customers.length} לקוחות רשומים`}
        action={openNewCustomer}
        actionLabel="לקוח חדש"
      />

      <div className="mb-6">
        <div className="relative max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="חיפוש לפי שם, טלפון או ת.ז..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10"
          />
        </div>
      </div>

      <DataTable
        columns={columns}
        data={filteredCustomers}
        isLoading={isLoading}
        emptyMessage="לא נמצאו לקוחות"
      />

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {viewMode ? "פרטי לקוח" : selectedCustomer ? "עריכת לקוח" : "לקוח חדש"}
            </DialogTitle>
          </DialogHeader>

          {viewMode && selectedCustomer ? (
            <div className="space-y-6">
              {/* License Images */}
              {(selectedCustomer.license_front_image || selectedCustomer.license_back_image) && (
                <div>
                  <h3 className="font-semibold mb-3">תמונות רישיון</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {selectedCustomer.license_front_image && (
                      <div>
                        <Label className="text-gray-500 mb-2 block">צד קדמי</Label>
                        <a 
                          href={selectedCustomer.license_front_image} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="block"
                        >
                          <img 
                            src={selectedCustomer.license_front_image} 
                            alt="רישיון צד קדמי" 
                            className="w-full h-48 object-cover rounded-lg border hover:opacity-80 transition-opacity"
                          />
                        </a>
                      </div>
                    )}
                    {selectedCustomer.license_back_image && (
                      <div>
                        <Label className="text-gray-500 mb-2 block">צד אחורי</Label>
                        <a 
                          href={selectedCustomer.license_back_image} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="block"
                        >
                          <img 
                            src={selectedCustomer.license_back_image} 
                            alt="רישיון צד אחורי" 
                            className="w-full h-48 object-cover rounded-lg border hover:opacity-80 transition-opacity"
                          />
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-500">שם מלא</Label>
                  <p className="font-medium">{selectedCustomer.first_name} {selectedCustomer.last_name}</p>
                </div>
                <div>
                  <Label className="text-gray-500">ת.ז.</Label>
                  <p className="font-medium">{selectedCustomer.id_number}</p>
                </div>
                <div>
                  <Label className="text-gray-500">טלפון</Label>
                  <p className="font-medium">{selectedCustomer.phone}</p>
                </div>
                <div>
                  <Label className="text-gray-500">טלפון נוסף</Label>
                  <p className="font-medium">{selectedCustomer.phone_secondary || "-"}</p>
                </div>
                <div>
                  <Label className="text-gray-500">מייל</Label>
                  <p className="font-medium">{selectedCustomer.email || "-"}</p>
                </div>
                {selectedCustomer.birth_date && (
                  <div>
                    <Label className="text-gray-500">גיל</Label>
                    <p className="font-medium">{calculateAge(selectedCustomer.birth_date)} שנים</p>
                  </div>
                )}
                <div>
                  <Label className="text-gray-500">כתובת</Label>
                  <p className="font-medium">{selectedCustomer.address}, {selectedCustomer.city}</p>
                </div>
                <div>
                  <Label className="text-gray-500">תוקף רישיון</Label>
                  <p className="font-medium">
                    {selectedCustomer.license_expiry ? format(new Date(selectedCustomer.license_expiry), "dd/MM/yyyy") : "-"}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-3">היסטוריית השכרות</h3>
                {getCustomerRentals(selectedCustomer.id).length === 0 ? (
                  <p className="text-gray-500">אין השכרות</p>
                ) : (
                  <div className="space-y-2">
                    {getCustomerRentals(selectedCustomer.id).map((rental) => (
                      <div key={rental.id} className="p-3 bg-gray-50 rounded-lg flex justify-between items-center">
                        <div>
                          <p className="font-medium">{rental.vehicle_details}</p>
                          <p className="text-sm text-gray-500">
                            {rental.start_date ? format(new Date(rental.start_date), "dd/MM/yyyy") : "-"}
                          </p>
                        </div>
                        <StatusBadge status={rental.status} />
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <Button onClick={() => { setViewMode(false); }} className="w-full">
                עריכה
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Customer Details */}
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="basic">פרטים בסיסיים</TabsTrigger>
                  <TabsTrigger value="documents">מסמכים</TabsTrigger>
                  <TabsTrigger value="reception">פרטי קבלה</TabsTrigger>
                </TabsList>

                <TabsContent value="basic" className="space-y-4">
              {/* License Upload Section */}
              <div className="border-2 border-dashed border-cyan-300 rounded-lg p-6 bg-cyan-50">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Sparkles className="w-5 h-5 text-cyan-600" />
                    <h3 className="font-semibold text-cyan-900">העלאת רישיון חכמה</h3>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    העלה את שני צדי הרישיון והמערכת תמלא את הפרטים אוטומטית
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    {/* Front Side */}
                    <div className="text-center">
                      <p className="text-sm font-medium mb-2 text-gray-700">צד קדמי</p>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById("license-front-upload").click()}
                        disabled={isProcessingLicense}
                        className="w-full border-cyan-600 text-cyan-600 hover:bg-cyan-50"
                      >
                        {isProcessingLicense ? (
                          <>
                            <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                            מעבד...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4 ml-2" />
                            {formData.license_front_image ? "הועלה ✓" : "העלה"}
                          </>
                        )}
                      </Button>
                      <input
                        id="license-front-upload"
                        type="file"
                        accept="image/*"
                        onChange={handleLicenseFrontUpload}
                        className="hidden"
                      />
                      {formData.license_front_image && (
                        <a 
                          href={formData.license_front_image} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-xs text-cyan-600 hover:underline block mt-1"
                        >
                          צפה בתמונה
                        </a>
                      )}
                    </div>

                    {/* Back Side */}
                    <div className="text-center">
                      <p className="text-sm font-medium mb-2 text-gray-700">צד אחורי</p>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById("license-back-upload").click()}
                        disabled={isProcessingLicense}
                        className="w-full border-cyan-600 text-cyan-600 hover:bg-cyan-50"
                      >
                        {isProcessingLicense ? (
                          <>
                            <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                            מעבד...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4 ml-2" />
                            {formData.license_back_image ? "הועלה ✓" : "העלה"}
                          </>
                        )}
                      </Button>
                      <input
                        id="license-back-upload"
                        type="file"
                        accept="image/*"
                        onChange={handleLicenseBackUpload}
                        className="hidden"
                      />
                      {formData.license_back_image && (
                        <a 
                          href={formData.license_back_image} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-xs text-cyan-600 hover:underline block mt-1"
                        >
                          צפה בתמונה
                        </a>
                      )}
                    </div>
                  </div>
                  {formData.license_front_image && formData.license_back_image && (
                    <div className="mt-3 p-2 bg-green-100 text-green-800 rounded-lg text-sm">
                      ✓ שני הצדדים הועלו בהצלחה
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="first_name">שם פרטי *</Label>
                  <Input
                    id="first_name"
                    name="first_name"
                    value={formData.first_name || ""}
                    onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="last_name">שם משפחה *</Label>
                  <Input
                    id="last_name"
                    name="last_name"
                    value={formData.last_name || ""}
                    onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone">טלפון *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone || ""}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone_secondary">טלפון נוסף</Label>
                  <Input
                    id="phone_secondary"
                    name="phone_secondary"
                    type="tel"
                    value={formData.phone_secondary || ""}
                    onChange={(e) => setFormData({ ...formData, phone_secondary: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="email">מייל</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email || ""}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="id_number">ת.ז. *</Label>
                  <Input
                    id="id_number"
                    name="id_number"
                    value={formData.id_number || ""}
                    onChange={(e) => setFormData({ ...formData, id_number: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="birth_date">תאריך לידה</Label>
                  <Input
                    id="birth_date"
                    name="birth_date"
                    type="date"
                    value={formData.birth_date || ""}
                    onChange={(e) => setFormData({ ...formData, birth_date: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="address">כתובת</Label>
                  <Input
                    id="address"
                    name="address"
                    value={formData.address || ""}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="city">עיר</Label>
                  <Input
                    id="city"
                    name="city"
                    value={formData.city || ""}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="license_start_year">שנת תחילת רישיון</Label>
                  <Input
                    id="license_start_year"
                    name="license_start_year"
                    type="number"
                    value={formData.license_start_year || ""}
                    onChange={(e) => {
                      const year = e.target.value;
                      setFormData({ 
                        ...formData, 
                        license_start_year: year,
                        license_seniority: calculateSeniority(year)
                      });
                    }}
                  />
                </div>
                <div>
                  <Label htmlFor="license_expiry">תוקף רישיון</Label>
                  <Input
                    id="license_expiry"
                    name="license_expiry"
                    type="date"
                    value={formData.license_expiry || ""}
                    onChange={(e) => setFormData({ ...formData, license_expiry: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="license_seniority">ותק רישיון (שנים) - אוטומטי</Label>
                  <Input
                    id="license_seniority"
                    name="license_seniority"
                    type="number"
                    value={formData.license_seniority || ""}
                    disabled
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="status">סטטוס</Label>
                  <Select name="status" defaultValue={selectedCustomer?.status || "פעיל"}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="פעיל">פעיל</SelectItem>
                      <SelectItem value="לא פעיל">לא פעיל</SelectItem>
                      <SelectItem value="חסום">חסום</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="payment_method">אמצעי תשלום מועדף</Label>
                  <Select name="payment_method" defaultValue={selectedCustomer?.payment_method}>
                    <SelectTrigger>
                      <SelectValue placeholder="בחר" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="מזומן">מזומן</SelectItem>
                      <SelectItem value="אשראי">אשראי</SelectItem>
                      <SelectItem value="צ'ק">צ'ק</SelectItem>
                      <SelectItem value="העברה בנקאית">העברה בנקאית</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="payment_timing">מועד תשלום</Label>
                  <Select name="payment_timing" defaultValue={selectedCustomer?.payment_timing || "מראש"}>
                    <SelectTrigger>
                      <SelectValue placeholder="בחר" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="מראש">מראש</SelectItem>
                      <SelectItem value="בסוף החודש">בסוף החודש</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

                </TabsContent>

                <TabsContent value="documents" className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    {formData.license_front_image && (
                      <div className="border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">רישיון נהיגה - קדמי</span>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(formData.license_front_image, '_blank')}
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </div>
                        <img 
                          src={formData.license_front_image} 
                          alt="רישיון קדמי"
                          className="w-full h-32 object-cover rounded"
                        />
                      </div>
                    )}
                    
                    {formData.license_back_image && (
                      <div className="border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">רישיון נהיגה - אחורי</span>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(formData.license_back_image, '_blank')}
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </div>
                        <img 
                          src={formData.license_back_image} 
                          alt="רישיון אחורי"
                          className="w-full h-32 object-cover rounded"
                        />
                      </div>
                    )}

                    {!formData.license_front_image && !formData.license_back_image && (
                      <div className="text-center py-8 text-gray-500">
                        <FileText className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                        <p>אין מסמכים</p>
                        <p className="text-sm mt-2">העלה רישיון נהיגה בטאב "פרטים בסיסיים"</p>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="reception" className="space-y-4">
              {/* Reception Details */}
              <div>
                <h3 className="font-semibold mb-3 text-gray-700">פרטים לקבלה</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="reception_business_name">שם עסק</Label>
                    <Input
                      id="reception_business_name"
                      name="reception_business_name"
                      value={formData.reception_business_name || ""}
                      onChange={(e) => setFormData({ ...formData, reception_business_name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="reception_tax_id">ח.פ / ע.מ</Label>
                    <Input
                      id="reception_tax_id"
                      name="reception_tax_id"
                      value={formData.reception_tax_id || ""}
                      onChange={(e) => setFormData({ ...formData, reception_tax_id: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="reception_address">כתובת לקבלה</Label>
                    <Input
                      id="reception_address"
                      name="reception_address"
                      value={formData.reception_address || ""}
                      onChange={(e) => setFormData({ ...formData, reception_address: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="reception_email">מייל לקבלה</Label>
                    <Input
                      id="reception_email"
                      name="reception_email"
                      type="email"
                      value={formData.reception_email || ""}
                      onChange={(e) => setFormData({ ...formData, reception_email: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div>
                <Label htmlFor="notes">הערות</Label>
                <Textarea
                  id="notes"
                  name="notes"
                  defaultValue={selectedCustomer?.notes}
                />
              </div>

                </TabsContent>
              </Tabs>

              <div className="flex gap-3 pt-4">
                <Button type="submit" className="flex-1 bg-cyan-600 hover:bg-cyan-700">
                  {selectedCustomer ? "עדכון" : "יצירה"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                  ביטול
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}